﻿using System;
using System.Data;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Text;

using System.Linq;

using Shove.Database;
using SLS.Zzy.Task.Helper;
using System.Text.RegularExpressions;

namespace SLS.Zzy.Task
{
    /// <summary>
    /// HPSH 的摘要说明
    /// </summary>
    public class ElectronTicket_Zzy_JC
    {
        private const int TimeoutSeconds = 90;

        private long gCount1 = 0;
        private long gCount2 = 0;
        private long gCount3 = 0;

        private System.Threading.Thread thread;
        private string ConnectionString;

        private Message msg = new Message("ElectronTicket_Zzy_JC");
        private Log log = new Log("ElectronTicket_Zzy_JC");

        public int State = 0;   // 0 停止 1 运行中 2 置为停止

        public string ElectronTicket_Zzy_JC_UserName;
        public string ElectronTicket_Zzy_JC_UserPassword;
        public string ElectronTicket_Zzy_JC_Getway;
        public string ElectronTicket_Zzy_JC_InquiryGetway;

        public ElectronTicket_Zzy_JC(string connectionstring)
        {
            ConnectionString = connectionstring;
        }

        public void Run()
        {
            SystemOptions so = new SystemOptions(ConnectionString);

            if (!so["ElectronTicket_ZZYTC_Status_ON"].ToBoolean(false))
            {
                return;
            }

            if ((ElectronTicket_Zzy_JC_Getway == "") || (ElectronTicket_Zzy_JC_UserName == "") || (ElectronTicket_Zzy_JC_UserPassword == ""))
            {
                msg.Send("ElectronTicket_Zzy_JC Task 参数配置不完整.");
                log.Write("ElectronTicket_Zzy_JC Task 参数配置不完整.");

                return;
            }

            // 已经启动
            if (State == 1)
            {
                return;
            }

            lock (this) // 确保临界区被一个 Thread 所占用
            {
                State = 1;

                gCount1 = 0;
                gCount2 = 0;
                gCount3 = 0;

                thread = new System.Threading.Thread(new System.Threading.ThreadStart(Do));
                thread.IsBackground = true;

                thread.Start();

                msg.Send("ElectronTicket_Zzy_JC Task Start.");
                log.Write("ElectronTicket_Zzy_JC Task Start.");
            }
        }

        public void Exit()
        {
            State = 2;
        }

        public void Do()
        {
            while (true)
            {
                if (State == 2)
                {
                    msg.Send("ElectronTicket_Zzy_JC Task Stop.");
                    log.Write("ElectronTicket_Zzy_JC Task Stop.");

                    State = 0;

                    Stop();

                    return;
                }

                System.Threading.Thread.Sleep(1000);   // 1秒为单位

                gCount1++;
                gCount2++;
                gCount3++;

                #region 10 秒，发送电子票数据

                if (gCount1 >= 10 * 1)
                {
                    gCount1 = 0;

                    try
                    {
                        WriteTickets();             // 满员方案拆分为票

                        msg.Send("WriteTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        msg.Send("WriteTickets is Fail: " + e.Message);
                        log.Write("WriteTickets is Fail: " + e.Message);
                    }

                    try
                    {
                        QueryTickets();             // 代购票查询

                        msg.Send("QueryTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        msg.Send("QueryTickets is Fail: " + e.Message);
                        log.Write("QueryTickets is Fail: " + e.Message);
                    }

                    try
                    {
                        SendTickets();              // 发送代购电子票

                        msg.Send("SendTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        msg.Send("SendTickets is Fail: " + e.Message);
                        log.Write("SendTickets is Fail: " + e.Message);
                    }
                }

                #endregion

                #region 2 分钟，查询奖期状态

                if (gCount2 >= 10 * 2)
                {
                    gCount2 = 0;

                    try
                    {
                        QueryIsuse();
                    }
                    catch (Exception e)
                    {
                        msg.Send("QueryIsuse is Fail: " + e.Message);
                        log.Write("QueryIsuse is Fail: " + e.Message);
                    }

                    try
                    {
                        QueryIsuseState();      // 查询奖期状态

                        msg.Send("QueryIsuseState ...... OK.");
                    }
                    catch (Exception e)
                    {
                        msg.Send("QueryIsuseState is Fail: " + e.Message);
                        log.Write("QueryIsuseState is Fail: " + e.Message);
                    }
                }

                #endregion

                #region 20 分钟，开奖查询

                if (gCount3 >= 10 * 2)
                {
                    gCount3 = 0;

                    try
                    {

                        // QueryIsuseOpen();      // 查询奖期开奖结果
                        msg.Send("QueryIsuseOpen ...... OK.");
                    }
                    catch (Exception e)
                    {
                        msg.Send("QueryIsuseOpen is Fail: " + e.Message);
                        log.Write("QueryIsuseOpen is Fail: " + e.Message);
                    }
                }

                #endregion
            }
        }

        private void Stop()
        {
            if (thread != null)
            {
                thread.Abort();
                thread = null;
            }
        }

        #region 定时器执行的事件

        // 满员方案拆分为票
        private void WriteTickets()
        {
            DataTable dt = new DAL.Views.V_SchemeSchedules().Open(ConnectionString, "ID, LotteryID, PlayTypeID, LotteryNumber, Multiple, Money", "Buyed = 0 and (GetDate() between StartTime and EndTime) and BuyedShare >= Share and isnull(Identifiers, '') = '' and PrintOutType = 108 and State < 2 and dateadd(mi, 1, StateUpdateTime) <= GetDate() and LotteryNumber <> '' and LotteryID not in (62, 70) and (PrintType = 0 or SPrintOutType = 108)", "UserType desc, [ID]");

            if (dt == null)
            {
                msg.Send("读取方案错误(WriteTickets)。");
                log.Write("读取方案错误(WriteTickets)。");

                return;
            }

            DAL.Tables.T_Schemes t_Schemes = new DAL.Tables.T_Schemes();

            foreach (DataRow dr in dt.Rows)
            {
                long SchemeID = Shove._Convert.StrToLong(dr["ID"].ToString(), -1);
                int LotteryID = Shove._Convert.StrToInt(dr["LotteryID"].ToString(), -1);
                string LotterNumber = dr["LotteryNumber"].ToString();
                int PlayTypeID = Shove._Convert.StrToInt(dr["PlayTypeID"].ToString(), -1);
                int Multiple = Shove._Convert.StrToInt(dr["Multiple"].ToString(), -1);

                if ((SchemeID < 0) || (LotteryID < 0) || (PlayTypeID < 0) || (Multiple < 1))
                {
                    msg.Send("读取方案错误(WriteTickets)。方案号：" + SchemeID.ToString());
                    log.Write("读取方案错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                double Money = 0;
                SLS.Lottery.Ticket[] Tickets = null;

                try
                {
                    Tickets = new SLS.Lottery()[LotteryID].ToElectronicTicket_ZZYTC(PlayTypeID, LotterNumber, Multiple, 50, ref Money);
                }
                catch (Exception e)
                {
                    msg.Send("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString() + "，" + e.Message);
                    log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString() + "，" + e.Message);

                    continue;
                }

                if (Tickets == null)
                {
                    msg.Send("分解票错误(WriteTickets)。方案号：" + SchemeID.ToString());
                    log.Write("分解票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                if (Money != Shove._Convert.StrToDouble(dr["Money"].ToString(), -1))
                {
                    msg.Send("异常警告！！！！(WriteTickets)。方案号： " + SchemeID.ToString() + " 的购买金额与实际票的金额不符合！！！！");
                    log.Write("异常警告！！！！(WriteTickets)。方案号： " + SchemeID.ToString() + " 的购买金额与实际票的金额不符合！！！！");

                    continue;
                }

                int TicketPlayTypeID = Tickets[0].PlayTypeID;

                string TicketXML = "<Tickets>";

                foreach (SLS.Lottery.Ticket ticket in Tickets)
                {
                    TicketXML += "<Ticket LotteryNumber=\"" + ticket.Number + "\" Multiple=\"" + ticket.Multiple + "\" Money=\"" + ticket.Money + "\" PlayTypeID=\"" + ticket.PlayTypeID.ToString() + "\"/>";
                }

                TicketXML += "</Tickets>";

                int ReturnValue = 0;
                string ReturnDescription = "";

                int Result = DAL.Procedures.P_SchemesSendToCenterAdd(ConnectionString, SchemeID, TicketPlayTypeID, TicketXML, ref ReturnValue, ref ReturnDescription);

                if ((Result < 0) || (ReturnValue < 0))
                {
                    msg.Send("票写入错误(WriteTickets)：方案号：" + SchemeID.ToString() + "，" + ReturnDescription + "," + TicketPlayTypeID.ToString() + "," + TicketXML);
                    log.Write("票写入错误(WriteTickets)：方案号：" + SchemeID.ToString() + "，" + ReturnDescription + "," + TicketPlayTypeID.ToString() + "," + TicketXML);
                }
            }
        }

        // 代购票查询
        private void QueryTickets()
        {
            DataTable dt = new DAL.Views.V_SchemesSendToCenter().Open(ConnectionString, "distinct SchemeID", "(((Sends > 0) AND (Sends < 100)) or sends in(11018, 11017, 12002)) AND (HandleResult = 0) AND (IsOpened = 0) and dateadd(mi, -30, EndTime) <= GetDate() and buyed = 0 and LotteryID not in (62, 70) and PrintOutType = 108", "");

            if (dt == null)
            {
                msg.Send("查询代购票出错(QueryTickets)：读取未成功票错误。");
                log.Write("查询代购票出错(QueryTickets)：读取未成功票错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            DataTable dtSchemesSendToCenter = null;

            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dtSchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter().Open(ConnectionString, "*", "schemeid=" + dt.Rows[i]["SchemeID"].ToString() + " and (Sends > 0) AND (Sends < 100) and HandleResult = 0", "");

                if (dtSchemesSendToCenter == null)
                {
                    continue;
                }

                if (dtSchemesSendToCenter.Rows.Count < 1)
                {
                    continue;
                }

                System.Threading.Thread.Sleep(1000);

                string Body = "<ilist><ielement>";

                int count = dtSchemesSendToCenter.Rows.Count;

                if (dtSchemesSendToCenter.Rows.Count > 10)
                {
                    count = 10;
                }

                for (int j = 0; j < count; j++)
                {
                    string ticketid = dtSchemesSendToCenter.Rows[j]["Identifiers"].ToString();
                    Body += "<AGENTOPERATEID>" + ticketid + "</AGENTOPERATEID>";
                }

                Body += "</ielement></ilist>";

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<caipiaotv>";
                Message += "<ctrl>";
                Message += "<userid>" + ElectronTicket_Zzy_JC_UserName + "</userid>";
                Message += "<key>" + Shove._Security.Encrypt.MD5(ElectronTicket_Zzy_JC_UserPassword + RegexReplace(Body, "<[^>]*>", ""), "utf-8").ToUpper() + "</key>";
                Message += "<command>50205</command>";
                Message += "</ctrl>";
                Message += Body;
                Message += "</caipiaotv>";

                WriteElectronTicketLog(true, "50205", Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_Zzy_JC_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                string TransType = "50205";
                string TransMessage = ReceiveString;

                WriteElectronTicketLog(false, TransType, ReceiveString);

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(TransMessage));
                }
                catch { }

                string errorcode = GetFromXPath(TransMessage, "caipiaotv/ctrl/errorcode");

                if (errorcode != "0")
                {
                    msg.Send("接收票信息时出现错误, 方案ID:" + dt.Rows[i]["SchemeID"].ToString() + ",  错误代码:" + errorcode);
                    log.Write("接收票信息时出现错误, 方案ID:" + dt.Rows[i]["SchemeID"].ToString() + ",  错误代码:" + errorcode);

                    continue;
                }

                string elements = TransMessage.Substring(TransMessage.IndexOf("<list"), TransMessage.LastIndexOf("</list>") - TransMessage.IndexOf("<list")) + "</list>";

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[0];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                for (int k = 0; k < dtTicket.Rows.Count; k++)
                {
                    DataRow dr = dtTicket.Rows[k];

                    string Identifiers = dr["AGENTOPERATEID"].ToString();
                    int Status = Shove._Convert.StrToInt(dr["ERRORCODE"].ToString(), 0);
                    int PrintStatus = Shove._Convert.StrToInt(dr["PRINTSTATUS"].ToString(), 0);

                    if (PrintStatus == 1)
                    {
                        int ReturnValue = 0;
                        string ReturnDescription = "";

                        int Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status.ToString(), ref ReturnValue, ref ReturnDescription);

                        if ((Result < 0) || (ReturnValue < 0))
                        {
                            msg.Send("对所查询到的电子票数据第一次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);
                            log.Write("对所查询到的电子票数据第一次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);

                            System.Threading.Thread.Sleep(1000);

                            ReturnValue = 0;
                            ReturnDescription = "";

                            Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status.ToString(), ref ReturnValue, ref ReturnDescription);

                            if ((Result < 0) || (ReturnValue < 0))
                            {
                                msg.Send("对所查询到的电子票数据第二次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);
                                log.Write("对所查询到的电子票数据第二次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);
                            }
                        }

                        continue;
                    }
                    else if (Status > 0)
                    {
                        t_SchemesSendToCenter.Sends.Value = Status;
                        t_SchemesSendToCenter.Update(ConnectionString, "Identifiers='" + Identifiers + "'");
                    }
                }
            }
        }

        // 发送代购电子票
        private void SendTickets()
        {
            DAL.Views.V_SchemesSendToCenter v_SchemesSendToCenter = new DAL.Views.V_SchemesSendToCenter();

            DataTable dt = v_SchemesSendToCenter.Open(ConnectionString, "distinct SchemeID, SiteID, UserType, Name, Email, Mobile", "Buyed = 0 and (GetDate() between StartTime and case when LotteryID = 62 then dateadd(s, 30, EndTime) else dateadd(mi, 90, EndTime) end) and Sends < 99 and (HandleResult = 0) and isnull(HandleDateTime, '') = '' and PrintOutType = 108 and LotteryID not in (62, 70)", " UserType desc");

            if (dt == null)
            {
                msg.Send("发送代购票出错(SendTickets)：读取方案错误。");
                log.Write("发送代购票出错(SendTickets)：读取方案错误。");

                return;
            }

            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();

            DataTable dtScheme = null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataTable dtSchemesSend = v_SchemesSendToCenter.Open(ConnectionString, "", "SchemeID=" + dt.Rows[i]["SchemeID"].ToString() + " and Buyed = 0 and Sends < 99 and HandleResult = 0 and isnull(HandleDateTime, '') = ''", "");

                if (dtSchemesSend == null)
                {
                    msg.Send("发送代购票出错(SendTickets)：读取方案错误。方案号：" + dt.Rows[i]["SchemeID"].ToString());
                    log.Write("发送代购票出错(SendTickets)：读取方案错误。方案号：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (dtSchemesSend.Rows.Count < 1)
                {
                    continue;
                }

                string Sends = dtSchemesSend.Rows[0]["Sends"].ToString();

                string ticketid = "";
                string LotteryNumber = "";
                int LotteryPlayTypeID = 0;
                int Price = 2;

                dtScheme = new DAL.Tables.T_Schemes().Open(ConnectionString, "PlayTypeID", "ID=" + dt.Rows[i]["SchemeID"].ToString(), "");

                if (dtScheme == null)
                {
                    continue;
                }

                if (dtScheme.Rows.Count != 1)
                {
                    continue;
                }

                LotteryPlayTypeID = Shove._Convert.StrToInt(dtScheme.Rows[0]["PlayTypeID"].ToString(), 0);

                DateTime Now = DateTime.Now;

                string Body = "<ilist>";

                int Count = dtSchemesSend.Rows.Count;

                if (dtSchemesSend.Rows.Count > 50)
                {
                    Count = 50;
                }

                for (int j = 0; j < Count; j++)
                {
                    DataRow dr = dtSchemesSend.Rows[j];

                    ticketid = dr["Identifiers"].ToString();

                    Body += "<ielement>";
                    Body += "<ISSUE>" + GetIsusesNameToZzy(dr["LotteryID"].ToString(), dr["IsuseName"].ToString()) + "</ISSUE>";
                    Body += "<LOTTERYID>" + GetLotteryName(int.Parse(dr["LotteryID"].ToString())) + "</LOTTERYID>";
                    Body += "<SCHEMETITLE>a</SCHEMETITLE>";
                    Body += "<SCHEMEDESCRIPTION>q</SCHEMEDESCRIPTION>";
                    Body += "<SCHEMEQUOTIENT>1</SCHEMEQUOTIENT>";

                    try
                    {
                        LotteryNumber = dr["Ticket"].ToString();
                    }
                    catch
                    {
                        continue;
                    }

                    string[] strs = LotteryNumber.Split('\n');
                    string lotterycode = "";
                    string lotterysaleid = "";

                    foreach (string str in strs)
                    {
                        if (str.Trim() == "")
                        {
                            continue;
                        }

                        lotterycode += str + "^";
                        lotterysaleid += dr["PlayTypeID"].ToString() + "^";
                    }

                    if (lotterycode.EndsWith("^"))
                    {
                        lotterycode = lotterycode.Substring(0, lotterycode.Length - 1);
                    }

                    if (lotterysaleid.EndsWith("^"))
                    {
                        lotterysaleid = lotterysaleid.Substring(0, lotterysaleid.Length - 1);
                    }

                    Body += "<LOTTERYSALEID>" + lotterysaleid + "</LOTTERYSALEID>";
                    Body += "<SCHEMELOTTERYINFO>" + lotterycode + "</SCHEMELOTTERYINFO>";
                    Body += "<SCHEMENUMBERS>" + dr["Multiple"].ToString() + "</SCHEMENUMBERS>";

                    if (LotteryPlayTypeID == 3903 || LotteryPlayTypeID == 3904)
                    {
                        Price = 3;
                    }

                    Body += "<LOTTERYNUMBERS>" + (double.Parse(dr["Money"].ToString()) / (double.Parse(dr["Multiple"].ToString()) * Price)).ToString() + "</LOTTERYNUMBERS>";
                    Body += "<SCHEMEVALUE>" + double.Parse(dr["Money"].ToString()).ToString().Replace(",", "") + "00" + "</SCHEMEVALUE>";
                    Body += "<AGENTOPERATEID>" + ticketid + "</AGENTOPERATEID>";
                    Body += "<VIEWFLAG>2</VIEWFLAG>";
                    Body += "<VIEWLIMIT>1</VIEWLIMIT>";
                    Body += "<ISCHECKOFF>0</ISCHECKOFF>";
                    Body += "<CHECKOFFQUOTIENT>0</CHECKOFFQUOTIENT>";
                    Body += "<QUOTIENTS>1</QUOTIENTS>";
                    Body += "<INVESTTYPEID>1</INVESTTYPEID>"; //投注口令
                    Body += "<ISAPPEND>" + (Price == 3 ? "1" : "0") + "</ISAPPEND>";
                    Body += "</ielement>";
                }

                Body += "</ilist>";

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<caipiaotv>";
                Message += "<ctrl>";
                Message += "<userid>" + ElectronTicket_Zzy_JC_UserName + "</userid>";
                Message += "<key>" + Shove._Security.Encrypt.MD5(ElectronTicket_Zzy_JC_UserPassword + RegexReplace(Body, "<[^>]*>", ""), "utf-8").ToUpper() + "</key>";
                Message += "<command>50207</command>";
                Message += "</ctrl>";
                Message += Body;
                Message += "</caipiaotv>";

                WriteElectronTicketLog(true, "50207", "transType=50207&transMessage=" + Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_Zzy_JC_Getway, Message, TimeoutSeconds);

                    WriteElectronTicketLog(false, "50207", ReceiveString);
                }
                catch
                {
                    msg.Send("电子票-103 发送失败(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());
                    log.Write("电子票-103 发送失败(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set Sends = Sends + 1 where SchemeID = " + dt.Rows[i]["SchemeID"].ToString()) < 0)
                {
                    msg.Send("更新票发送状态时出错(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());
                    log.Write("更新票发送状态时出错(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                string TransType = "50207";
                string TransMessage = ReceiveString;

                WriteElectronTicketLog(false, TransType, ReceiveString);

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(TransMessage));
                }
                catch { }

                string errorcode = GetFromXPath(TransMessage, "caipiaotv/ctrl/errorcode");

                if (errorcode != "0")
                {
                    msg.Send("接收票信息时出现错误, 方案ID:" + dt.Rows[i]["SchemeID"].ToString() + ",  错误代码:" + errorcode);
                    log.Write("接收票信息时出现错误, 方案ID:" + dt.Rows[i]["SchemeID"].ToString() + ",  错误代码:" + errorcode);

                    t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToInt(errorcode, 1);

                    t_SchemesSendToCenter.HandleDateTime.Value = DateTime.Now;
                    t_SchemesSendToCenter.Update(ConnectionString, "SchemeID = " + dt.Rows[i]["SchemeID"].ToString() + "");

                    continue;
                }

                string elements = TransMessage.Substring(TransMessage.IndexOf("<list"), TransMessage.LastIndexOf("</list>") - TransMessage.IndexOf("<list")) + "</list>";

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[0];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                for (int j = 0; j < dtTicket.Rows.Count; j++)
                {
                    DataRow dr = dtTicket.Rows[j];
                    string TicketID = dr["AGENTOPERATEID"].ToString();
                    string Status = dr["errorcode"].ToString();

                    if (Status != "0")
                    {
                        t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToInt(Status, 1);
                    }

                    t_SchemesSendToCenter.HandleDateTime.Value = DateTime.Now;
                    t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + TicketID + "'");

                    continue;
                }
            }

        }

        // 查询奖期
        private void QueryIsuse()
        {
            // 查询的几组条件说明：
            //  1 有效期内未开奖、未开启的
            //  2 已截止未开奖的
            DataTable dt = new DAL.Tables.T_Lotteries().Open(ConnectionString, "[ID]", "PrintOutType = 108", "");

            if (dt == null)
            {
                msg.Send("期号状态查询错误(QueryIsuse)。");
                log.Write("期号状态查询错误(QueryIsuse)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                string LotteryName = GetLotteryName(Shove._Convert.StrToInt(dt.Rows[i]["ID"].ToString(), 0));
                string Body = "<ilist><ielement><LOTTERYID>" + LotteryName + "</LOTTERYID></ielement></ilist>";

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<caipiaotv>";
                Message += "<ctrl>";
                Message += "<userid>" + ElectronTicket_Zzy_JC_UserName + "</userid>";
                Message += "<key>" + Shove._Security.Encrypt.MD5(ElectronTicket_Zzy_JC_UserPassword + RegexReplace(Body, "<[^>]*>", ""), "utf-8").ToUpper() + "</key>";
                Message += "<command>50200</command>";
                Message += "</ctrl>";
                Message += Body;
                Message += "</caipiaotv>";

                WriteElectronTicketLog(true, "50200", "transType=50200&transMessage=" + Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_Zzy_JC_InquiryGetway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                string TransType = "50200";
                string TransMessage = ReceiveString;

                WriteElectronTicketLog(false, TransType, ReceiveString);

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(TransMessage));
                }
                catch
                {
                    continue;
                }

                string errorcode = GetFromXPath(TransMessage, "caipiaotv/ctrl/errorcode");

                if (errorcode != "0")
                {
                    string errormsg = GetFromXPath(TransMessage, "caipiaotv/ctrl/errormsg");

                    msg.Send("奖期查询时出现错误, 彩种ID:" + dt.Rows[i]["ID"].ToString() + ",  错误代码:" + errorcode + ", 错误描述:" + errormsg);
                    log.Write("奖期查询时出现错误, 彩种ID:" + dt.Rows[i]["ID"].ToString() + ",  错误代码:" + errorcode + ", 错误描述:" + errormsg);

                    continue;
                }

                if (TransMessage.IndexOf("<element") < 0)
                {
                    continue;
                }

                string elements = TransMessage.Substring(TransMessage.IndexOf("<element"), TransMessage.LastIndexOf("</element>") - TransMessage.IndexOf("<element")) + "</element>";

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtIsuses = ds.Tables[0];

                if (dtIsuses.Rows.Count < 1)
                {
                    return;
                }

                DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

                DateTime Starttime = new DateTime();
                DateTime EndTime = new DateTime();
                short State = 0;
                string IsuseName = "";

                for (int k = 0; k < dtIsuses.Rows.Count; k++)
                {
                    DataRow dr = dtIsuses.Rows[k];

                    LotteryName = dr["LOTTERYID"].ToString();
                    int LotteryID = GetLotteryID(LotteryName);

                    Starttime = Shove._Convert.StrToDateTime(dr["STARTTIMESTAMP"].ToString(), DateTime.Now.ToString());
                    EndTime = Shove._Convert.StrToDateTime(dr["ENDTIMESTAMP"].ToString(), DateTime.Now.ToString());
                    State = Shove._Convert.StrToShort(dr["STATUS"].ToString(), 0);
                    IsuseName = GetIsusesNameToCaiyou(LotteryID.ToString(), dr["ISSUE"].ToString());

                    if (t_Isuses.GetCount(ConnectionString, "LotteryID = " + LotteryID.ToString() + " and [Name] = '" + Shove._Web.Utility.FilteSqlInfusion(IsuseName) + "' and year(Getdate()) = year(EndTime)") < 1)
                    {
                        long IsuseID = 0;
                        string ReturnDescription = "";

                        if (DAL.Procedures.P_IsuseAdd(ConnectionString, LotteryID, IsuseName, Starttime, EndTime, "", ref IsuseID, ref ReturnDescription) < 0)
                        {
                            continue;
                        }

                        if (IsuseID < 0)
                        {
                            continue;
                        }
                    }

                    int ReturnValues = 0;
                    string ReturnDescprtions = "";

                    if (DAL.Procedures.P_IsuseUpdate(ConnectionString, LotteryID, Shove._Web.Utility.FilteSqlInfusion(IsuseName), State, Starttime, EndTime, DateTime.Now, "", ref ReturnValues, ref ReturnDescprtions) < 0)
                    {
                        msg.Send("电子票期号更新出现错误");
                    }
                }

                #endregion
            }
        }

        // 查询奖期状态

        private void QueryIsuseState()
        {
            // 查询的几组条件说明：
            //  1 有效期内未开奖、未开启的
            //  2 已截止未开奖的
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "(isOpened = 0 and Getdate() > EndTime and State < 5 and LotteryID in (72,73)) and PrintOutType = 108", "EndTime");

            if (dt == null)
            {
                msg.Send("期号状态查询错误(QueryIsuseState)。");
                log.Write("期号状态查询错误(QueryIsuseState)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                string LotteryName = GetLotteryName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = GetIsusesNameToZzy(dt.Rows[i]["LotteryID"].ToString(), dt.Rows[i]["Name"].ToString());
                string Body = "<ilist><ielement><LOTTERYID>" + LotteryName + "</LOTTERYID><ISSUE>" + IsuseName + "</ISSUE></ielement></ilist>";

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<caipiaotv>";
                Message += "<ctrl>";
                Message += "<userid>" + ElectronTicket_Zzy_JC_UserName + "</userid>";
                Message += "<key>" + Shove._Security.Encrypt.MD5(ElectronTicket_Zzy_JC_UserPassword + RegexReplace(Body, "<[^>]*>", ""), "utf-8").ToUpper() + "</key>";
                Message += "<command>50203</command>";
                Message += "</ctrl>";
                Message += Body;
                Message += "</caipiaotv>";

                WriteElectronTicketLog(true, "50203", "transType=50203&transMessage=" + Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_Zzy_JC_InquiryGetway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                string TransType = "50203";
                string TransMessage = ReceiveString;

                WriteElectronTicketLog(false, TransType, ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(TransMessage));
                }
                catch
                {
                    continue;
                }

                string errorcode = GetFromXPath(TransMessage, "caipiaotv/ctrl/errorcode");

                if (errorcode != "0")
                {
                    string errormsg = GetFromXPath(TransMessage, "caipiaotv/ctrl/errormsg");

                    msg.Send("奖期查询时出现错误, 期号ID:" + dt.Rows[i]["Name"].ToString() + ",  错误代码:" + errorcode + ", 错误描述:" + errormsg);
                    log.Write("奖期查询时出现错误, 期号ID:" + dt.Rows[i]["Name"].ToString() + ",  错误代码:" + errorcode + ", 错误描述:" + errormsg);

                    continue;
                }

                if (TransMessage.IndexOf("<element") < 0)
                {
                    continue;
                }

                string elements = TransMessage.Substring(TransMessage.IndexOf("<element"), TransMessage.LastIndexOf("</element>") - TransMessage.IndexOf("<element")) + "</element>";

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[0];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

                for (int k = 0; k < dtTicket.Rows.Count; k++)
                {
                    DataRow dr = dtTicket.Rows[k];

                    LotteryName = dr["LOTTERYID"].ToString();
                    int LotteryID = GetLotteryID(LotteryName);
                    IsuseName = GetIsusesNameToCaiyou(LotteryID.ToString(), dr["ISSUE"].ToString());
                    string WinNumber = GetWinNumber(LotteryID, dr["BONUSCODE"].ToString());

                    if ((LotteryID < 0) || (String.IsNullOrEmpty(IsuseName)))
                    {
                        continue;
                    }

                    DataTable dtIsuse = t_Isuses.Open(ConnectionString, "ID, State, WinLotteryNumber", "LotteryID = " + LotteryID.ToString() + " and [Name] = '" + IsuseName + "' and year(getdate()) = year(endtime)", "");

                    if ((dtIsuse == null) || (dtIsuse.Rows.Count < 1))
                    {
                        continue;
                    }

                    if (!String.IsNullOrEmpty(WinNumber) && (dtIsuse.Rows[0]["WinLotteryNumber"].ToString() != WinNumber))
                    {
                        DataTable dtWinTypes = new DAL.Tables.T_WinTypes().Open(ConnectionString, "", "LotteryID =" + LotteryID.ToString(), "");

                        double[] WinMoneyList = new double[dtWinTypes.Rows.Count * 2];

                        for (int j = 0; j < dtWinTypes.Rows.Count; j++)
                        {
                            if (Shove._Convert.StrToDouble(dtWinTypes.Rows[j]["DefaultMoney"].ToString(), 1) < 1)
                            {
                                return;
                            }

                            WinMoneyList[j * 2] = Shove._Convert.StrToDouble(dtWinTypes.Rows[j]["DefaultMoney"].ToString(), 1);
                            WinMoneyList[j * 2 + 1] = Shove._Convert.StrToDouble(dtWinTypes.Rows[j]["DefaultMoneyNoWithTax"].ToString(), 1);
                        }

                        #region 开奖第一步

                        DataTable dtWin = null;

                        dtWin = new DAL.Tables.T_Schemes().Open(ConnectionString, "LotteryNumber,PlayTypeID,Multiple,ID", "isOpened = 0 and IsuseID = " + dtIsuse.Rows[0]["ID"].ToString(), "[ID]");

                        if (dtWin == null)
                        {
                            return;
                        }

                        for (int y = 0; y < dtWin.Rows.Count; y++)
                        {
                            string LotteryNumber = "";

                            try
                            {
                                LotteryNumber = dtWin.Rows[y]["LotteryNumber"].ToString();
                            }
                            catch
                            { }

                            string Description = "";
                            double WinMoneyNoWithTax = 0;

                            try
                            {

                                double WinMoney = new SLS.Lottery()[LotteryID].ComputeWin(LotteryNumber, WinNumber, ref Description, ref WinMoneyNoWithTax, int.Parse(dtWin.Rows[y]["PlayTypeID"].ToString()), WinMoneyList);

                                Shove.Database.MSSQL.ExecuteNonQuery(ConnectionString, "update T_Schemes set EditWinMoney = @p1, EditWinMoneyNoWithTax = @p2, WinDescription = @p3 where [ID] = " + dtWin.Rows[y]["ID"].ToString(),
                                    new Shove.Database.MSSQL.Parameter("p1", SqlDbType.Money, 0, ParameterDirection.Input, WinMoney * Shove._Convert.StrToInt(dtWin.Rows[y]["Multiple"].ToString(), 1)),
                                    new Shove.Database.MSSQL.Parameter("p2", SqlDbType.Money, 0, ParameterDirection.Input, WinMoneyNoWithTax * Shove._Convert.StrToInt(dtWin.Rows[y]["Multiple"].ToString(), 1)),
                                    new Shove.Database.MSSQL.Parameter("p3", SqlDbType.VarChar, 0, ParameterDirection.Input, Description));
                            }
                            catch
                            {
                                continue;
                            }
                        }

                        #endregion

                        #region 开奖第二步

                        int SchemeCount, QuashCount, WinCount, WinNoBuyCount;
                        bool isEndOpen = false;

                        int ReturnValue = 0;
                        string ReturnDescription = "";

                        while (!isEndOpen)
                        {
                            SchemeCount = 0;
                            QuashCount = 0;
                            WinCount = 0;
                            WinNoBuyCount = 0;
                            //  总方案数，处理时撤单数，中奖数，中奖但未成功数

                            ReturnValue = 0;
                            ReturnDescription = "";
                            DataSet dsWin = null;

                            DAL.Procedures.P_Win(ConnectionString, ref dsWin,
                                 Shove._Convert.StrToLong(dtIsuse.Rows[0]["ID"].ToString(), 0),
                                 WinNumber,
                                 "",
                                 1,
                                 true,
                                 ref SchemeCount, ref QuashCount, ref WinCount, ref WinNoBuyCount,
                                 ref isEndOpen,
                                 ref ReturnValue, ref ReturnDescription);
                        }

                        #endregion
                    }
                }

                #endregion
            }
        }

        #endregion

        /////////////////////////////////////////////////////////////////////////////////////

        // 返回成功信息
        private void ReNotice(string MessageID, string Type)
        {
            DateTime Now = DateTime.Now;

            string Body = "<body><response code=\"0000\" message=\"成功，系统处理正常\"/></body>";

            string TimeStamp = Now.ToString("yyyyMMdd") + Now.ToString("HHmmss");

            string Message = "<?xml version=\"1.0\" encoding=\"GBK\"?>";
            Message += "<message version=\"1.0\" id=\"" + MessageID + "\">";
            Message += "<header>";
            Message += "<messengerID>" + ElectronTicket_Zzy_JC_UserName + "</messengerID>";
            Message += "<timestamp>" + TimeStamp + "</timestamp>";
            Message += "<transactiontype>" + Type + "</transactiontype>";
            Message += "<digest>" + Shove._Security.Encrypt.MD5(MessageID + TimeStamp + ElectronTicket_Zzy_JC_UserPassword + Body, "gb2312") + "</digest>";
            Message += "</header>";
            Message += Body;
            Message += "</message>";

            WriteElectronTicketLog(true, Type, "transType=" + Type + "&transMessage=" + Message);

            PublicFunction.Post(ElectronTicket_Zzy_JC_Getway, "transType=" + Type + "&transMessage=" + Message, TimeoutSeconds);
        }

        #region 公共方法

        private string GetFromXPath(string XML, string XPath)
        {
            if (XML.Trim() == "")
                return "";

            string Result = "";
            try
            {
                XPathDocument doc = new XPathDocument(new StringReader(XML));
                XPathNavigator nav = doc.CreateNavigator();
                XPathNodeIterator nodes = nav.Select(XPath);
                while (nodes.MoveNext())
                    Result += nodes.Current.Value;
            }
            catch//(Exception ee)
            {
                return "";
                //return ee.Message;
            }

            return Result;
        }

        private string GetLotteryName(int LotteryID)
        {
            switch (LotteryID)
            {
                case 2:
                    return "D8";
                case 3:
                    return "D7";
                case 9:
                    return "C522";
                case 15:
                    return "D12";
                case 39:
                    return "C355";
                case 62:
                    return "D11";
                case 63:
                    return "D3";
                case 64:
                    return "D5";
                case 65:
                    return "C731";
                case 70:
                    return "DLC";
                case 74:
                    return "D14";
                case 75:
                    return "D9";
                case 72:
                    return "";
                case 73:
                    return "";
                default:
                    return "";
            }
        }

        private int GetLotteryID(string LotteryName)
        {
            switch (LotteryName)
            {
                case "D8":
                    return 2;
                case "D7":
                    return 3;
                case "C522":
                    return 9;
                case "D12":
                    return 15;
                case "C355":
                    return 39;
                case "D11":
                    return 62;
                case "D3":
                    return 63;
                case "D5":
                    return 64;
                case "C731":
                    return 65;
                case "DLC":
                    return 70;
                case "D14":
                    return 74;
                case "D9":
                    return 75;
                default:
                    return -1;
            }
        }

        //写日志文件
        public void WriteElectronTicketLog(bool isSend, string TransType, string TransMessage)
        {
            log.Write("isSend: " + isSend.ToString() + "\tTransType: " + TransType + "\t" + TransMessage);
        }

        //正则表达式替换通用方法
        public string RegexReplace(string StrReplace, string strRegex, string NewStr)
        {
            Regex regex = new Regex(strRegex, RegexOptions.IgnoreCase | RegexOptions.Compiled);

            return regex.Replace(StrReplace, NewStr);
        }


        private string GetIsusesNameToCaiyou(string LotteryID, string IsusesName)
        {
            switch (LotteryID)
            {
                case "74":
                    return "20" + IsusesName;
                case "75":
                    return "20" + IsusesName;
                case "2":
                    return "20" + IsusesName;
                case "15":
                    return "20" + IsusesName;
                case "39":
                    return "20" + IsusesName;
                case "3":
                    return "20" + IsusesName;
                case "63":
                    return "20" + IsusesName;
                case "64":
                    return "20" + IsusesName;
                case "9":
                    return "20" + IsusesName;
                case "65":
                    return "20" + IsusesName;
                default:
                    return IsusesName;
            }
        }

        private string GetIsusesNameToZzy(string LotteryID, string IsusesName)
        {
            switch (LotteryID)
            {
                case "74":
                    return IsusesName.Substring(2);
                case "75":
                    return IsusesName.Substring(2);
                case "2":
                    return IsusesName.Substring(2);
                case "15":
                    return IsusesName.Substring(2);
                case "39":
                    return IsusesName.Substring(2);
                case "3":
                    return IsusesName.Substring(2);
                case "63":
                    return IsusesName.Substring(2);
                case "64":
                    return IsusesName.Substring(2);
                case "9":
                    return IsusesName.Substring(2);
                case "65":
                    return IsusesName.Substring(2);
                default:
                    return IsusesName;
            }
        }

        #endregion

        #region 分析中奖描述、奖等

        private class CompareToLength : IComparer
        {
            int IComparer.Compare(Object x, Object y)
            {
                long _x = Shove._Convert.StrToLong(x.ToString(), -1);
                long _y = Shove._Convert.StrToLong(y.ToString(), -1);

                return _x.CompareTo(_y);
            }
        }

        private string GetWinNumber(int LotteryID, string WinNumber)
        {
            switch (LotteryID)
            {
                case 1:
                    return WinNumber.Replace(",", "");
                case 2:
                    return WinNumber.Replace(",", "");
                case 3:
                    return WinNumber.Replace(",", "");
                case 5:
                    return WinNumber.Replace(",", " ").Insert(15, "+");
                case 6:
                    return WinNumber.Replace(",", "");
                case 9:
                    return WinNumber.Replace(",", " ");
                case 13:
                    return WinNumber.Replace(",", " ").Insert(21, "+");
                case 15:
                    return WinNumber.Replace(",", "");
                case 29:
                    return WinNumber.Replace(",", "");
                case 39:
                    return WinNumber.Replace(",", " ").Insert(15, " + ");
                case 65:
                    return WinNumber.Replace(",", " ").Insert(21, "+");
                case 62:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 63:
                    return WinNumber.Replace(",", "");
                case 64:
                    return WinNumber.Replace(",", "");
                case 70:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 74:
                    return WinNumber.Replace(",", "");
                case 75:
                    return WinNumber.Replace(",", "");
                default:
                    return WinNumber;
            }
        }

        #endregion
    }
}