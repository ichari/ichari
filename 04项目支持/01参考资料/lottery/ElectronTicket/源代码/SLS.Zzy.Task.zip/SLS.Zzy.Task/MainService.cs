﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Configuration;

namespace SLS.Zzy.Task
{
    public partial class MainService : ServiceBase
    {
        private string ConnectionString = "";

        private ElectronTicket_Zzy ElectronTicket_Zzy_Task = null;
        private ElectronTicket_Zzy_GP ElectronTicket_Zzy_GP_Task = null;

        public MainService()
        {
            InitializeComponent();
            Shove._IO.IniFile ini = new Shove._IO.IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "Config.ini");
            ConnectionString = ini.Read("Options", "ConnectionString");
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                System.Data.SqlClient.SqlConnection conn = Shove.Database.MSSQL.CreateDataConnection<System.Data.SqlClient.SqlConnection>(ConnectionString);

                while (conn.State != ConnectionState.Open)
                {
                    conn.Open();

                    new Log("System").Write("数据库连接失败");

                    System.Threading.Thread.Sleep(1000);
                }

                conn.Close();
            }
            catch (Exception e)
            {
                new Log("System").Write(e.Message);
            }

            SystemOptions so = new SystemOptions(ConnectionString);

            // 掌中奕电子票自动任务
            try
            {
                if (so["ElectronTicket_ZZYTC_Status_ON"].ToBoolean(false) && (new DAL.Tables.T_Lotteries().GetCount(ConnectionString, "PrintOutType = 108") > 0))
                {
                    ElectronTicket_Zzy_Task = new ElectronTicket_Zzy(ConnectionString);

                    ElectronTicket_Zzy_Task.ElectronTicket_Zzy_Getway = so["ElectronTicket_ZZYTC_Getway"].ToString("");
                    ElectronTicket_Zzy_Task.ElectronTicket_Zzy_UserName = so["ElectronTicket_ZZYTC_UserName"].ToString("");
                    ElectronTicket_Zzy_Task.ElectronTicket_Zzy_UserPassword = so["ElectronTicket_ZZYTC_UserPassword"].ToString("");
                    ElectronTicket_Zzy_Task.ElectronTicket_Zzy_InquiryGetway = so["ElectronTicket_ZZYTC_InquiryGetway"].ToString("");

                    ElectronTicket_Zzy_GP_Task = new ElectronTicket_Zzy_GP(ConnectionString);

                    ElectronTicket_Zzy_GP_Task.ElectronTicket_Zzy_GP_Getway = so["ElectronTicket_ZZYTC_Getway"].ToString("");
                    ElectronTicket_Zzy_GP_Task.ElectronTicket_Zzy_GP_UserName = so["ElectronTicket_ZZYTC_UserName"].ToString("");
                    ElectronTicket_Zzy_GP_Task.ElectronTicket_Zzy_GP_UserPassword = so["ElectronTicket_ZZYTC_UserPassword"].ToString("");
                    ElectronTicket_Zzy_GP_Task.ElectronTicket_Zzy_GP_InquiryGetway = so["ElectronTicket_ZZYTC_InquiryGetway"].ToString("");

                    if ((ElectronTicket_Zzy_Task.ElectronTicket_Zzy_Getway != "") && (ElectronTicket_Zzy_Task.ElectronTicket_Zzy_UserName != "") && (ElectronTicket_Zzy_Task.ElectronTicket_Zzy_UserPassword != ""))
                    {
                        ElectronTicket_Zzy_Task.Run();
                        ElectronTicket_Zzy_GP_Task.Run();
                    }
                }
            }
            catch (Exception e)
            {
                new Log("System").Write("ElectronTicket_Zzy 启动失败：" + e.Message);
            }
        }

        protected override void OnStop()
        {
            if (ElectronTicket_Zzy_Task != null)
            {
                ElectronTicket_Zzy_Task.Exit();
            }

            if (ElectronTicket_Zzy_GP_Task != null)
            {
                ElectronTicket_Zzy_GP_Task.Exit();
            }

            while ((ElectronTicket_Zzy_Task != null) && (ElectronTicket_Zzy_Task.State != 0)) { System.Threading.Thread.Sleep(500); };
            while ((ElectronTicket_Zzy_GP_Task != null) && (ElectronTicket_Zzy_GP_Task.State != 0)) { System.Threading.Thread.Sleep(500); };
        }
    }
}
