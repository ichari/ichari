﻿using System;
using System.Data;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Text;

using System.Linq;

using Shove.Database;
using SLS.Cttcsd.Task.Helper;

namespace SLS.Cttcsd.Task
{
    /// <summary>
    /// HPSH 的摘要说明
    /// </summary>
    public class ElectronTicket_WriteSends
    {
        private const int TimeoutSeconds = 90;
 
        private long gCount1 = 0;

        private System.Threading.Thread thread;

        private string ConnectionString;

        private Log log = new Log("ElectronTicket_WriteSends");

        public int State = 0;   // 0 停止 1 运行中 2 置为停止

        public string ElectronTicket_CTTCSD_UserName;
        public string ElectronTicket_CTTCSD_UserPassword;
        public string ElectronTicket_CTTCSD_Getway;
        public string ElectronTicket_CTTCSD_DownloadGetway;

        public string ElectronTicket_PrintOut_IDCardNumber;
        public string ElectronTicket_PrintOut_Mobile;

        public ElectronTicket_WriteSends(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public void Run()
        {
            SystemOptions so = new SystemOptions(ConnectionString);

            if (!so["ElectronTicket_CTTCSD_Status_ON"].ToBoolean(false))
            {
                return;
            }

            if ((ElectronTicket_CTTCSD_Getway == "") || (ElectronTicket_CTTCSD_UserName == "") || (ElectronTicket_CTTCSD_UserPassword == ""))
            {
                log.Write("ElectronTicket_WriteSends Task 参数配置不完整.");

                return;
            }

            // 已经启动
            if (State == 1)
            {
                return;
            }

            lock (this) // 确保临界区被一个 Thread 所占用
            {
                State = 1;

                gCount1 = 0;

                thread = new System.Threading.Thread(new System.Threading.ThreadStart(Do));
                thread.IsBackground = true;

                thread.Start();

                log.Write("ElectronTicket_WriteSends Task Start.");
            }
        }

        public void Exit()
        {
            State = 2;
        }

        public void Do()
        {
            while (true)
            {
                if (State == 2)
                {
                    log.Write("ElectronTicket_WriteSends Task Stop.");

                    State = 0;

                    Stop();

                    return;
                }

                System.Threading.Thread.Sleep(1000);   // 1秒为单位

                gCount1++; 

                #region 20 秒，发送电子票数据

                if (gCount1 >= 20 * 1)
                {
                    gCount1 = 0;

                    try
                    {
                        WriteTickets();             // 满员方案拆分为票
                        log.Write("WriteTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("WriteTickets is Fail: " + e.Message);
                    }

                    try
                    {
                        SendTickets();              // 发送代购电子票

                        log.Write("SendTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("SendTickets is Fail: " + e.Message);
                    }
                }

                #endregion 
            }
        }

        private void Stop()
        {
            if (thread != null)
            {
                thread.Abort();
                thread = null;
            }
        }

        #region 定时器执行的事件

        // 满员方案拆分为票
        private void WriteTickets()
        {
            //DataTable dt = new DAL.Views.V_SchemeSchedules().Open(ConnectionString, "ID, LotteryID, PlayTypeID, LotteryNumber, Multiple, Money", "Buyed = 0 and (GetDate() between StartTime and EndTime) and BuyedShare >= Share and isnull(Identifiers, '') = '' and PrintOutType = 108 and (State = 4 or State = 1 or State  = 0) and dateadd(mi, 1, StateUpdateTime) <= GetDate() and LotteryNumber <> ''", "[ID]");

            /// Loong Update Date: 2011-12-20
            /// 注解：方案进度未到100, 使用保底补上, 处理方案进度加保底大于100的方案
            string condition = @"Buyed = 0 and (GetDate() between StartTime and EndTime) 
                and isnull(Identifiers, '') = '' and PrintOutType = 108 and (State = 4 or State = 1 or State  = 0) 
                and dateadd(mi, 1, StateUpdateTime) <= GetDate() and LotteryNumber <> '' 
                and ((AssureMoney / (Money / Share)) + BuyedShare) >= Share"; /* 购买份数未达到总份数, 使用保底补上*/

            DataTable dt = new DAL.Views.V_SchemeSchedules().Open(ConnectionString, "ID, LotteryID, PlayTypeID, LotteryNumber, Multiple, Money", condition, "[ID]");
            if (dt == null)
            {
                log.Write("读取方案错误(WriteTickets)。");

                return;
            }

            DAL.Tables.T_Schemes t_Schemes = new DAL.Tables.T_Schemes();

            foreach (DataRow dr in dt.Rows)
            {
                long SchemeID = Shove._Convert.StrToLong(dr["ID"].ToString(), -1);
                int LotteryID = Shove._Convert.StrToInt(dr["LotteryID"].ToString(), -1);
                string LotterNumber = dr["LotteryNumber"].ToString();
                int PlayTypeID = Shove._Convert.StrToInt(dr["PlayTypeID"].ToString(), -1);
                int Multiple = Shove._Convert.StrToInt(dr["Multiple"].ToString(), -1);

                if ((SchemeID < 0) || (LotteryID < 0) || (PlayTypeID < 0) || (Multiple < 1))
                {
                    log.Write("读取方案错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                double Money = 0;
                SLS.Lottery.Ticket[] Tickets = null;

                try
                {
                    Tickets = new SLS.Lottery()[LotteryID].ToElectronicTicket_CTTCSD(PlayTypeID, LotterNumber.Trim(), Multiple, 99, ref Money);
                }
                catch (Exception e)
                {
                    log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString() + "，" + e.Message);

                    continue;
                }

                if (Tickets == null)
                {
                    log.Write("分解票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                if (Money != Shove._Convert.StrToDouble(dr["Money"].ToString(), -1))
                {
                    log.Write("异常警告！！！！(WriteTickets)。方案号： " + SchemeID.ToString() + " 的购买金额与实际票的金额不符合！！！！");

                    continue;
                }

                int TicketPlayTypeID = Tickets[0].PlayTypeID;

                string TicketXML = "<Tickets>";

                foreach (SLS.Lottery.Ticket ticket in Tickets)
                {
                    if (LotteryID == 72)
                    {
                        DataTable dtMatch = MSSQL.Select(ConnectionString, "select MatchID, Day, MatchNumber from T_PassRate union select MatchID, Day, MatchNumber from T_singleRate", null);

                        if (dtMatch == null)
                        {
                            log.Write("拆票错误(WriteTickets),赔率数据库未链接上。方案号：" + SchemeID.ToString() + "，");

                            break;
                        }

                        string[] Numbers = ticket.Number.Trim().Split(';');

                        if (Numbers.Length < 3)
                        {
                            log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                            break;
                        }

                        string Number = Numbers[1].Substring(1, Numbers[1].Length - 2);
                        string[] Match = Number.Split('|');

                        string MatchID = "";
                        string MatchResult = "";
                        string str_Number = "";
                        ticket.Number = "";

                        DataRow[] drMatch = null;

                        for (int i = 0; i < Match.Length; i++)
                        {
                            str_Number = "";

                            MatchID = Match[i].Substring(0, Match[i].IndexOf('('));
                            MatchResult = Match[i].Substring(Match[i].IndexOf('(') + 1, Match[i].IndexOf(')') - Match[i].IndexOf('(') - 1); 

                            drMatch = dtMatch.Select("MatchID=" + MatchID);

                            if (drMatch == null || drMatch.Length < 1)
                            {
                                break;
                            }

                            for (int j = 0; j < MatchResult.Split(',').Length; j++)
                            {
                                str_Number += GetSporttoryLotteryNumber(PlayTypeID, MatchResult.Split(',')[j].ToString());
                            }

                            ticket.Number += drMatch[0]["Day"].ToString() + "|" + GetDayFromWeek(drMatch[0]["MatchNumber"].ToString().Substring(0, 2)) + "|" + drMatch[0]["MatchNumber"].ToString().Substring(2, drMatch[0]["MatchNumber"].ToString().Length - 2) + "|" + str_Number + ("\n");
                        }
                    }
                    else if (LotteryID == 73)
                    {
                        DataTable dtMatch = MSSQL.Select(ConnectionString, "select MatchID, Day, MatchNumber from T_PassRateBasket union select MatchID, Day, MatchNumber from T_SingleRateBasket", null);

                        if (dtMatch == null)
                        {
                            log.Write("拆票错误(WriteTickets),赔率数据库未链接上。方案号：" + SchemeID.ToString() + "，");

                            break;
                        }

                        string[] Numbers = ticket.Number.Trim().Split(';');

                        if (Numbers.Length != 3)
                        {
                            log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                            break;
                        }

                        string Number = Numbers[1].Substring(1, Numbers[1].Length - 2);
                        string[] Match = Number.Split('|');

                        string MatchID = "";
                        string MatchResult = "";
                        string str_Number = "";
                        ticket.Number = "";

                        DataRow[] drMatch = null;

                        for (int i = 0; i < Match.Length; i++)
                        {
                            str_Number = "";

                            MatchID = Match[i].Substring(0, Match[i].IndexOf('('));
                            MatchResult = Match[i].Substring(Match[i].IndexOf('(') + 1, Match[i].IndexOf(')') - Match[i].IndexOf('(') - 1);

                            drMatch = dtMatch.Select("MatchID=" + MatchID);

                            if (drMatch == null || drMatch.Length < 1)
                            {
                                break;
                            }

                            for (int j = 0; j < MatchResult.Split(',').Length; j++)
                            {
                                str_Number += GetSporttoryLotteryNumber(PlayTypeID, MatchResult.Split(',')[j].ToString());
                            }

                            ticket.Number += drMatch[0]["Day"].ToString() + "|" + GetDayFromWeek(drMatch[0]["MatchNumber"].ToString().Substring(0, 2)) + "|" + drMatch[0]["MatchNumber"].ToString().Substring(2, drMatch[0]["MatchNumber"].ToString().Length - 2) + "|" + str_Number + ("\n");
                        }
                    }

                    if (ticket.Number.Trim() == "")
                    {
                        log.Write("拆票错误(WriteTickets)：方案号：" + SchemeID.ToString());

                        continue;
                    }

                    TicketXML += "<Ticket LotteryNumber=\"" + ticket.Number + "\" Multiple=\"" + ticket.Multiple + "\" Money=\"" + ticket.Money + "\" PlayTypeID=\"" + ticket.PlayTypeID.ToString() + "\"/>";
                }

                TicketXML += "</Tickets>";

                int ReturnValue = 0;
                string ReturnDescription = "";

                int Result = DAL.Procedures.P_SchemesSendToCenterAdd(ConnectionString, SchemeID, TicketPlayTypeID, TicketXML, ref ReturnValue, ref ReturnDescription);

                if ((Result < 0) || (ReturnValue < 0))
                {
                    log.Write("票写入错误(WriteTickets)：方案号：" + SchemeID.ToString() + "，" + ReturnDescription);
                }
            }
        }

        // 发送代购电子票
        private void SendTickets() {
            DAL.Views.V_SchemesSendToCenter v_SchemesSendToCenter = new DAL.Views.V_SchemesSendToCenter();

            DataTable dt = v_SchemesSendToCenter.Open(ConnectionString, "distinct SchemeID, SiteID, UserType, Name, Email, Mobile", "Buyed = 0 and Sends < 99 and (HandleResult = 0) and LotteryID in (72, 73) and PrintOutType = 108", " UserType desc");

            if (dt == null || dt.Rows.Count <1) {
                return;
            }
            for (int i = 0; i < dt.Rows.Count; i++) {                 
                try {
                    System.Threading.ThreadPool.QueueUserWorkItem(SendSchemes, (object)dt.Rows[i]["SchemeID"].ToString());
                } catch ( Exception e) {
                    log.Write(e.Message);
                }
                System.Threading.Thread.Sleep(200); 
            }
        }

        #endregion

        public void SendSchemes(object schemeid) {

            if (schemeid == null || schemeid == DBNull.Value) return;
            
            string scheme = schemeid.ToString();
            log.Write("发送代购票 " + scheme);

            DAL.Views.V_SchemesSendToCenter v_SchemesSendToCenter = new DAL.Views.V_SchemesSendToCenter();
            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();
            DataTable dtScheme = null;
            DataTable dtSchemesSend = v_SchemesSendToCenter.Open(ConnectionString, "", "SchemeID= " + scheme + " and Buyed = 0 and Sends < 99 and HandleResult = 0 and (State = 4 or State = 1)", "");

            if (dtSchemesSend == null) {
                log.Write("发送代购票出错(SendTickets)：读取方案错误。方案号：" + scheme.ToString());
                return;
            }
            if (dtSchemesSend.Rows.Count < 1) {
                return;
            }
            string Sends = dtSchemesSend.Rows[0]["Sends"].ToString();

            string ticketid = "";
            string LotteryNumber = "";
            DateTime Now = DateTime.Now;

            int LotteryPlayTypeID = 0;
            int Price = 2;

            dtScheme = new DAL.Tables.T_Schemes().Open(ConnectionString, "PlayTypeID", "ID=" + scheme.ToString(), "");

            if (dtScheme == null) {
                return ;
            }
            if (dtScheme.Rows.Count != 1) {
                return;
            }
            LotteryPlayTypeID = Shove._Convert.StrToInt(dtScheme.Rows[0]["PlayTypeID"].ToString(), 0);

            if (LotteryPlayTypeID == 3903 || LotteryPlayTypeID == 3904) {
                Price = 3;
            }
            string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";

            if (LotteryPlayTypeID >= 7201 && LotteryPlayTypeID <= 7304) {
                Body += "<lotteryId>" + GetPlayName(LotteryPlayTypeID) + "</lotteryId><issue>1</issue>";
            } else {
                Body += "<lotteryId>" + GetGameName(int.Parse(dtSchemesSend.Rows[0]["LotteryID"].ToString())) + "</lotteryId><issue>" + dtSchemesSend.Rows[0]["IsuseName"].ToString() + "</issue>";
            }
            Body += "<records>";

            for (int j = 0; j < dtSchemesSend.Rows.Count; j++) {
                DataRow dr = dtSchemesSend.Rows[j];
                ticketid = dr["Identifiers"].ToString();
                Body += "<record>";
                Body += "<id>" + ticketid + "</id>";
                Body += "<lotterySaleId>" + dr["PlayTypeID"].ToString() + "</lotterySaleId>";
                Body += "<phone>" + ElectronTicket_PrintOut_Mobile + "</phone>";
                Body += "<idCard>" + ElectronTicket_PrintOut_IDCardNumber + "</idCard>";
                Body += "<code>";
                try {
                    LotteryNumber = dr["Ticket"].ToString();
                } catch {
                    continue;
                }
                string[] strs = LotteryNumber.Split('\n');
                foreach (string str in strs) {
                    if (str.Trim() == "") {
                        continue;
                    }
                    Body += str + "^";
                }

                Body += "</code>";
                Body += "<money>" + double.Parse(dr["Money"].ToString()).ToString("N").Replace(",", "").Replace(".", "") + "</money>";
                Body += "<timesCount>" + dr["Multiple"].ToString() + "</timesCount>";
                Body += "<issueCount>1</issueCount>";
                Body += "<investCount>" + (double.Parse(dr["Money"].ToString()) / (Price * Shove._Convert.StrToInt(dr["Multiple"].ToString(), 0))).ToString() + "</investCount>";

                if (Price == 3) {
                    Body += "<investType>1</investType>";
                } else {
                    Body += "<investType>0</investType>";
                }
                Body += "</record>";
            }

            Body += "</records></body>";
            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);
            // MessageID
            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMddHHmmssfff");

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1000</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1000").Write(Message);

            string ReceiveString = "";

            try {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                //WriteElectronTicketLog(false, "1000", ReceiveString);
            } catch (Exception e) {
                log.Write("电子票-1000 发送失败(SendTickets)。方案ID：" + scheme + " " + e.Message);
                return;
            }

            //if (MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set Sends = Sends + 1 where SchemeID = " + scheme) < 0) {
            //    log.Write("更新票发送状态时出错(SendTickets)。方案ID：" + scheme);
            //    return;
            //}

            if (ReceiveString.Length <= 10) {
                return;
            }
            //new Log("1000").Write(ReceiveString);
            System.Xml.XmlDocument XmlDoc = new XmlDocument();
            try {
                XmlDoc.Load(new StringReader(ReceiveString));
            } catch {
                return;
            }

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword);

            new Log("1000").Write(ReceiveString);
            //WriteElectronTicketLog(false, "1000", ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf("<records"), ReceiveString.LastIndexOf("</records>") - ReceiveString.IndexOf("<records")) + "</records>";

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null) {
                return;
            }
            if (ds.Tables.Count == 0) {
                return;
            }
            DataTable dtTicket = ds.Tables[0];

            if (dtTicket.Rows.Count < 1) {
                return;
            }

            string code = "";
            //string printResult = "";
            string identifier = string.Empty;

            for (int k = 0; k < dtTicket.Rows.Count; k++) {
                code = string.Empty;
                DataRow dr = dtTicket.Rows[k];
                code = dr["result"].ToString();
                //printResult = dr["printResult"].ToString();
                identifier = dr["id"].ToString();

                if (code == "0") {
                    //t_SchemesSendToCenter.HandleDateTime.Value = DateTime.Now.ToString();
                    //t_SchemesSendToCenter.Sends.Value = "223";//200023 已提交成功。
                    //t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = " + identifier);
                    MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set HandleDateTime = getdate(), Sends = 223  where Identifiers = '" + identifier +"';" );
                    continue;
                }
                //200003  投注序列号重复 已提交成功。
                if (code == "200003") {
                    //t_SchemesSendToCenter.HandleDateTime.Value = DateTime.Now.ToString();
                    //t_SchemesSendToCenter.Sends.Value = "223";//200023 已提交成功。
                    //t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = " + identifier);
                    //continue;
                    MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set HandleDateTime = getdate(), Sends = 223  where Identifiers = '" + identifier + "';");
                    continue;
                }
                if (code == "200014" || code == "200024") {
                    MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set HandleDateTime = null, Sends = 0 where Identifiers = '" + identifier + "';");
                    continue;
                }

                if ("100001 100002 100003 100004 200004 200006 200024 200025".IndexOf(code) >= 0)     // 重复发送的投注票
                {
                    continue;
                }

                t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToShort(code.Remove(1, 3), 1);
                long ResultUpdate = t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + identifier + "';");
            }

        }

        #region 公共方法

        private string GetFromXPath(string XML, string XPath)
        {
            if (XML.Trim() == "")
                return "";

            string Result = "";
            try
            {
                XPathDocument doc = new XPathDocument(new StringReader(XML));
                XPathNavigator nav = doc.CreateNavigator();
                XPathNodeIterator nodes = nav.Select(XPath);
                while (nodes.MoveNext())
                    Result += nodes.Current.Value;
            }
            catch//(Exception ee)
            {
                return "";
                //return ee.Message;
            }

            return Result;
        }

        private string GetGameName(int LotteryID)
        {
            switch (LotteryID)
            {
                case 74:
                    return "D14";
                case 75:
                    return "D9";
                case 2:
                    return "C4";
                case 3:
                    return "D7";
                case 9:
                    return "C522";
                case 15:
                    return "C12";
                case 39:
                    return "T001";
                case 62:
                    return "C511";
                case 63:
                    return "D3";
                case 64:
                    return "D5";
                case 65:
                    return "C731";
                default:
                    return "";
            }
        }

        private string GetPlayName(int PlayTypeID)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    return "FT001";
                case 7202:
                    return "FT002";
                case 7203:
                    return "FT003";
                case 7204:
                    return "FT004";
                case 7301:
                    return "BSK001";
                case 7302:
                    return "BSK002";
                case 7303:
                    return "BSK003";
                case 7304:
                    return "BSK004";
                default:
                    return "";
            }
        }

        private string GetSporttoryLotteryNumber(int PlayTypeID, string Number)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    switch (Number)
                    {
                        case "1":
                            return "3";
                        case "2":
                            return "1";
                        case "3":
                            return "0";
                        default:
                            return "0";
                    }
                case 7202:
                    switch (Number)
                    {
                        case "10":
                            return "50";
                        case "11":
                            return "51";
                        case "12":
                            return "52";
                        case "13":
                            return "90";
                        case "14":
                            return "00";
                        case "15":
                            return "11";
                        case "16":
                            return "22";
                        case "17":
                            return "33";
                        case "18":
                            return "99";
                        case "19":
                            return "01";
                        case "20":
                            return "02";
                        case "21":
                            return "12";
                        case "22":
                            return "03";
                        case "23":
                            return "13";
                        case "24":
                            return "23";
                        case "25":
                            return "04";
                        case "26":
                            return "14";
                        case "27":
                            return "24";
                        case "28":
                            return "05";
                        case "29":
                            return "15";
                        case "30":
                            return "25";
                        case "31":
                            return "09";
                        case "1":
                            return "10";
                        case "2":
                            return "20";
                        case "3":
                            return "21";
                        case "4":
                            return "30";
                        case "5":
                            return "31";
                        case "6":
                            return "32";
                        case "7":
                            return "40";
                        case "8":
                            return "41";
                        case "9":
                            return "42";
                        default:
                            return "";
                    }
                case 7203:
                    switch (Number)
                    {
                        case "1":
                            return "0";
                        case "2":
                            return "1";
                        case "3":
                            return "2";
                        case "4":
                            return "3";
                        case "5":
                            return "4";
                        case "6":
                            return "5";
                        case "7":
                            return "6";
                        case "8":
                            return "7";
                        default:
                            return "";
                    }
                case 7204:
                    switch (Number)
                    {
                        case "1":
                            return "33";
                        case "2":
                            return "31";
                        case "3":
                            return "30";
                        case "4":
                            return "13";
                        case "5":
                            return "11";
                        case "6":
                            return "10";
                        case "7":
                            return "03";
                        case "8":
                            return "01";
                        case "9":
                            return "00";
                        default:
                            return "";
                    }
                case 7301:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7302:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7303:
                    switch (Number)
                    {
                        #region
                        /*#interface Define
                            01 -->  主胜1-5
                            02 -->  主胜6-10
                            03 -->  主胜11-15
                            04 -->  主胜16-20
                            05 -->  主胜21-25
                            06 -->  主胜26+
                            11 -->  客胜1-5
                            12 -->  客胜6-10
                            13 -->  客胜11-15
                            14 -->  客胜16-20
                            15 -->  客胜21-25
                            16 -->  客胜26+


                            #my Define
                            1 -->    客胜1-5
                            2 -->   主胜1-5
                            3 -->    客胜6-10
                            4 -->   主胜6-10
                            5 -->    客胜11-15
                            6 -->   主胜11-15
                            7 -->    客胜16-20
                            8 -->   主胜16-20
                            9 -->    客胜21-25
                            10 -->   主胜21-25
                            11 -->    客胜26+
                            12 -->   主胜26+
                         */
                        #endregion
                        case "12": /*主胜26+*/
                            return "06";
                        case "11": /*客胜26+*/
                            return "16";
                        case "10": /*主胜21-25*/
                            return "05";
                        case "9": /*客胜21-25*/
                            return "15";
                        case "8": /*主胜16-20*/
                            return "04";
                        case "7": /*客胜16-20*/
                            return "14";
                        case "6": /*主胜11-15*/
                            return "03";
                        case "5": /*客胜11-15*/
                            return "13";
                        case "4": /*主胜6-10*/
                            return "02";
                        case "3": /*客胜6-10*/
                            return "12";
                        case "2": /*主胜1-5*/
                            return "01";
                        case "1": /*客胜1-5*/
                            return "11";
                        default:
                            return "01";
                    }
                case 7304:
                    return Number;
                default:
                    return "";
            }
        }
        private int GetLotteryID(string gameName)
        {
            switch (gameName)
            {
                case "D14":
                    return 74;
                case "D9":
                    return 75;
                case "C4":
                    return 2;
                case "D7":
                    return 3;
                case "C522":
                    return 9;
                case "C12":
                    return 15;
                case "T001":
                    return 39;
                case "C511":
                    return 62;
                case "D3":
                    return 63;
                case "D5":
                    return 64;
                case "C731":
                    return 65;
                default:
                    return -1;
            }
        }

        //写日志文件
        public void WriteElectronTicketLog(bool isSend, string TransType, string TransMessage)
        {
            log.Write("isSend: " + isSend.ToString() + "\tTransType: " + TransType + "\t" + TransMessage);
        }

        private string GetWeekDescprtion(string Day)
        {
            switch (Day)
            {
                case "1":
                    return "周一";
                case "2":
                    return "周二";
                case "3":
                    return "周三";
                case "4":
                    return "周四";
                case "5":
                    return "周五";
                case "6":
                    return "周六";
                case "7":
                    return "周日";
                default:
                    return "";

            }

        }

        private string GetDayFromWeek(string Day)
        {
            switch (Day)
            {
                case "周一":
                    return "1";
                case "周二":
                    return "2";
                case "周三":
                    return "3";
                case "周四":
                    return "4";
                case "周五":
                    return "5";
                case "周六":
                    return "6";
                case "周日":
                    return "7";
                default:
                    return "";

            }

        }

        #endregion

        #region 分析中奖描述、奖等

        private class CompareToLength : IComparer
        {
            int IComparer.Compare(Object x, Object y)
            {
                long _x = Shove._Convert.StrToLong(x.ToString(), -1);
                long _y = Shove._Convert.StrToLong(y.ToString(), -1);

                return _x.CompareTo(_y);
            }
        }

        private string GetWinNumber(int LotteryID, string WinNumber)
        {
            switch (LotteryID)
            {
                case 5:
                    return WinNumber.Replace(",", " ").Insert(12, " +").Insert(10, " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 6:
                    return WinNumber.Replace(",", "");
                case 13:
                    return WinNumber.Replace(",", " ").Replace("#", " + ");
                case 29:
                    return WinNumber.Replace(",", "");
                case 58:
                    return WinNumber.Replace(",", "").Replace("#01", "+鼠").Replace("#02", "+牛").Replace("#03", "+虎").Replace("#04", "+兔").Replace("#05", "+龙").Replace("#06", "+蛇").Replace("#07", "+马").Replace("#08", "+羊").Replace("#09", "+猴").Replace("#10", "+鸡").Replace("#11", "+狗").Replace("#12", "+猪");
                case 59:
                    return WinNumber.Replace(",", " ").Replace("#", " ");
                case 60:
                    return WinNumber.Replace(",", "");
                case 3:
                    return WinNumber.Replace(",", "");
                case 9:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 65:
                    return WinNumber.Replace(",", " ").Insert(13, " ").Insert(11, "+ ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 39:
                    return WinNumber.Replace(" ", "+").Insert(13, " ").Replace("+", " + ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 1:
                    return WinNumber.Replace(",", "");
                case 2:
                    return WinNumber.Replace(",", "");
                case 15:
                    return WinNumber.Replace(",", "").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 62:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 63:
                    return WinNumber.Replace(",", "");
                case 64:
                    return WinNumber.Replace(",", "").Replace("#", " + ");
                default:
                    return WinNumber;
            }
        }

        #endregion
    }
}