﻿using System;
using System.Data;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Text;

using System.Linq;

using Shove.Database;
using SLS.Cttcsd.Task.Helper;

namespace SLS.Cttcsd.Task
{
    /// <summary>
    /// HPSH 的摘要说明
    /// </summary>
    public class ElectronTicket_CTTCSD
    {
        private const int TimeoutSeconds = 90;

        private long gCount1 = 0;
        private long gCount2 = 0;
        private long gCount3 = 0;
        private long gCount4 = 0;
        private long gCount5 = 0;
        private long gCount6 = 0;

        private System.Threading.Thread thread;

        private string ConnectionString;

        private Log log = new Log("ElectronTicket_CTTCSD");

        public int State = 0;   // 0 停止 1 运行中 2 置为停止

        public string ElectronTicket_CTTCSD_UserName;
        public string ElectronTicket_CTTCSD_UserPassword;
        public string ElectronTicket_CTTCSD_Getway;
        public string ElectronTicket_CTTCSD_DownloadGetway;

        public string ElectronTicket_PrintOut_IDCardNumber;
        public string ElectronTicket_PrintOut_Mobile;

        public ElectronTicket_CTTCSD(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public void Run()
        {
            SystemOptions so = new SystemOptions(ConnectionString);

            if (!so["ElectronTicket_CTTCSD_Status_ON"].ToBoolean(false))
            {
                return;
            }

            if ((ElectronTicket_CTTCSD_Getway == "") || (ElectronTicket_CTTCSD_UserName == "") || (ElectronTicket_CTTCSD_UserPassword == ""))
            {
                log.Write("ElectronTicket_CTTCSD Task 参数配置不完整.");

                return;
            }

            // 已经启动
            if (State == 1)
            {
                return;
            }

            lock (this) // 确保临界区被一个 Thread 所占用
            {
                State = 1;

                gCount1 = 0;
                gCount2 = 0;
                gCount3 = 0;
                gCount4 = 0;
                gCount5 = 0;

                thread = new System.Threading.Thread(new System.Threading.ThreadStart(Do));
                thread.IsBackground = true;

                thread.Start();

                log.Write("ElectronTicket_CTTCSD Task Start.");
            }
        }

        public void Exit()
        {
            State = 2;
        }

        public void Do()
        {
            while (true)
            {
                if (State == 2)
                {
                    log.Write("ElectronTicket_CTTCSD Task Stop.");

                    State = 0;

                    Stop();

                    return;
                }

                System.Threading.Thread.Sleep(1000);   // 1秒为单位

                gCount1++;
                gCount2++;
                gCount3++;
                gCount4++;
                gCount5++;
                gCount6++;

                #region 20 秒，发送电子票数据

                if (gCount1 >= 20 * 1)
                {
                    gCount1 = 0;

                    try
                    {
                        //WriteTickets();             // 满员方案拆分为票
                        //log.Write("WriteTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("WriteTickets is Fail: " + e.Message);
                    }

                    try
                    {
                        //SendTickets();              // 发送代购电子票

                        //log.Write("SendTickets ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("SendTickets is Fail: " + e.Message);
                    }
                }

                #endregion
                
                #region 2 分钟，查询奖期状态

                if (gCount2 >= 60 * 2)
                {
                    gCount2 = 0;

                    try
                    {
                        //QueryIsuseState();      // 查询奖期状态

                        log.Write("QueryIsuseState ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("QueryIsuseState is Fail: " + e.Message);
                    }
                }

                #endregion

                #region 5分钟 票查询
                if (gCount5 >= 60 * 5)
                {
                    gCount5 = 0;

                    try
                    {
                        //QueryTickets();             // 代购票查询
                    }
                    catch (Exception ex)
                    {
                        log.Write("QueryTickets is Fail: " + ex.Message);
                    }
                }
                #endregion

                #region 2分钟 竞彩票查询
                if (gCount6 >= 60 * 2)
                {
                    gCount6 = 0;
                    try
                    {
                        QueryTicketsSports();   // 竞彩票查询(竞彩)
                        log.Write("QueryTicketsSports ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("QueryTicketsSports is Fail: " + e.Message);
                    }
                }
                #endregion

                #region 20 分钟，开奖查询

                if (gCount3 >= 60 * 20)
                {
                    gCount3 = 0;
                    /**
                    try
                    {
                        QueryIsuseOpen();      // 查询奖期开奖结果

                        log.Write("QueryIsuseOpen ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("QueryIsuseOpen is Fail: " + e.Message);
                    }

                    try
                    {
                        QueryReconciliation();  //查询开奖信息

                        log.Write("QueryReconciliation ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("QueryReconciliation is Fail: " + e.Message);
                    }

                    try
                    {
                        GetIsuseInfo();

                        log.Write("GetIsuseInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetIsuseInfo is Fail: " + e.Message);
                    }

                    try
                    {
                        GetIsuseAwardInfo();

                        log.Write("GetIsuseAwardInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetIsuseAwardInfo is Fail: " + e.Message);
                    }
                     * **/
                }

                #endregion
                 
            }
        }

        private void Stop()
        {
            if (thread != null)
            {
                thread.Abort();
                thread = null;
            }
        }

        #region 定时器执行的事件

        // 满员方案拆分为票
        private void WriteTickets()
        {
            /// Loong Update Date: 2011-12-20
            /// 注解：方案进度未到100, 使用保底补上, 处理方案进度加保底大于100的方案
            string condition = @"Buyed = 0 and (GetDate() between StartTime and EndTime) 
                and isnull(Identifiers, '') = '' and PrintOutType = 108 and (State = 4 or State = 1 or State  = 0) 
                and dateadd(mi, 1, StateUpdateTime) <= GetDate() and LotteryNumber <> '' 
                and ((AssureMoney / (Money / Share)) + BuyedShare) >= Share"; /* 购买份数未达到总份数, 使用保底补上*/

            DataTable dt = new DAL.Views.V_SchemeSchedules().Open(ConnectionString, "ID, LotteryID, PlayTypeID, LotteryNumber, Multiple, Money", condition, "[ID]");

            if (dt == null)
            {
                log.Write("读取方案错误(WriteTickets)。");

                return;
            }

            DAL.Tables.T_Schemes t_Schemes = new DAL.Tables.T_Schemes();

            foreach (DataRow dr in dt.Rows)
            {
                long SchemeID = Shove._Convert.StrToLong(dr["ID"].ToString(), -1);
                int LotteryID = Shove._Convert.StrToInt(dr["LotteryID"].ToString(), -1);
                string LotterNumber = dr["LotteryNumber"].ToString();
                int PlayTypeID = Shove._Convert.StrToInt(dr["PlayTypeID"].ToString(), -1);
                int Multiple = Shove._Convert.StrToInt(dr["Multiple"].ToString(), -1);

                if ((SchemeID < 0) || (LotteryID < 0) || (PlayTypeID < 0) || (Multiple < 1))
                {
                    log.Write("读取方案错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                double Money = 0;
                SLS.Lottery.Ticket[] Tickets = null;

                try
                {
                    Tickets = new SLS.Lottery()[LotteryID].ToElectronicTicket_CTTCSD(PlayTypeID, LotterNumber.Trim(), Multiple, 99, ref Money);
                }
                catch (Exception e)
                {
                    log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString() + "，" + e.Message);

                    continue;
                }

                if (Tickets == null)
                {
                    log.Write("分解票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                    continue;
                }

                if (Money != Shove._Convert.StrToDouble(dr["Money"].ToString(), -1))
                {
                    log.Write("异常警告！！！！(WriteTickets)。方案号： " + SchemeID.ToString() + " 的购买金额与实际票的金额不符合！！！！");

                    continue;
                }

                int TicketPlayTypeID = Tickets[0].PlayTypeID;

                string TicketXML = "<Tickets>";

                foreach (SLS.Lottery.Ticket ticket in Tickets)
                {
                    if (LotteryID == 72)
                    {
                        DataTable dtMatch = MSSQL.Select(ConnectionString, "select MatchID, Day, MatchNumber from T_PassRate union select MatchID, Day, MatchNumber from T_singleRate", null);

                        if (dtMatch == null)
                        {
                            log.Write("拆票错误(WriteTickets),赔率数据库未链接上。方案号：" + SchemeID.ToString() + "，");

                            break;
                        }

                        string[] Numbers = ticket.Number.Trim().Split(';');

                        if (Numbers.Length < 3)
                        {
                            log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                            break;
                        }

                        string Number = Numbers[1].Substring(1, Numbers[1].Length - 2);
                        string[] Match = Number.Split('|');

                        string MatchID = "";
                        string MatchResult = "";
                        string str_Number = "";
                        ticket.Number = "";

                        DataRow[] drMatch = null;

                        for (int i = 0; i < Match.Length; i++)
                        {
                            str_Number = "";

                            MatchID = Match[i].Substring(0, Match[i].IndexOf('('));
                            MatchResult = Match[i].Substring(Match[i].IndexOf('(') + 1, Match[i].IndexOf(')') - Match[i].IndexOf('(') - 1);

                            drMatch = dtMatch.Select("MatchID=" + MatchID);

                            if (drMatch == null || drMatch.Length < 1)
                            {
                                break;
                            }

                            for (int j = 0; j < MatchResult.Split(',').Length; j++)
                            {
                                str_Number += GetSporttoryLotteryNumber(PlayTypeID, MatchResult.Split(',')[j].ToString());
                            }

                            ticket.Number += drMatch[0]["Day"].ToString() + "|" + GetDayFromWeek(drMatch[0]["MatchNumber"].ToString().Substring(0, 2)) + "|" + drMatch[0]["MatchNumber"].ToString().Substring(2, drMatch[0]["MatchNumber"].ToString().Length - 2) + "|" + str_Number + ("\n");
                        }
                    }
                    else if (LotteryID == 73)
                    {
                        DataTable dtMatch = MSSQL.Select(ConnectionString, "select MatchID, Day, MatchNumber from T_PassRateBasket union select MatchID, Day, MatchNumber from T_SingleRateBasket", null);

                        if (dtMatch == null)
                        {
                            log.Write("拆票错误(WriteTickets),赔率数据库未链接上。方案号：" + SchemeID.ToString() + "，");

                            break;
                        }

                        string[] Numbers = ticket.Number.Trim().Split(';');

                        if (Numbers.Length != 3)
                        {
                            log.Write("拆票错误(WriteTickets)。方案号：" + SchemeID.ToString());

                            break;
                        }

                        string Number = Numbers[1].Substring(1, Numbers[1].Length - 2);
                        string[] Match = Number.Split('|');

                        string MatchID = "";
                        string MatchResult = "";
                        string str_Number = "";
                        ticket.Number = "";

                        DataRow[] drMatch = null;

                        for (int i = 0; i < Match.Length; i++)
                        {
                            str_Number = "";

                            MatchID = Match[i].Substring(0, Match[i].IndexOf('('));
                            MatchResult = Match[i].Substring(Match[i].IndexOf('(') + 1, Match[i].IndexOf(')') - Match[i].IndexOf('(') - 1);

                            drMatch = dtMatch.Select("MatchID=" + MatchID);

                            if (drMatch == null || drMatch.Length < 1)
                            {
                                break;
                            }

                            for (int j = 0; j < MatchResult.Split(',').Length; j++)
                            {
                                str_Number += GetSporttoryLotteryNumber(PlayTypeID, MatchResult.Split(',')[j].ToString());
                            }

                            ticket.Number += drMatch[0]["Day"].ToString() + "|" + GetDayFromWeek(drMatch[0]["MatchNumber"].ToString().Substring(0, 2)) + "|" + drMatch[0]["MatchNumber"].ToString().Substring(2, drMatch[0]["MatchNumber"].ToString().Length - 2) + "|" + str_Number + ("\n");
                        }
                    }

                    if (ticket.Number.Trim() == "")
                    {
                        log.Write("拆票错误(WriteTickets)：方案号：" + SchemeID.ToString());

                        continue;
                    }

                    TicketXML += "<Ticket LotteryNumber=\"" + ticket.Number + "\" Multiple=\"" + ticket.Multiple + "\" Money=\"" + ticket.Money + "\" PlayTypeID=\"" + ticket.PlayTypeID.ToString() + "\"/>";
                }

                TicketXML += "</Tickets>";

                int ReturnValue = 0;
                string ReturnDescription = "";

                int Result = DAL.Procedures.P_SchemesSendToCenterAdd(ConnectionString, SchemeID, TicketPlayTypeID, TicketXML, ref ReturnValue, ref ReturnDescription);

                if ((Result < 0) || (ReturnValue < 0))
                {
                    log.Write("票写入错误(WriteTickets)：方案号：" + SchemeID.ToString() + "，" + ReturnDescription);
                }
            }
        }

        // 代购票查询
        private void QueryTickets()
        {
            DataTable dt = new DAL.Views.V_SchemesSendToCenter().Open(ConnectionString, "distinct SchemeID", "(((Sends > 0) AND (Sends < 100))) AND (HandleResult = 0) AND (IsOpened = 0) and dateadd(mi, -600, EndTime) <= GetDate() and buyed = 0 and PrintOutType = 108", "");

            if (dt == null)
            {
                log.Write("查询代购票出错(QueryTickets)：读取未成功票错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            DataTable dtSchemesSendToCenter = null;

            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dtSchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter().Open(ConnectionString, "*", "schemeid=" + dt.Rows[i]["SchemeID"].ToString() + " and (Sends > 0) AND (Sends < 100) and HandleResult = 0", "");

                if (dtSchemesSendToCenter == null)
                {
                    continue;
                }

                if (dtSchemesSendToCenter.Rows.Count < 1)
                {
                    continue;
                }

                System.Threading.Thread.Sleep(1000);

                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><records>";

                int count = dtSchemesSendToCenter.Rows.Count;

                if (dtSchemesSendToCenter.Rows.Count > 50)
                {
                    count = 50;
                }

                for (int j = 0; j < count; j++)
                {
                    string ticketid = dtSchemesSendToCenter.Rows[j]["Identifiers"].ToString();
                    Body += "<record><id>" + ticketid + "</id></record>";
                }

                Body += "</records></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1003</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1003").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1003", ReceiveString);

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                ReceiveString = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                new Log("1003").Write(ReceiveString);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(ReceiveString));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[1];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                int ReturnValue = 0;
                string ReturnDescription = "";

                for (int k = 0; k < dtTicket.Rows.Count; k++)
                {
                    DataRow dr = dtTicket.Rows[k];

                    string Identifiers = dr["id"].ToString();
                    string Status = dr["result"].ToString();

                    if (Status == "0")
                    {
                        int Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status, "", ref ReturnValue, ref ReturnDescription);

                        if ((Result < 0) || (ReturnValue < 0))
                        {
                            log.Write("对所查询到的电子票数据第一次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);

                            System.Threading.Thread.Sleep(1000);

                            ReturnValue = 0;
                            ReturnDescription = "";

                            Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status, "", ref ReturnValue, ref ReturnDescription);

                            if ((Result < 0) || (ReturnValue < 0))
                            {
                                log.Write("对所查询到的电子票数据第二次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);
                            }
                        }

                        continue;
                    }

                    if ("100001 100002 100003 100004 100005 200001 200002 200003 200004 200005 200006 200007 200012 200013 200014 200015 200016 200017 200018 200019 200022 200023 200025".IndexOf(Status) >= 0)
                    {
                        t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToShort(Status.ToString().Remove(1, 3), 1);
                        t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + Identifiers + "'");

                        continue;
                    }

                    if (Status == "200008")
                    {
                        System.Threading.Thread.Sleep(1000);

                        continue;
                    }

                    if (Status == "200009")
                    {
                        t_SchemesSendToCenter.Sends.Value = "99";
                        t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + Identifiers + "'");

                        continue;
                    }

                    if (Status == "200024" || Status == "200011")
                    {
                        MSSQL.Select(ConnectionString, "update T_SchemesSendToCenter set HandleDateTime = null, Sends = 0 where Identifiers = '" + Identifiers + "'", new MSSQL.Parameter[0]);

                        continue;
                    }
                }
            }
        }

        /// <summary>
        ///  竞彩代购票查询
        /// </summary>
        private void QueryTicketsSports()
        {
            DataTable dt = new DAL.Views.V_SchemesSendToCenter().Open(ConnectionString, "distinct SchemeID", "( ((Sends > 0) AND (Sends < 100)) or Sends in(221,223) ) AND (HandleResult = 0) AND (IsOpened = 0) and buyed = 0 and PrintOutType = 108 and [DateTime] < DATEADD(MINUTE,-2,GETDATE())", "");

            if (dt == null)
            {
                log.Write("查询竞彩代购票出错(QueryTickets)：读取未成功票错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            DataTable dtSchemesSendToCenter = null;

            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dtSchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter().Open(ConnectionString, "*", "schemeid=" + dt.Rows[i]["SchemeID"].ToString() + " and ( ((Sends > 0) AND (Sends < 100)) or Sends in(221,223) ) and HandleResult = 0", "");

                if (dtSchemesSendToCenter == null)
                {
                    continue;
                }

                if (dtSchemesSendToCenter.Rows.Count < 1)
                {
                    continue;
                }

                System.Threading.Thread.Sleep(1000);

                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><records>";

                int count = dtSchemesSendToCenter.Rows.Count;

                if (dtSchemesSendToCenter.Rows.Count > 500)
                {
                    count = 500;
                }

                for (int j = 0; j < count; j++)
                {
                    string ticketid = dtSchemesSendToCenter.Rows[j]["Identifiers"].ToString();
                    Body += "<record><id>" + ticketid + "</id></record>";
                }

                Body += "</records></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1003</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1003").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1003", ReceiveString);

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                ReceiveString = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                new Log("1003").Write(ReceiveString);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(ReceiveString));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[1];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                int ReturnValue = 0;
                string ReturnDescription = "";

                for (int k = 0; k < dtTicket.Rows.Count; k++)
                {
                    DataRow dr = dtTicket.Rows[k];

                    string Identifiers = dr["id"].ToString();
                    string Status = dr["result"].ToString();

                    if (Status == "0")
                    {
                        int Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status, "", ref ReturnValue, ref ReturnDescription);

                        if ((Result < 0) || (ReturnValue < 0))
                        {
                            log.Write("对所查询到的电子票数据第一次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);

                            System.Threading.Thread.Sleep(1000);

                            ReturnValue = 0;
                            ReturnDescription = "";

                            Result = DAL.Procedures.P_SchemesSendToCenterHandle(ConnectionString, Identifiers, DateTime.Now, true, Status, "", ref ReturnValue, ref ReturnDescription);

                            if ((Result < 0) || (ReturnValue < 0))
                            {
                                log.Write("对所查询到的电子票数据第二次处理出错(QueryTickets)：数据读写错误。票号：" + Identifiers + "，" + ReturnDescription);
                            }
                        }

                        continue;
                    }

                    if ("100005 200005 200007 200011 200012 200013 200015 200016 200017 200018 200019 200020 200021 200022".IndexOf(Status) >= 0)
                    {
                        t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToShort(Status.ToString().Remove(1, 3), 1);
                        t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + Identifiers + "'");

                        continue;
                    }

                    if (Status == "200008")
                    {
                        System.Threading.Thread.Sleep(1000);

                        continue;
                    }

                    if (Status == "200009")
                    {
                        t_SchemesSendToCenter.Sends.Value = "99";
                        t_SchemesSendToCenter.Update(ConnectionString, "Identifiers = '" + Identifiers + "'");

                        continue;
                    }
                    if (Status == "200014" || Status == "200024" || Status == "200010")
                    {
                        MSSQL.Select(ConnectionString, "update T_SchemesSendToCenter set HandleDateTime = null, Sends = 0 where Identifiers = '" + Identifiers + "'", new MSSQL.Parameter[0]);

                        continue;
                    }
                }
            }
        }

        // 发送代购电子票
        private void SendTickets()
        {
            //周六周日全天送票，其它 23~24,0~9 点不送票。
            //if (
            //    DateTime.Now.DayOfWeek != DayOfWeek.Saturday
            //    && DateTime.Now.DayOfWeek != DayOfWeek.Sunday
            //    && (DateTime.Now.Hour > 23 || DateTime.Now.Hour < 9)
            //    )
            //    return;

            DAL.Views.V_SchemesSendToCenter v_SchemesSendToCenter = new DAL.Views.V_SchemesSendToCenter();

            DataTable dt = v_SchemesSendToCenter.Open(ConnectionString, "distinct SchemeID, SiteID, UserType, Name, Email, Mobile", "Buyed = 0 and (GetDate() > StartTime) and Sends < 99 and (HandleResult = 0) and (State = 4 or State = 1 or (State = 0 and LotteryID in (72, 73))) and isnull(HandleDateTime, '') = '' and PrintOutType = 108", " UserType desc");

            if (dt == null)
            {
                log.Write("发送代购票出错(SendTickets)：读取方案错误。");

                return;
            }

            DAL.Tables.T_SchemesSendToCenter t_SchemesSendToCenter = new DAL.Tables.T_SchemesSendToCenter();

            DataTable dtScheme = null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                DataTable dtSchemesSend = v_SchemesSendToCenter.Open(ConnectionString, "", "SchemeID=" + dt.Rows[i]["SchemeID"].ToString() + " and Buyed = 0 and Sends < 99 and HandleResult = 0 and (State = 4 or State = 1)", "");

                if (dtSchemesSend == null)
                {
                    log.Write("发送代购票出错(SendTickets)：读取方案错误。方案号：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (dtSchemesSend.Rows.Count < 1)
                {
                    continue;
                }

                string Sends = dtSchemesSend.Rows[0]["Sends"].ToString();

                string ticketid = "";
                string LotteryNumber = "";
                DateTime Now = DateTime.Now;

                int LotteryPlayTypeID = 0;
                int Price = 2;

                dtScheme = new DAL.Tables.T_Schemes().Open(ConnectionString, "PlayTypeID", "ID=" + dt.Rows[i]["SchemeID"].ToString(), "");

                if (dtScheme == null)
                {
                    continue;
                }

                if (dtScheme.Rows.Count != 1)
                {
                    continue;
                }

                LotteryPlayTypeID = Shove._Convert.StrToInt(dtScheme.Rows[0]["PlayTypeID"].ToString(), 0);

                if (LotteryPlayTypeID == 3903 || LotteryPlayTypeID == 3904)
                {
                    Price = 3;
                }

                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";

                if (LotteryPlayTypeID >= 7201 && LotteryPlayTypeID <= 7304)
                {
                    Body += "<lotteryId>" + GetPlayName(LotteryPlayTypeID) + "</lotteryId><issue>1</issue>";
                }
                else
                {
                    Body += "<lotteryId>" + GetGameName(int.Parse(dtSchemesSend.Rows[0]["LotteryID"].ToString())) + "</lotteryId><issue>" + dtSchemesSend.Rows[0]["IsuseName"].ToString() + "</issue>";
                }

                Body += "<records>";

                for (int j = 0; j < dtSchemesSend.Rows.Count; j++)
                {
                    DataRow dr = dtSchemesSend.Rows[j];

                    ticketid = dr["Identifiers"].ToString();

                    Body += "<record>";
                    Body += "<id>" + ticketid + "</id>";
                    Body += "<lotterySaleId>" + dr["PlayTypeID"].ToString() + "</lotterySaleId>";
                    Body += "<phone>" + ElectronTicket_PrintOut_Mobile + "</phone>";
                    Body += "<idCard>" + ElectronTicket_PrintOut_IDCardNumber + "</idCard>";
                    Body += "<code>";

                    try
                    {
                        LotteryNumber = dr["Ticket"].ToString();
                    }
                    catch
                    {
                        continue;
                    }

                    string[] strs = LotteryNumber.Split('\n');

                    foreach (string str in strs)
                    {
                        if (str.Trim() == "")
                        {
                            continue;
                        }

                        Body += str + "^";
                    }

                    Body += "</code>";
                    Body += "<money>" + double.Parse(dr["Money"].ToString()).ToString("N").Replace(",", "").Replace(".", "") + "</money>";
                    Body += "<timesCount>" + dr["Multiple"].ToString() + "</timesCount>";
                    Body += "<issueCount>1</issueCount>";
                    Body += "<investCount>" + (double.Parse(dr["Money"].ToString()) / (Price * Shove._Convert.StrToInt(dr["Multiple"].ToString(), 0))).ToString() + "</investCount>";

                    if (Price == 3)
                    {
                        Body += "<investType>1</investType>";
                    }
                    else
                    {
                        Body += "<investType>0</investType>";
                    }

                    Body += "</record>";
                }

                Body += "</records></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);
                // MessageID
                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1000</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                //new Log("1000").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);

                    //WriteElectronTicketLog(false, "1000", ReceiveString);
                }
                catch
                {
                    log.Write("电子票-1000 发送失败(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (MSSQL.ExecuteNonQuery(ConnectionString, "update T_SchemesSendToCenter set Sends = Sends + 1 where SchemeID = " + dt.Rows[i]["SchemeID"].ToString()) < 0)
                {
                    log.Write("更新票发送状态时出错(SendTickets)。方案ID：" + dt.Rows[i]["SchemeID"].ToString());

                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                //new Log("1000").Write(ReceiveString);

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword);

                new Log("1000").Write(ReceiveString);
                //WriteElectronTicketLog(false, "1000", ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf("<records"), ReceiveString.LastIndexOf("</records>") - ReceiveString.IndexOf("<records")) + "</records>";

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtTicket = ds.Tables[0];

                if (dtTicket.Rows.Count < 1)
                {
                    return;
                }

                string code = "";
                string printResult = "";

                int ReturnValue = 0;
                string ReturnDescription = "";

                for (int k = 0; k < dtTicket.Rows.Count; k++)
                {
                    DataRow dr = dtTicket.Rows[k];

                    code = dr["result"].ToString();
                    printResult = dr["printResult"].ToString();

                    if (code == "0")
                    {
                        t_SchemesSendToCenter.HandleDateTime.Value = DateTime.Now.ToString();
                        t_SchemesSendToCenter.Update(ConnectionString, "SchemeID = " + dt.Rows[i]["SchemeID"].ToString());

                        continue;
                    }

                    int State = 0;
                    int SiteID = Shove._Convert.StrToInt(dt.Rows[i]["SiteID"].ToString(), 1);

                    try
                    {
                        State = int.Parse(code);
                    }
                    catch { }

                    if (code == "200009")     // 限号
                    {
                        if (Shove._Convert.StrToInt(Sends, 0) < 99)
                        {
                            t_SchemesSendToCenter.Sends.Value = 99;
                            t_SchemesSendToCenter.Update(ConnectionString, "SchemeID = " + dt.Rows[i]["SchemeID"].ToString());
                        }
                        else
                        {
                            int Result = DAL.Procedures.P_QuashScheme(ConnectionString, SiteID, Shove._Convert.StrToLong(dt.Rows[i]["SchemeID"].ToString(), 0), true, false, ref ReturnValue, ref ReturnDescription);

                            DAL.Tables.T_UserDetails t_UserDetails = new DAL.Tables.T_UserDetails();
                            t_UserDetails.Memo.Value = "限号撤单";
                            t_UserDetails.Update(ConnectionString, "SchemeID = " + dt.Rows[i]["SchemeID"].ToString() + " and OperatorType = 9");

                            if ((Result < 0) || (ReturnValue < 0))
                            {
                                log.Write("对所发送落地失败的代购票【作撤单】处理出错(SendTickets)：数据读写错误。票号：" + dt.Rows[i]["SchemeID"].ToString() + "，" + code + "，" + ReturnDescription);
                            }
                        }

                        continue;
                    }

                    if ("100001 100002 100003 100004 100005 200003 200004 200006 200014 200020 200023 200024 200011 200021".IndexOf(code) >= 0)     // 重复发送的投注票
                    {
                        continue;
                    }

                    t_SchemesSendToCenter.Sends.Value = Shove._Convert.StrToShort(State.ToString().Remove(1, 3), 1);
                    long ResultUpdate = t_SchemesSendToCenter.Update(ConnectionString, "SchemeID = " + dt.Rows[i]["SchemeID"].ToString());
                }
            }
        }

        // 查询奖期状态
        private void QueryIsuseState()
        {
            // 查询的几组条件说明：
            //  1 有效期内未开奖、未开启的
            //  2 已截止未开奖的
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "(State < 2 and (Getdate() between StartTime and EndTime) or (isOpened = 0 and Getdate() > EndTime and State <> 4)) and PrintOutType = 108 and Lotteryid <> 72 and LotteryID <> 73", "EndTime");

            if (dt == null)
            {
                log.Write("期号状态查询错误(QueryIsuseState)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                string LotteryName = GetGameName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = dt.Rows[i]["Name"].ToString();
                DateTime Now = DateTime.Now;

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><lotteryId>" + LotteryName + "</lotteryId><issue>" + IsuseName + "</issue></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1001</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1001").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1001", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1001").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtIsuses = ds.Tables[0];

                if (dtIsuses.Rows.Count < 1)
                {
                    return;
                }

                DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

                for (int k = 0; k < dtIsuses.Rows.Count; k++)
                {
                    LotteryName = dtIsuses.Rows[k]["lotteryId"].ToString();
                    IsuseName = dtIsuses.Rows[k]["issue"].ToString();
                    string Status = dtIsuses.Rows[k]["status"].ToString();
                    int LotteryID = GetLotteryID(LotteryName);

                    if ((LotteryID < 0) || (String.IsNullOrEmpty(IsuseName)))
                    {
                        continue;
                    }

                    DataTable dtIsuse = t_Isuses.Open(ConnectionString, "ID, State", "LotteryID = " + LotteryID.ToString() + " and [Name] = '" + IsuseName + "'", "");

                    if ((dtIsuse == null) || (dtIsuse.Rows.Count < 1))
                    {
                        continue;
                    }

                    bool isHasUpdate = false;

                    if (dtIsuse.Rows[k]["State"].ToString() != Status)
                    {
                        t_Isuses.State.Value = Status;
                        t_Isuses.StateUpdateTime.Value = DateTime.Now;

                        isHasUpdate = true;
                    }

                    if (isHasUpdate)
                    {
                        t_Isuses.Update(ConnectionString, "LotteryID = " + LotteryID.ToString() + " and [Name] = '" + IsuseName + "'");
                    }

                    if (Shove._Convert.StrToInt(Status, 0) == 5)
                    {
                        int ReturnValue = 0;
                        string ReturnDescprtion = "";

                        if (DAL.Procedures.P_ElectronTicketAgentSchemeQuash(ConnectionString, Shove._Convert.StrToLong(dtIsuse.Rows[0]["ID"].ToString(), 0), ref ReturnValue, ref ReturnDescprtion) < 0)
                        {
                            log.Write("电子票方案撤单错误_P_ElectronTicketAgentSchemeQuash。");

                            continue;
                        }
                    }
                }

                #endregion
            }
        }

        // 查询开奖信息
        private void QueryIsuseOpen()
        {
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "IsOpened = 0 and State <> 3 and PrintOutType = 108  and Lotteryid not in (72, 73) and isnull(WinLotteryNumber, '') = ''", "EndTime");

            if (dt == null)
            {
                log.Write("电子票查询开奖出错(QueryIsuseOpen)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                DateTime Now = DateTime.Now;

                string IsuseID = dt.Rows[i]["ID"].ToString();
                string LotteryName = GetGameName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = dt.Rows[i]["Name"].ToString();

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><lotteryId>" + LotteryName + "</lotteryId><issue>" + IsuseName + "</issue></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1004</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1004").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1004", ReceiveString);

                GetSprize(IsuseID, ReceiveString);
            }
        }

        private void QueryReconciliation()
        {
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "IsOpened = 0 and Getdate() > EndTime and PrintOutType = 108 and isnull(WinLotteryNumber, '') <> '' and Lotteryid not in (72, 73)", "EndTime");

            if (dt == null)
            {
                log.Write("电子票查询开奖出错(QueryReconciliation)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                DateTime Now = DateTime.Now;

                string IsuseID = dt.Rows[i]["ID"].ToString();
                string LotteryName = GetGameName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = dt.Rows[i]["Name"].ToString();

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><checkType>1301</checkType><lotteryId>" + LotteryName + "</lotteryId><issue>" + IsuseName + "</issue><checkDay>" + Now.ToString("yyyyMMdd") + "</checkDay></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1012</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                WriteElectronTicketLog(true, "1012", "transType=1012&transMessage=" + Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1012", ReceiveString);

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                WriteElectronTicketLog(false, "1012", ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 1)
                {
                    return;
                }

                DataTable dtFile = ds.Tables[0];

                if (dtFile.Rows.Count < 1)
                {
                    return;
                }

                string BonusXML = "<Schemes>";
                string AgentBonusXML = "<Schemes>";

                foreach (DataRow dr in dtFile.Rows)
                {
                    string FileName = dr["fileName"].ToString();

                    if (string.IsNullOrEmpty(FileName))
                    {
                        break;
                    }

                    string DownLoadFileNameUrl = ElectronTicket_CTTCSD_DownloadGetway + "/" + ElectronTicket_CTTCSD_UserName + "/" + LotteryName + "/Award/" + FileName;

                    string Html = PublicFunction.GetHtml(DownLoadFileNameUrl, "utf-8", 120);

                    if (Html == "")
                    {
                        break;
                    }

                    if (Html.IndexOf("<body/>") >= 0)
                    {
                        break;
                    }

                    elements = Html.Substring(Html.IndexOf("<head>"), Html.LastIndexOf("</body>") - Html.IndexOf("<head>")) + "</body>";

                    DataSet ds1 = new DataSet();

                    ds1.ReadXml(new StringReader(Html));

                    if (ds1 == null)
                    {
                        break;
                    }

                    if (ds1.Tables.Count != 4)
                    {
                        break;
                    }

                    if (Shove._Security.Encrypt.MD5(elements).ToLower() != ds1.Tables[0].Rows[0]["sign"].ToString().ToLower())
                    {
                        break;
                    }

                    DataTable dtTicket = ds1.Tables[3];

                    if (dtTicket.Rows.Count < 1)
                    {
                        break;
                    }

                    int LotteryID = GetLotteryID(ds1.Tables[1].Rows[0]["lotteryId"].ToString());
                    string IssueName = ds1.Tables[1].Rows[0]["issue"].ToString();

                    string[] StrTickets = null;

                    DataTable dtTicketTemp = new DataTable();

                    dtTicketTemp.Columns.Add("ID", typeof(System.String));
                    dtTicketTemp.Columns.Add("AwardValue", typeof(System.String));

                    DataRow drTicketTemp = null;

                    foreach (DataRow drTicket in dtTicket.Rows)
                    {
                        StrTickets = drTicket[0].ToString().Split(',');

                        if (StrTickets.Length != 7)
                        {
                            continue;
                        }

                        drTicketTemp = dtTicketTemp.NewRow();

                        drTicketTemp["ID"] = StrTickets[0].ToString();
                        drTicketTemp["AwardValue"] = StrTickets[3].ToString().Insert(StrTickets[3].ToString().Length - 2, ".");

                        dtTicketTemp.Rows.Add(drTicketTemp);
                        dtTicketTemp.AcceptChanges();
                    }

                    DataTable dtSchemes = MSSQL.Select(ConnectionString, "SELECT SchemeID, SchemesMultiple as Multiple, Identifiers FROM V_SchemesSendToCenter WHERE (IsuseID = " + IsuseID + ")");

                    if (dtSchemes == null)
                    {
                        log.Write("电子票查询开奖出错(dtSchemes)。");

                        break;
                    }

                    try
                    {
                        var query1 = from NewDtTickets in dtTicketTemp.AsEnumerable()
                                     join NewdtScheme in dtSchemes.AsEnumerable()
                                     on NewDtTickets.Field<string>("ID") equals NewdtScheme.Field<string>("Identifiers")
                                     select new
                                     {
                                         ID = NewdtScheme.Field<long>("SchemeID"),
                                         Multiple = NewdtScheme.Field<int>("Multiple"),
                                         Bonus = Shove._Convert.StrToDouble(NewDtTickets.Field<string>("AwardValue"), 0)
                                     };

                        var query2 = from NewDt in query1.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into gg
                                     select new
                                     {
                                         ID = gg.Key.ID,
                                         Multiple = gg.Key.Multiple,
                                         Bonus = gg.Sum(NewDt => NewDt.Bonus)
                                     };

                        var query3 = from NewDt in query2.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into t_dtSchemes
                                     select new
                                     {
                                         SchemeID = t_dtSchemes.Key.ID,
                                         Multiple = t_dtSchemes.Key.Multiple,
                                         Bonus = t_dtSchemes.Sum(NewDt => NewDt.Bonus)
                                     };

                        foreach (var Scheme in query3)
                        {
                            BonusXML += "<Scheme SchemeID=\"" + Scheme.SchemeID.ToString() + "\" WinMoney=\"" + Scheme.Bonus.ToString() + "\" WinDescription=\"\" />";
                        }
                    }
                    catch
                    {
                        log.Write("电子票开奖，第 " + IsuseName + " 期详细中奖数据解析错误");

                        break;
                    }
                }

                BonusXML += "</Schemes>";
                AgentBonusXML += "</Schemes>";

                int ReturnValue = 0;
                string ReturnDescription = "";

                int Times = 0;
                int Result = -1;

                while ((Result < 0) && (Times < 5))
                {
                    ReturnValue = 0;
                    ReturnDescription = "";

                    Result = DAL.Procedures.P_ElectronTicketWin(ConnectionString, Shove._Convert.StrToLong(IsuseID, 0), BonusXML, AgentBonusXML, ref ReturnValue, ref ReturnDescription);

                    if (Result < 0)
                    {
                        log.Write("电子票第 " + (Times + 1).ToString() + " 次派奖出现错误(IsuseOpenNotice) 期号为: " + IsuseName + "，彩种为: " + LotteryName);
                        Times++;

                        if (Times < 5)
                        {
                            System.Threading.Thread.Sleep(10000);
                        }

                        continue;
                    }
                }

                if (ReturnValue < 0)
                {
                    new Log("ElectronTicket\\CTTCSD").Write("电子票派奖出现错误(QueryReconciliation) 期号为: " + IsuseName + "，彩种为: " + LotteryName + "，错误：" + ReturnDescription);

                    break;
                }
            }
        }

        private void GetSprize(string IsuseID, string Transmessage)
        {
            System.Xml.XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(new StringReader(Transmessage));

            string ReceiveString = PublicFunction.DecryptDES(Transmessage.Substring(Transmessage.IndexOf("<body>") + 6, Transmessage.LastIndexOf("</body>") - Transmessage.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1004").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count == 0)
            {
                return;
            }

            if (ds.Tables.Count < 1)
            {
                return;
            }

            DataTable dtLottery = ds.Tables[0];
            DataTable dtIssue = ds.Tables[1];

            DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

            string number = dtLottery.Rows[0]["issue"].ToString();
            string LotteryName = dtLottery.Rows[0]["lotteryId"].ToString();

            string BonusNumber = dtIssue.Rows[0]["baseCode"].ToString() + " " + dtIssue.Rows[0]["specialCode"].ToString();

            int LotteryID = GetLotteryID(LotteryName);

            DataTable dtIsuse = new DAL.Tables.T_Isuses().Open(ConnectionString, "", "[ID] = " + IsuseID + " and [Name] = '" + number + "' and LotteryID = " + LotteryID.ToString() + " and IsOpened = 0", "");

            if ((dtIsuse == null) || (dtIsuse.Rows.Count < 1))
            {
                return;
            }

            DAL.Tables.T_Isuses T_Isuses = new DAL.Tables.T_Isuses();

            T_Isuses.WinLotteryNumber.Value = GetWinNumber(LotteryID, BonusNumber);
            T_Isuses.OpenOperatorID.Value = 1;
            T_Isuses.Update(ConnectionString, "[ID] = " + IsuseID + " and [Name] = '" + number + "' and LotteryID = " + LotteryID.ToString());


            DAL.Tables.T_IsuseInfo t_IsuseInfo = new DAL.Tables.T_IsuseInfo();

            t_IsuseInfo.TotalSaleMoney.Value = Shove._Convert.StrToDouble(dtLottery.Rows[0]["totalSaleMoney"].ToString(), -1);
            t_IsuseInfo.PoolOut.Value = Shove._Convert.StrToDouble(dtLottery.Rows[0]["poolOut"].ToString(), -1);
            t_IsuseInfo.TotalAwardMoney.Value = Shove._Convert.StrToDouble(dtLottery.Rows[0]["totalAwardMoney"].ToString(), -1);
            t_IsuseInfo.TotalSaleMoneyLocal.Value = Shove._Convert.StrToDouble(dtLottery.Rows[0]["totalSaleMoneyLocal"].ToString(), -1);
            t_IsuseInfo.TotalAwardMoneyLocal.Value = Shove._Convert.StrToDouble(dtLottery.Rows[0]["totalAwardMoneyLocal"].ToString(), -1);
            t_IsuseInfo.IssueID.Value = Shove._Convert.StrToLong(IsuseID, -1);

            if (new DAL.Tables.T_IsuseInfo().GetCount(ConnectionString, "IssueID=" + IsuseID) < 1)
            {
                t_IsuseInfo.Insert(ConnectionString);
            }
            else
            {
                t_IsuseInfo.Update(ConnectionString);
            }
        }

        private void GetIsuseInfo()
        {
            // 查询的几组条件说明：
            //  1 有效期内未开奖、未开启的
            //  2 已截止未开奖的
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "PrintOutType = 108 and IsOpened = 0 and not exists (select 1 from T_IsuseInfo where T_IsuseInfo.IssueID = V_Isuses.ID and T_IsuseInfo.sum >= 0)  and Lotteryid <> 72 and LotteryId <> 73", "EndTime");

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetIsuseInfo)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                string LotteryName = GetGameName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = dt.Rows[i]["Name"].ToString();
                DateTime Now = DateTime.Now;

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><lotteryId>" + LotteryName + "</lotteryId><issue>" + IsuseName + "</issue></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1008</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1008").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1008", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1000").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtIsuses = ds.Tables[0];

                if (dtIsuses.Rows.Count < 1)
                {
                    return;
                }

                DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

                for (int k = 0; k < dtIsuses.Rows.Count; k++)
                {
                    int Result = Shove._Convert.StrToInt(dtIsuses.Rows[k]["result"].ToString(), -1);

                    if (Result != 0)
                    {
                        continue;
                    }

                    DAL.Tables.T_IsuseInfo t_IsuseInfo = new DAL.Tables.T_IsuseInfo();

                    t_IsuseInfo.Sum.Value = Shove._Convert.StrToDouble(dtIsuses.Rows[k]["sum"].ToString(), -1);

                    if (new DAL.Tables.T_IsuseInfo().GetCount(ConnectionString, "IssueID=" + dt.Rows[i]["ID"].ToString()) < 1)
                    {
                        t_IsuseInfo.Insert(ConnectionString);
                    }
                    else
                    {
                        t_IsuseInfo.Update(ConnectionString);
                    }
                }

                #endregion
            }
        }

        private void GetIsuseAwardInfo()
        {
            DataTable dt = new DAL.Views.V_Isuses().Open(ConnectionString, "[ID], LotteryID, [Name]", "PrintOutType = 108 and IsOpened = 0 and not exists (select 1 from T_IsuseInfo where T_IsuseInfo.IssueID = V_Isuses.ID and T_IsuseInfo.SmallAwardSum >= 0) and EndTime < GETDATE() and EndTime > '2010-12-18' and LotteryId not in (72, 73)", "EndTime");

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetIsuseAwardInf)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                string LotteryName = GetGameName(Shove._Convert.StrToInt(dt.Rows[i]["LotteryID"].ToString(), 0));
                string IsuseName = dt.Rows[i]["Name"].ToString();
                DateTime Now = DateTime.Now;

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><lotteryId>" + LotteryName + "</lotteryId><issue>" + IsuseName + "</issue></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1009</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1009").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1009", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1009").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtIsuses = ds.Tables[0];

                if (dtIsuses.Rows.Count < 1)
                {
                    return;
                }

                DAL.Tables.T_Isuses t_Isuses = new DAL.Tables.T_Isuses();

                for (int k = 0; k < dtIsuses.Rows.Count; k++)
                {
                    int Result = Shove._Convert.StrToInt(dtIsuses.Rows[k]["result"].ToString(), -1);

                    if (Result != 0)
                    {
                        continue;
                    }

                    DAL.Tables.T_IsuseInfo t_IsuseInfo = new DAL.Tables.T_IsuseInfo();

                    t_IsuseInfo.SmallAwardSum.Value = Shove._Convert.StrToDouble(dtIsuses.Rows[k]["smallAwardSum"].ToString(), -1);
                    t_IsuseInfo.BigAwardSum.Value = Shove._Convert.StrToDouble(dtIsuses.Rows[k]["bigAwardSum"].ToString(), -1);
                    t_IsuseInfo.TaxSum.Value = Shove._Convert.StrToDouble(dtIsuses.Rows[k]["taxSum"].ToString(), -1);

                    if (new DAL.Tables.T_IsuseInfo().GetCount(ConnectionString, "IssueID=" + dt.Rows[i]["ID"].ToString()) < 1)
                    {
                        t_IsuseInfo.Insert(ConnectionString);
                    }
                    else
                    {
                        t_IsuseInfo.Update(ConnectionString);
                    }
                }

                #endregion
            }
        }

        private void GetSporttoryAwardInfo()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select StopSellingTime, MatchNumber, ID from T_Match where IsOpened = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetSporttoryAwardInfo)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>1</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1016</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1016").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1016", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1016").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 2)
                {
                    continue;
                }

                DataTable dtFileName = ds.Tables[1];

                if (dtFileName.Rows.Count < 1)
                {
                    return;
                }

                foreach (DataRow dr in dtFileName.Rows)
                {
                    string ProcessState = dr["processState"].ToString();
                    string FileName = dr["fileName"].ToString();

                    if (ProcessState.Trim() == "0")
                    {
                        continue;
                    }

                    string DownLoadFileNameUrl = ElectronTicket_CTTCSD_DownloadGetway + "/" + ElectronTicket_CTTCSD_UserName + "/1/Award/" + FileName;

                    string Html = PublicFunction.GetHtml(DownLoadFileNameUrl, "utf-8", 120);

                    if (Html == "")
                    {
                        continue;
                    }

                    new Log("GetSporttoryAwardInfo").Write(Html);

                    if (Html.IndexOf("<body/>") >= 0)
                    {
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    elements = Html.Substring(Html.IndexOf("<head>"), Html.LastIndexOf("</body>") - Html.IndexOf("<head>")) + "</body>";

                    DataSet ds1 = new DataSet();

                    ds1.ReadXml(new StringReader(Html));

                    if (ds1 == null)
                    {
                        continue;
                    }

                    if (Shove._Security.Encrypt.MD5(elements).ToLower() != ds1.Tables[0].Rows[0]["sign"].ToString().ToLower())
                    {
                        continue;
                    }

                    DataTable dtTicket = ds1.Tables[ds1.Tables.Count - 1];

                    if (dtTicket.Rows.Count < 1)
                    {
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    string[] StrTickets = null;

                    DataTable dtTicketTemp = new DataTable();

                    dtTicketTemp.Columns.Add("ID", typeof(System.String));
                    dtTicketTemp.Columns.Add("AwardValue", typeof(System.String));

                    DataRow drTicketTemp = null;

                    foreach (DataRow drTicket in dtTicket.Rows)
                    {
                        StrTickets = drTicket[0].ToString().Split(',');

                        if (StrTickets.Length != 8)
                        {
                            continue;
                        }

                        drTicketTemp = dtTicketTemp.NewRow();

                        drTicketTemp["ID"] = StrTickets[0].ToString();
                        drTicketTemp["AwardValue"] = StrTickets[5].ToString().Insert(StrTickets[5].ToString().Length - 2, ".");

                        dtTicketTemp.Rows.Add(drTicketTemp);
                        dtTicketTemp.AcceptChanges();
                    }

                    DataTable dtSchemes = MSSQL.Select(ConnectionString, "SELECT SchemeID, SchemesMultiple as Multiple, Identifiers FROM V_SchemesSendToCenter where LotteryID = 72");

                    try
                    {
                        var query1 = from NewDtTickets in dtTicketTemp.AsEnumerable()
                                     join NewdtScheme in dtSchemes.AsEnumerable()
                                     on NewDtTickets.Field<string>("ID") equals NewdtScheme.Field<string>("Identifiers")
                                     select new
                                     {
                                         ID = NewdtScheme.Field<long>("SchemeID"),
                                         Multiple = NewdtScheme.Field<int>("Multiple"),
                                         Bonus = Shove._Convert.StrToDouble(NewDtTickets.Field<string>("AwardValue"), 0)
                                     };

                        var query2 = from NewDt in query1.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into gg
                                     select new
                                     {
                                         ID = gg.Key.ID,
                                         Multiple = gg.Key.Multiple,
                                         Bonus = gg.Sum(NewDt => NewDt.Bonus)
                                     };

                        var query3 = from NewDt in query2.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into t_dtSchemes
                                     select new
                                     {
                                         SchemeID = t_dtSchemes.Key.ID,
                                         Multiple = t_dtSchemes.Key.Multiple,
                                         Bonus = t_dtSchemes.Sum(NewDt => NewDt.Bonus)
                                     };

                        int ReturnValue = 0;
                        string ReturnDescription = "";

                        foreach (var Scheme in query3)
                        {
                            int Times = 0;
                            int Result = -1;

                            while ((Result < 0) && (Times < 5))
                            {
                                ReturnValue = 0;
                                ReturnDescription = "";

                                Result = DAL.Procedures.P_WinByOpenManual(ConnectionString, 1, Scheme.SchemeID, Scheme.Bonus, Scheme.Bonus, "", 1, ref ReturnValue, ref ReturnDescription);

                                if (Result < 0)
                                {
                                    new Log("ElectronTicket\\CTTCSD").Write("电子票第 " + (Times + 1).ToString() + " 次派奖出现错误(IsuseOpenNotice) 方案号为: " + Scheme.SchemeID.ToString() + "，彩种为: 竞彩");

                                    Times++;

                                    if (Times < 5)
                                    {
                                        System.Threading.Thread.Sleep(10000);
                                    }

                                    continue;
                                }
                            }

                            if (ReturnValue < 0)
                            {
                                new Log("ElectronTicket\\CTTCSD").Write("电子票第 " + (Times + 1).ToString() + " 次派奖出现错误(IsuseOpenNotice) 方案号为: " + Scheme.SchemeID.ToString() + "，彩种为: 竞彩");

                                continue;
                            }
                        }

                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);
                    }
                    catch (Exception e)
                    {
                        new Log("ElectronTicket\\CTTCSD").Write("电子票开奖，详细中奖数据解析错误：" + e.Message);

                        continue;
                    }

                }

                #endregion
            }
        }

        private void GetBasketballAwardInfo()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select * from T_MatchBasket where IsOpened = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetBasketballAwardInfo)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>0</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1016</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1016").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1016", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1016").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtFileName = ds.Tables[1];

                if (dtFileName.Rows.Count < 1)
                {
                    return;
                }

                foreach (DataRow dr in dtFileName.Rows)
                {
                    string ProcessState = dr["processState"].ToString();
                    string FileName = dr["fileName"].ToString();

                    if (ProcessState.Trim() == "0")
                    {
                        continue;
                    }

                    string DownLoadFileNameUrl = ElectronTicket_CTTCSD_DownloadGetway + "/" + ElectronTicket_CTTCSD_UserName + "/0/Award/" + FileName;

                    string Html = PublicFunction.GetHtml(DownLoadFileNameUrl, "utf-8", 120);

                    if (Html == "")
                    {
                        continue;
                    }

                    new Log("GetBasketballAwardInfo").Write(Html);

                    if (Html.IndexOf("<body/>") >= 0)
                    {
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    elements = Html.Substring(Html.IndexOf("<head>"), Html.LastIndexOf("</body>") - Html.IndexOf("<head>")) + "</body>";

                    DataSet ds1 = new DataSet();

                    ds1.ReadXml(new StringReader(Html));

                    if (ds1 == null)
                    {
                        continue;
                    }

                    if (Shove._Security.Encrypt.MD5(elements).ToLower() != ds1.Tables[0].Rows[0]["sign"].ToString().ToLower())
                    {
                        continue;
                    }

                    DataTable dtTicket = ds1.Tables[ds1.Tables.Count - 1];

                    if (dtTicket.Rows.Count < 1)
                    {
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    string[] StrTickets = null;

                    DataTable dtTicketTemp = new DataTable();

                    dtTicketTemp.Columns.Add("ID", typeof(System.String));
                    dtTicketTemp.Columns.Add("AwardValue", typeof(System.String));

                    DataRow drTicketTemp = null;

                    foreach (DataRow drTicket in dtTicket.Rows)
                    {
                        StrTickets = drTicket[0].ToString().Split(',');

                        if (StrTickets.Length != 8)
                        {
                            continue;
                        }

                        drTicketTemp = dtTicketTemp.NewRow();

                        drTicketTemp["ID"] = StrTickets[0].ToString();
                        drTicketTemp["AwardValue"] = StrTickets[5].ToString().Insert(StrTickets[5].ToString().Length - 2, ".");

                        dtTicketTemp.Rows.Add(drTicketTemp);
                        dtTicketTemp.AcceptChanges();
                    }

                    DataTable dtSchemes = MSSQL.Select(ConnectionString, "SELECT SchemeID, SchemesMultiple as Multiple, Identifiers FROM V_SchemesSendToCenter  where LotteryID = 73");

                    try
                    {
                        var query1 = from NewDtTickets in dtTicketTemp.AsEnumerable()
                                     join NewdtScheme in dtSchemes.AsEnumerable()
                                     on NewDtTickets.Field<string>("ID") equals NewdtScheme.Field<string>("Identifiers")
                                     select new
                                     {
                                         ID = NewdtScheme.Field<long>("SchemeID"),
                                         Multiple = NewdtScheme.Field<int>("Multiple"),
                                         Bonus = Shove._Convert.StrToDouble(NewDtTickets.Field<string>("AwardValue"), 0)
                                     };

                        var query2 = from NewDt in query1.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into gg
                                     select new
                                     {
                                         ID = gg.Key.ID,
                                         Multiple = gg.Key.Multiple,
                                         Bonus = gg.Sum(NewDt => NewDt.Bonus)
                                     };

                        var query3 = from NewDt in query2.AsQueryable()
                                     group NewDt by new { NewDt.ID, NewDt.Multiple } into t_dtSchemes
                                     select new
                                     {
                                         SchemeID = t_dtSchemes.Key.ID,
                                         Multiple = t_dtSchemes.Key.Multiple,
                                         Bonus = t_dtSchemes.Sum(NewDt => NewDt.Bonus)
                                     };

                        int ReturnValue = 0;
                        string ReturnDescription = "";

                        foreach (var Scheme in query3)
                        {
                            int Times = 0;
                            int Result = -1;

                            while ((Result < 0) && (Times < 5))
                            {
                                ReturnValue = 0;
                                ReturnDescription = "";

                                Result = DAL.Procedures.P_WinByOpenManual(ConnectionString, 1, Scheme.SchemeID, Scheme.Bonus, Scheme.Bonus, "", 1, ref ReturnValue, ref ReturnDescription);

                                if (Result < 0)
                                {
                                    new Log("ElectronTicket\\CTTCSD").Write("电子票第 " + (Times + 1).ToString() + " 次派奖出现错误(IsuseOpenNotice) 方案号为: " + Scheme.SchemeID.ToString() + "，彩种为: 竞彩");

                                    Times++;

                                    if (Times < 5)
                                    {
                                        System.Threading.Thread.Sleep(10000);
                                    }

                                    continue;
                                }
                            }

                            if (ReturnValue < 0)
                            {
                                new Log("ElectronTicket\\CTTCSD").Write("电子票第 " + (Times + 1).ToString() + " 次派奖出现错误(IsuseOpenNotice) 方案号为: " + Scheme.SchemeID.ToString() + "，彩种为: 竞彩");

                                continue;
                            }
                        }

                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);
                    }
                    catch (Exception e)
                    {
                        new Log("ElectronTicket\\CTTCSD").Write("电子票开奖，详细中奖数据解析错误：" + e.Message);

                        continue;
                    }

                }

                #endregion
            }
        }

        private void GetSportteryTeamInfo()
        {
            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>1</type></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1015</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1015").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1015", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1015").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 2)
            {
                return;
            }

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            string MatchNumber = "";
            string Game = "";
            string MainTeam = "";
            string GuestTeam = "";
            string Day = "";
            string SaleFlag = "";

            int orderby = 1;
            int Count = 0;

            DateTime stopselltime = DateTime.Now;
            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();
            StringBuilder sbSingleRate = new StringBuilder();

            for (int i = 0; i < dtTeamInfo.Rows.Count; i++)
            {
                DataRow dr = dtTeamInfo.Rows[i];

                SaleFlag = dr["saleFlag"].ToString();

                if (SaleFlag == "1")
                {
                    continue;
                }

                MatchNumber = GetWeekDescprtion(dr["weekId"].ToString()) + dr["teamId"].ToString();
                Game = dr["league"].ToString();
                stopselltime = Shove._Convert.StrToDateTime(dr["endTime"].ToString(), DateTime.Now.ToString());
                Day = dr["day"].ToString();

                try
                {
                    MainTeam = dr["team"].ToString().Split(':')[0];
                    GuestTeam = dr["team"].ToString().Split(':')[1];
                }
                catch
                {
                    continue;
                }

                sb.Append(" exec [pro_PassRateAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "'; ");
                sb.Append(" Update T_PassRate set IsHhad = 1,  IsCrs = 1, IsTtg = 1, IsHafu = 1 where MatchNumber='" + MatchNumber + "'; ");

                sbSingleRate.Append(" exec [pro_SingleRateAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "'; ");
                sbSingleRate.Append(" Update T_singleRate set IsHhad = 1,  IsCrs = 1, IsTtg = 1, IsHafu = 1 where MatchNumber='" + MatchNumber + "'; ");

                Count++;
            }

            if (ds.Tables.Count == 4)
            {
                string Condition = "";
                string Type = "";

                foreach (DataRow dr in ds.Tables[3].Rows)
                {
                    Type = dr["type"].ToString();

                    switch (dr["lotteryId"].ToString())
                    {
                        case "FT001":
                            Condition = " IsHhad = 0 ";

                            break;
                        case "FT002":
                            Condition = " IsCrs = 0 ";

                            break;
                        case "FT003":
                            Condition = " IsTtg = 0 ";

                            break;
                        case "FT004":
                            Condition = " IsHafu = 0 ";

                            break;
                        default:
                            break;
                    }

                    DataRow[] drTeamInfo = ds.Tables[1].Select("vs_Id=" + dr["unsupport_Id"].ToString());

                    if (dtTeamInfo.Rows.Count < 1)
                    {
                        continue;
                    }

                    if (Type == "1")
                    {
                        sb.Append(" Update T_PassRate set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                    else
                    {
                        sbSingleRate.Append(" Update T_singleRate set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                }
            }

            sb.Append(" delete T_PassRate where StopSellTime < dateadd(day, -4,getdate()); ");
            sbSingleRate.Append(" delete T_singleRate where StopSellTime < dateadd(day, -4,getdate()); ");

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            MSSQL.ExecuteNonQuery(ConnectionString, sbSingleRate.ToString(), null);
        }

        private void GetBasketballTeamInfo()
        {
            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>0</type></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1015</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1015").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1015", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1015").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 2)
            {
                return;
            }

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            string MatchNumber = "";
            string Game = "";
            string MainTeam = "";
            string GuestTeam = "";
            string Day = "";
            string SaleFlag = "";

            int orderby = 1;
            int Count = 0;

            DateTime stopselltime = DateTime.Now;
            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();
            StringBuilder sbSingleRate = new StringBuilder();

            for (int i = 0; i < dtTeamInfo.Rows.Count; i++)
            {
                DataRow dr = dtTeamInfo.Rows[i];

                SaleFlag = dr["saleFlag"].ToString();

                if (SaleFlag == "1")
                {
                    continue;
                }

                MatchNumber = GetWeekDescprtion(dr["weekId"].ToString()) + dr["teamId"].ToString();
                Game = dr["league"].ToString();
                stopselltime = Shove._Convert.StrToDateTime(dr["endTime"].ToString(), DateTime.Now.ToString());
                Day = dr["day"].ToString();

                try
                {
                    MainTeam = dr["team"].ToString().Split(':')[0];
                    GuestTeam = dr["team"].ToString().Split(':')[1];
                }
                catch
                {
                    continue;
                }

                sb.Append(" exec [pro_PassRateBasketAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "'; ");
                sbSingleRate.Append(" exec [pro_SingleRateBasketAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "'; ");

                Count++;
            }

            if (ds.Tables.Count == 4)
            {
                string Condition = "";
                string Type = "";

                foreach (DataRow dr in ds.Tables[3].Rows)
                {
                    Type = dr["type"].ToString();

                    switch (dr["lotteryId"].ToString())
                    {
                        case "BSK001":
                            Condition = " IsMnl = 0 ";

                            break;
                        case "BSK002":
                            Condition = " IsHdc = 0 ";

                            break;
                        case "BSK003":
                            Condition = " IsWnm = 0 ";

                            break;
                        case "BSK004":
                            Condition = " IsHilo = 0 ";

                            break;
                        default:
                            break;
                    }

                    DataRow[] drTeamInfo = ds.Tables[1].Select("vs_Id=" + dr["unsupport_Id"].ToString());

                    if (dtTeamInfo.Rows.Count < 1)
                    {
                        continue;
                    }

                    if (Type == "1")
                    {
                        sb.Append(" Update T_PassRateBasket set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                    else
                    {
                        sbSingleRate.Append(" Update T_SingleRateBasket set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                }
            }

            sb.Append(" delete T_PassRateBasket where StopSellTime < dateadd(day, -4,getdate()); ");
            sbSingleRate.Append(" delete T_SingleRateBasket where StopSellTime < dateadd(day, -4,getdate()); ");

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            MSSQL.ExecuteNonQuery(ConnectionString, sbSingleRate.ToString(), null);
        }

        private void GetSporttoryOddsPassRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_PassRate", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetSporttoryOdds)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>1</type>";
            Body += "<valueType>1</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";
            int MainLoseball = 0;

            string win = "";
            string flat = "";
            string lose = "";

            string S1_0 = "";
            string S2_0 = "";
            string S2_1 = "";
            string S3_0 = "";
            string S3_1 = "";
            string S3_2 = "";
            string S4_0 = "";
            string S4_1 = "";
            string S4_2 = "";
            string S5_0 = "";
            string S5_1 = "";
            string S5_2 = "";
            string SOther = "";
            string P0_0 = "";
            string P1_1 = "";
            string P2_2 = "";
            string P3_3 = "";
            string POther = "";
            string F0_1 = "";
            string F0_2 = "";
            string F1_2 = "";
            string F0_3 = "";
            string F1_3 = "";
            string F2_3 = "";
            string F0_4 = "";
            string F1_4 = "";
            string F2_4 = "";
            string F0_5 = "";
            string F1_5 = "";
            string F2_5 = "";
            string FOther = "";

            string in0 = "";
            string in1 = "";
            string in2 = "";
            string in3 = "";
            string in4 = "";
            string in5 = "";
            string in6 = "";
            string in7 = "";

            string SS = "";
            string SP = "";
            string SF = "";
            string PS = "";
            string PP = "";
            string PF = "";
            string FS = "";
            string FP = "";
            string FF = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainLoseball = Shove._Convert.StrToInt(dtVS.Rows[i]["letPoint"].ToString(), 0);
                win = dtVS.Rows[i]["v3"].ToString();
                flat = dtVS.Rows[i]["v1"].ToString();
                lose = dtVS.Rows[i]["v0"].ToString();

                S1_0 = dtScore.Rows[i]["v10"].ToString();
                S2_0 = dtScore.Rows[i]["v20"].ToString();
                S2_1 = dtScore.Rows[i]["v21"].ToString();
                S3_0 = dtScore.Rows[i]["v30"].ToString();
                S3_1 = dtScore.Rows[i]["v31"].ToString();
                S3_2 = dtScore.Rows[i]["v32"].ToString();
                S4_0 = dtScore.Rows[i]["v40"].ToString();
                S4_1 = dtScore.Rows[i]["v41"].ToString();
                S4_2 = dtScore.Rows[i]["v42"].ToString();
                S5_0 = dtScore.Rows[i]["v50"].ToString();
                S5_1 = dtScore.Rows[i]["v51"].ToString();
                S5_2 = dtScore.Rows[i]["v52"].ToString();
                SOther = dtScore.Rows[i]["v90"].ToString();
                P0_0 = dtScore.Rows[i]["v00"].ToString();
                P1_1 = dtScore.Rows[i]["v11"].ToString();
                P2_2 = dtScore.Rows[i]["v22"].ToString();
                P3_3 = dtScore.Rows[i]["v33"].ToString();
                POther = dtScore.Rows[i]["v99"].ToString();
                F0_1 = dtScore.Rows[i]["v01"].ToString();
                F0_2 = dtScore.Rows[i]["v02"].ToString();
                F1_2 = dtScore.Rows[i]["v12"].ToString();
                F0_3 = dtScore.Rows[i]["v03"].ToString();
                F1_3 = dtScore.Rows[i]["v13"].ToString();
                F2_3 = dtScore.Rows[i]["v23"].ToString();
                F0_4 = dtScore.Rows[i]["v04"].ToString();
                F1_4 = dtScore.Rows[i]["v14"].ToString();
                F2_4 = dtScore.Rows[i]["v24"].ToString();
                F0_5 = dtScore.Rows[i]["v05"].ToString();
                F1_5 = dtScore.Rows[i]["v15"].ToString();
                F2_5 = dtScore.Rows[i]["v25"].ToString();
                FOther = dtScore.Rows[i]["v09"].ToString();

                in0 = dtGoal.Rows[i]["v0"].ToString();
                in1 = dtGoal.Rows[i]["v1"].ToString();
                in2 = dtGoal.Rows[i]["v2"].ToString();
                in3 = dtGoal.Rows[i]["v3"].ToString();
                in4 = dtGoal.Rows[i]["v4"].ToString();
                in5 = dtGoal.Rows[i]["v5"].ToString();
                in6 = dtGoal.Rows[i]["v6"].ToString();
                in7 = dtGoal.Rows[i]["v7"].ToString();

                SS = dtHalf.Rows[i]["v33"].ToString();
                SP = dtHalf.Rows[i]["v31"].ToString();
                SF = dtHalf.Rows[i]["v30"].ToString();
                PS = dtHalf.Rows[i]["v13"].ToString();
                PP = dtHalf.Rows[i]["v11"].ToString();
                PF = dtHalf.Rows[i]["v10"].ToString();
                FS = dtHalf.Rows[i]["v03"].ToString();
                FP = dtHalf.Rows[i]["v01"].ToString();
                FF = dtHalf.Rows[i]["v00"].ToString();

                sb.Append(" exec [pro_PassRateEdit] '" + Day + "', '" + MatchNumber + "'," + MainLoseball.ToString() + ",'" + win + "','" + flat + "','" + lose
                + "','" + S1_0 + "','" + S2_0 + "','" + S2_1 + "','" + S3_0 + "','" + S3_1 + "','" + S3_2 + "','" + S4_0 + "','" + S4_1 + "','" + S4_2
                + "','" + S5_0 + "','" + S5_1 + "','" + S5_2 + "','" + SOther + "','" + P0_0 + "','" + P1_1 + "','" + P2_2 + "','" + P3_3 + "','" + POther + "','" + F0_1
                + "','" + F0_2 + "','" + F1_2 + "','" + F0_3 + "','" + F1_3 + "','" + F2_3 + "','" + F0_4 + "','" + F1_4 + "','" + F2_4 + "','" + F0_5 + "','" + F1_5
                + "','" + F2_5 + "','" + FOther + "','" + in0 + "','" + in1 + "','" + in2 + "','" + in3 + "','" + in4 + "','" + in5 + "','" + in6 + "','" + in7
                + "','" + SS + "','" + SP + "','" + SF + "','" + PS + "','" + PP + "','" + PF + "','" + FS + "','" + FP + "','" + FF
                + "','" + uptime.ToString() + "'; ");
            }

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
        }

        private void GetBasketballOddsPassRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_PassRateBasket", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetBasketballOddsPassRate)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>0</type>";
            Body += "<valueType>1</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";

            string LetMainLose = "";
            string LetMainWin = "";
            string letscore = "";
            string Big = "";
            string Small = "";
            string BigSmallscore = "";
            string MainWin = "";
            string Mainlose = "";
            string DifferGuest1_5 = "";
            string DifferGuest6_10 = "";
            string DifferGuest11_15 = "";
            string DifferGuest16_20 = "";
            string DifferGuest21_25 = "";
            string DifferGuest26 = "";
            string DifferMain1_5 = "";
            string DifferMain6_10 = "";
            string DifferMain11_15 = "";
            string DifferMain16_20 = "";
            string DifferMain21_25 = "";
            string DifferMain26 = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainWin = dtVS.Rows[i]["v3"].ToString();
                Mainlose = dtVS.Rows[i]["v0"].ToString();

                LetMainLose = dtScore.Rows[i]["v3"].ToString();
                LetMainWin = dtScore.Rows[i]["v0"].ToString();
                letscore = dtScore.Rows[i]["letPoint"].ToString();

                BigSmallscore = dtGoal.Rows[i]["basePoint"].ToString();
                Big = dtGoal.Rows[i]["g"].ToString();
                Small = dtGoal.Rows[i]["l"].ToString();

                DifferGuest1_5 = dtHalf.Rows[i]["v01"].ToString();
                DifferGuest6_10 = dtHalf.Rows[i]["v02"].ToString();
                DifferGuest11_15 = dtHalf.Rows[i]["v03"].ToString();
                DifferGuest16_20 = dtHalf.Rows[i]["v04"].ToString();
                DifferGuest21_25 = dtHalf.Rows[i]["v05"].ToString();
                DifferGuest26 = dtHalf.Rows[i]["v06"].ToString();
                DifferMain1_5 = dtHalf.Rows[i]["v11"].ToString();
                DifferMain6_10 = dtHalf.Rows[i]["v12"].ToString();
                DifferMain11_15 = dtHalf.Rows[i]["v13"].ToString();
                DifferMain16_20 = dtHalf.Rows[i]["v14"].ToString();
                DifferMain21_25 = dtHalf.Rows[i]["v15"].ToString();
                DifferMain26 = dtHalf.Rows[i]["v16"].ToString();

                sb.Append(" exec [pro_PassRateBasketEdit] '" + Day + "', '" + MatchNumber + "'," + LetMainLose + ",'" + LetMainWin + "','" + letscore + "','" + Big
                + "','" + Small + "','" + BigSmallscore + "','" + MainWin + "','" + Mainlose + "','" + DifferGuest1_5 + "','" + DifferGuest6_10 + "','" + DifferGuest11_15 + "','" + DifferGuest16_20 + "','" + DifferGuest21_25
                + "','" + DifferGuest26 + "','" + DifferMain1_5 + "','" + DifferMain6_10 + "','" + DifferMain11_15 + "','" + DifferMain16_20 + "','" + DifferMain21_25 + "','" + DifferMain26
                + "','" + uptime.ToString() + "'; ");
            }

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
        }

        private void GetSporttoryOddsSingleRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_singleRate", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetSporttoryOdds)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>1</type>";
            Body += "<valueType>0</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";
            int MainLoseball = 0;

            string win = "";
            string flat = "";
            string lose = "";

            string S1_0 = "";
            string S2_0 = "";
            string S2_1 = "";
            string S3_0 = "";
            string S3_1 = "";
            string S3_2 = "";
            string S4_0 = "";
            string S4_1 = "";
            string S4_2 = "";
            string S5_0 = "";
            string S5_1 = "";
            string S5_2 = "";
            string SOther = "";
            string P0_0 = "";
            string P1_1 = "";
            string P2_2 = "";
            string P3_3 = "";
            string POther = "";
            string F0_1 = "";
            string F0_2 = "";
            string F1_2 = "";
            string F0_3 = "";
            string F1_3 = "";
            string F2_3 = "";
            string F0_4 = "";
            string F1_4 = "";
            string F2_4 = "";
            string F0_5 = "";
            string F1_5 = "";
            string F2_5 = "";
            string FOther = "";

            string in0 = "";
            string in1 = "";
            string in2 = "";
            string in3 = "";
            string in4 = "";
            string in5 = "";
            string in6 = "";
            string in7 = "";

            string SS = "";
            string SP = "";
            string SF = "";
            string PS = "";
            string PP = "";
            string PF = "";
            string FS = "";
            string FP = "";
            string FF = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainLoseball = Shove._Convert.StrToInt(dtVS.Rows[i]["letPoint"].ToString(), 0);
                win = dtVS.Rows[i]["v3"].ToString();
                flat = dtVS.Rows[i]["v1"].ToString();
                lose = dtVS.Rows[i]["v0"].ToString();

                S1_0 = dtScore.Rows[i]["v10"].ToString();
                S2_0 = dtScore.Rows[i]["v20"].ToString();
                S2_1 = dtScore.Rows[i]["v21"].ToString();
                S3_0 = dtScore.Rows[i]["v30"].ToString();
                S3_1 = dtScore.Rows[i]["v31"].ToString();
                S3_2 = dtScore.Rows[i]["v32"].ToString();
                S4_0 = dtScore.Rows[i]["v40"].ToString();
                S4_1 = dtScore.Rows[i]["v41"].ToString();
                S4_2 = dtScore.Rows[i]["v42"].ToString();
                S5_0 = dtScore.Rows[i]["v50"].ToString();
                S5_1 = dtScore.Rows[i]["v51"].ToString();
                S5_2 = dtScore.Rows[i]["v52"].ToString();
                SOther = dtScore.Rows[i]["v90"].ToString();
                P0_0 = dtScore.Rows[i]["v00"].ToString();
                P1_1 = dtScore.Rows[i]["v11"].ToString();
                P2_2 = dtScore.Rows[i]["v22"].ToString();
                P3_3 = dtScore.Rows[i]["v33"].ToString();
                POther = dtScore.Rows[i]["v99"].ToString();
                F0_1 = dtScore.Rows[i]["v01"].ToString();
                F0_2 = dtScore.Rows[i]["v02"].ToString();
                F1_2 = dtScore.Rows[i]["v12"].ToString();
                F0_3 = dtScore.Rows[i]["v03"].ToString();
                F1_3 = dtScore.Rows[i]["v13"].ToString();
                F2_3 = dtScore.Rows[i]["v23"].ToString();
                F0_4 = dtScore.Rows[i]["v04"].ToString();
                F1_4 = dtScore.Rows[i]["v14"].ToString();
                F2_4 = dtScore.Rows[i]["v24"].ToString();
                F0_5 = dtScore.Rows[i]["v05"].ToString();
                F1_5 = dtScore.Rows[i]["v15"].ToString();
                F2_5 = dtScore.Rows[i]["v25"].ToString();
                FOther = dtScore.Rows[i]["v09"].ToString();

                in0 = dtGoal.Rows[i]["v0"].ToString();
                in1 = dtGoal.Rows[i]["v1"].ToString();
                in2 = dtGoal.Rows[i]["v2"].ToString();
                in3 = dtGoal.Rows[i]["v3"].ToString();
                in4 = dtGoal.Rows[i]["v4"].ToString();
                in5 = dtGoal.Rows[i]["v5"].ToString();
                in6 = dtGoal.Rows[i]["v6"].ToString();
                in7 = dtGoal.Rows[i]["v7"].ToString();

                SS = dtHalf.Rows[i]["v33"].ToString();
                SP = dtHalf.Rows[i]["v31"].ToString();
                SF = dtHalf.Rows[i]["v30"].ToString();
                PS = dtHalf.Rows[i]["v13"].ToString();
                PP = dtHalf.Rows[i]["v11"].ToString();
                PF = dtHalf.Rows[i]["v10"].ToString();
                FS = dtHalf.Rows[i]["v03"].ToString();
                FP = dtHalf.Rows[i]["v01"].ToString();
                FF = dtHalf.Rows[i]["v00"].ToString();

                sb.Append(" exec [pro_SingleRateEdit] '" + Day + "', '" + MatchNumber + "'," + MainLoseball.ToString() + ",'" + win + "','" + flat + "','" + lose
                + "','" + S1_0 + "','" + S2_0 + "','" + S2_1 + "','" + S3_0 + "','" + S3_1 + "','" + S3_2 + "','" + S4_0 + "','" + S4_1 + "','" + S4_2
                + "','" + S5_0 + "','" + S5_1 + "','" + S5_2 + "','" + SOther + "','" + P0_0 + "','" + P1_1 + "','" + P2_2 + "','" + P3_3 + "','" + POther + "','" + F0_1
                + "','" + F0_2 + "','" + F1_2 + "','" + F0_3 + "','" + F1_3 + "','" + F2_3 + "','" + F0_4 + "','" + F1_4 + "','" + F2_4 + "','" + F0_5 + "','" + F1_5
                + "','" + F2_5 + "','" + FOther + "','" + in0 + "','" + in1 + "','" + in2 + "','" + in3 + "','" + in4 + "','" + in5 + "','" + in6 + "','" + in7
                + "','" + SS + "','" + SP + "','" + SF + "','" + PS + "','" + PP + "','" + PF + "','" + FS + "','" + FP + "','" + FF
                + "','" + uptime.ToString() + "'; ");
            }

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
        }

        private void GetBasketballOddsSingleRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_SingleRateBasket", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetBasketballOddsSingleRate)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>0</type>";
            Body += "<valueType>0</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";

            string LetMainLose = "";
            string LetMainWin = "";
            string letscore = "";
            string Big = "";
            string Small = "";
            string BigSmallscore = "";
            string MainWin = "";
            string Mainlose = "";
            string DifferGuest1_5 = "";
            string DifferGuest6_10 = "";
            string DifferGuest11_15 = "";
            string DifferGuest16_20 = "";
            string DifferGuest21_25 = "";
            string DifferGuest26 = "";
            string DifferMain1_5 = "";
            string DifferMain6_10 = "";
            string DifferMain11_15 = "";
            string DifferMain16_20 = "";
            string DifferMain21_25 = "";
            string DifferMain26 = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainWin = dtVS.Rows[i]["v3"].ToString();
                Mainlose = dtVS.Rows[i]["v0"].ToString();

                LetMainLose = dtScore.Rows[i]["v3"].ToString();
                LetMainWin = dtScore.Rows[i]["v0"].ToString();
                letscore = dtScore.Rows[i]["letPoint"].ToString();

                BigSmallscore = dtGoal.Rows[i]["basePoint"].ToString();
                Big = dtGoal.Rows[i]["g"].ToString();
                Small = dtGoal.Rows[i]["l"].ToString();

                DifferGuest1_5 = dtHalf.Rows[i]["v01"].ToString();
                DifferGuest6_10 = dtHalf.Rows[i]["v02"].ToString();
                DifferGuest11_15 = dtHalf.Rows[i]["v03"].ToString();
                DifferGuest16_20 = dtHalf.Rows[i]["v04"].ToString();
                DifferGuest21_25 = dtHalf.Rows[i]["v05"].ToString();
                DifferGuest26 = dtHalf.Rows[i]["v06"].ToString();
                DifferMain1_5 = dtHalf.Rows[i]["v11"].ToString();
                DifferMain6_10 = dtHalf.Rows[i]["v12"].ToString();
                DifferMain11_15 = dtHalf.Rows[i]["v13"].ToString();
                DifferMain16_20 = dtHalf.Rows[i]["v14"].ToString();
                DifferMain21_25 = dtHalf.Rows[i]["v15"].ToString();
                DifferMain26 = dtHalf.Rows[i]["v16"].ToString();

                sb.Append(" exec [pro_SingleRateBasketEdit] '" + Day + "', '" + MatchNumber + "'," + LetMainLose + ",'" + LetMainWin + "','" + letscore + "','" + Big
                + "','" + Small + "','" + BigSmallscore + "','" + MainWin + "','" + Mainlose + "','" + DifferGuest1_5 + "','" + DifferGuest6_10 + "','" + DifferGuest11_15 + "','" + DifferGuest16_20 + "','" + DifferGuest21_25
                + "','" + DifferGuest26 + "','" + DifferMain1_5 + "','" + DifferMain6_10 + "','" + DifferMain11_15 + "','" + DifferMain16_20 + "','" + DifferMain21_25 + "','" + DifferMain26
                + "','" + uptime.ToString() + "'; ");
            }

            MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
        }

        #endregion

        #region 公共方法

        private string GetFromXPath(string XML, string XPath)
        {
            if (XML.Trim() == "")
                return "";

            string Result = "";
            try
            {
                XPathDocument doc = new XPathDocument(new StringReader(XML));
                XPathNavigator nav = doc.CreateNavigator();
                XPathNodeIterator nodes = nav.Select(XPath);
                while (nodes.MoveNext())
                    Result += nodes.Current.Value;
            }
            catch//(Exception ee)
            {
                return "";
                //return ee.Message;
            }

            return Result;
        }

        private string GetGameName(int LotteryID)
        {
            switch (LotteryID)
            {
                case 74:
                    return "D14";
                case 75:
                    return "D9";
                case 2:
                    return "C4";
                case 3:
                    return "D7";
                case 9:
                    return "C522";
                case 15:
                    return "C12";
                case 39:
                    return "T001";
                case 62:
                    return "C511";
                case 63:
                    return "D3";
                case 64:
                    return "D5";
                case 65:
                    return "C731";
                default:
                    return "";
            }
        }

        private string GetPlayName(int PlayTypeID)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    return "FT001";
                case 7202:
                    return "FT002";
                case 7203:
                    return "FT003";
                case 7204:
                    return "FT004";
                case 7301:
                    return "BSK001";
                case 7302:
                    return "BSK002";
                case 7303:
                    return "BSK003";
                case 7304:
                    return "BSK004";
                default:
                    return "";
            }
        }

        private string GetSporttoryLotteryNumber(int PlayTypeID, string Number)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    switch (Number)
                    {
                        case "1":
                            return "3";
                        case "2":
                            return "1";
                        case "3":
                            return "0";
                        default:
                            return "0";
                    }
                case 7202:
                    switch (Number)
                    {
                        case "10":
                            return "50";
                        case "11":
                            return "51";
                        case "12":
                            return "52";
                        case "13":
                            return "90";
                        case "14":
                            return "00";
                        case "15":
                            return "11";
                        case "16":
                            return "22";
                        case "17":
                            return "33";
                        case "18":
                            return "99";
                        case "19":
                            return "01";
                        case "20":
                            return "02";
                        case "21":
                            return "12";
                        case "22":
                            return "03";
                        case "23":
                            return "13";
                        case "24":
                            return "23";
                        case "25":
                            return "04";
                        case "26":
                            return "14";
                        case "27":
                            return "24";
                        case "28":
                            return "05";
                        case "29":
                            return "15";
                        case "30":
                            return "25";
                        case "31":
                            return "09";
                        case "1":
                            return "10";
                        case "2":
                            return "20";
                        case "3":
                            return "21";
                        case "4":
                            return "30";
                        case "5":
                            return "31";
                        case "6":
                            return "32";
                        case "7":
                            return "40";
                        case "8":
                            return "41";
                        case "9":
                            return "42";
                        default:
                            return "";
                    }
                case 7203:
                    switch (Number)
                    {
                        case "1":
                            return "0";
                        case "2":
                            return "1";
                        case "3":
                            return "2";
                        case "4":
                            return "3";
                        case "5":
                            return "4";
                        case "6":
                            return "5";
                        case "7":
                            return "6";
                        case "8":
                            return "7";
                        default:
                            return "";
                    }
                case 7204:
                    switch (Number)
                    {
                        case "1":
                            return "33";
                        case "2":
                            return "31";
                        case "3":
                            return "30";
                        case "4":
                            return "13";
                        case "5":
                            return "11";
                        case "6":
                            return "10";
                        case "7":
                            return "03";
                        case "8":
                            return "01";
                        case "9":
                            return "00";
                        default:
                            return "";
                    }
                case 7301:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7302:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7303:
                    switch (Number)
                    {
                        #region
                        /*#interface Define
                            01 -->  主胜1-5
                            02 -->  主胜6-10
                            03 -->  主胜11-15
                            04 -->  主胜16-20
                            05 -->  主胜21-25
                            06 -->  主胜26+
                            11 -->  客胜1-5
                            12 -->  客胜6-10
                            13 -->  客胜11-15
                            14 -->  客胜16-20
                            15 -->  客胜21-25
                            16 -->  客胜26+


                            #my Define
                            1 -->    客胜1-5
                            2 -->   主胜1-5
                            3 -->    客胜6-10
                            4 -->   主胜6-10
                            5 -->    客胜11-15
                            6 -->   主胜11-15
                            7 -->    客胜16-20
                            8 -->   主胜16-20
                            9 -->    客胜21-25
                            10 -->   主胜21-25
                            11 -->    客胜26+
                            12 -->   主胜26+
                         */
                        #endregion
                        case "12": /*主胜26+*/
                            return "06";
                        case "11": /*客胜26+*/
                            return "16";
                        case "10": /*主胜21-25*/
                            return "05";
                        case "9": /*客胜21-25*/
                            return "15";
                        case "8": /*主胜16-20*/
                            return "04";
                        case "7": /*客胜16-20*/
                            return "14";
                        case "6": /*主胜11-15*/
                            return "03";
                        case "5": /*客胜11-15*/
                            return "13";
                        case "4": /*主胜6-10*/
                            return "02";
                        case "3": /*客胜6-10*/
                            return "12";
                        case "2": /*主胜1-5*/
                            return "01";
                        case "1": /*客胜1-5*/
                            return "11";
                        default:
                            return "01";
                    }
                case 7304:
                    return Number;
                default:
                    return "";
            }
        }

        private int GetLotteryID(string gameName)
        {
            switch (gameName)
            {
                case "D14":
                    return 74;
                case "D9":
                    return 75;
                case "C4":
                    return 2;
                case "D7":
                    return 3;
                case "C522":
                    return 9;
                case "C12":
                    return 15;
                case "T001":
                    return 39;
                case "C511":
                    return 62;
                case "D3":
                    return 63;
                case "D5":
                    return 64;
                case "C731":
                    return 65;
                default:
                    return -1;
            }
        }

        //写日志文件
        public void WriteElectronTicketLog(bool isSend, string TransType, string TransMessage)
        {
            log.Write("isSend: " + isSend.ToString() + "\tTransType: " + TransType + "\t" + TransMessage);
        }

        private string GetWeekDescprtion(string Day)
        {
            switch (Day)
            {
                case "1":
                    return "周一";
                case "2":
                    return "周二";
                case "3":
                    return "周三";
                case "4":
                    return "周四";
                case "5":
                    return "周五";
                case "6":
                    return "周六";
                case "7":
                    return "周日";
                default:
                    return "";

            }

        }

        private string GetDayFromWeek(string Day)
        {
            switch (Day)
            {
                case "周一":
                    return "1";
                case "周二":
                    return "2";
                case "周三":
                    return "3";
                case "周四":
                    return "4";
                case "周五":
                    return "5";
                case "周六":
                    return "6";
                case "周日":
                    return "7";
                default:
                    return "";

            }

        }

        #endregion

        #region 分析中奖描述、奖等

        private class CompareToLength : IComparer
        {
            int IComparer.Compare(Object x, Object y)
            {
                long _x = Shove._Convert.StrToLong(x.ToString(), -1);
                long _y = Shove._Convert.StrToLong(y.ToString(), -1);

                return _x.CompareTo(_y);
            }
        }

        private string GetWinNumber(int LotteryID, string WinNumber)
        {
            switch (LotteryID)
            {
                case 5:
                    return WinNumber.Replace(",", " ").Insert(12, " +").Insert(10, " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 6:
                    return WinNumber.Replace(",", "");
                case 13:
                    return WinNumber.Replace(",", " ").Replace("#", " + ");
                case 29:
                    return WinNumber.Replace(",", "");
                case 58:
                    return WinNumber.Replace(",", "").Replace("#01", "+鼠").Replace("#02", "+牛").Replace("#03", "+虎").Replace("#04", "+兔").Replace("#05", "+龙").Replace("#06", "+蛇").Replace("#07", "+马").Replace("#08", "+羊").Replace("#09", "+猴").Replace("#10", "+鸡").Replace("#11", "+狗").Replace("#12", "+猪");
                case 59:
                    return WinNumber.Replace(",", " ").Replace("#", " ");
                case 60:
                    return WinNumber.Replace(",", "");
                case 3:
                    return WinNumber.Replace(",", "");
                case 9:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 65:
                    return WinNumber.Replace(",", " ").Insert(13, " ").Insert(11, "+ ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 39:
                    return WinNumber.Replace(" ", "+").Insert(13, " ").Replace("+", " + ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 1:
                    return WinNumber.Replace(",", "");
                case 2:
                    return WinNumber.Replace(",", "");
                case 15:
                    return WinNumber.Replace(",", "").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 62:
                    return WinNumber.Replace(",", " ").Insert(8, " ").Insert(6, " ").Insert(4, " ").Insert(2, " ");
                case 63:
                    return WinNumber.Replace(",", "");
                case 64:
                    return WinNumber.Replace(",", "").Replace("#", " + ");
                default:
                    return WinNumber;
            }
        }

        #endregion
    }
}