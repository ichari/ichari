﻿using System;
using System.Data;
using System.Configuration;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using System.Text;

using System.Linq;

using Shove.Database;
using SLS.Cttcsd.Task.Helper;

namespace SLS.Cttcsd.Task
{
    /// <summary>
    /// HPSH 的摘要说明
    /// </summary>
    public class ElectronTicket_Sporttery
    {
        private const int TimeoutSeconds = 90;

        private long gCount1 = 0;
        private long gCount2 = 0;
        private long gCount3 = 0;

        private System.Threading.Thread thread;

        private string ConnectionString;

        private Log log = new Log("ElectronTicket_Sporttery");

        public int State = 0;   // 0 停止 1 运行中 2 置为停止

        public string ElectronTicket_CTTCSD_UserName;
        public string ElectronTicket_CTTCSD_UserPassword;
        public string ElectronTicket_CTTCSD_Getway;
        public string ElectronTicket_CTTCSD_DownloadGetway;

        public string ElectronTicket_PrintOut_IDCardNumber;
        public string ElectronTicket_PrintOut_Mobile;

        public ElectronTicket_Sporttery(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public void Run()
        {
            SystemOptions so = new SystemOptions(ConnectionString);

            if (!so["ElectronTicket_CTTCSD_Status_ON"].ToBoolean(false))
            {
                return;
            }

            if ((ElectronTicket_CTTCSD_Getway == "") || (ElectronTicket_CTTCSD_UserName == "") || (ElectronTicket_CTTCSD_UserPassword == ""))
            {
                log.Write("ElectronTicket_Sporttery Task 参数配置不完整.");

                return;
            }

            // 已经启动
            if (State == 1)
            {
                return;
            }

            lock (this) // 确保临界区被一个 Thread 所占用
            {
                State = 1;

                gCount1 = 0;
                gCount2 = 0;
                gCount3 = 0;

                thread = new System.Threading.Thread(new System.Threading.ThreadStart(Do));
                thread.IsBackground = true;

                thread.Start();

                log.Write("ElectronTicket_Sporttery Task Start.");
            }
        }

        public void Exit()
        {
            State = 2;
        }

        public void Do()
        {
            while (true)
            {
                if (State == 2)
                {
                    log.Write("ElectronTicket_Sporttery Task Stop.");

                    State = 0;

                    Stop();

                    return;
                }

                System.Threading.Thread.Sleep(1000);   // 1秒为单位

                gCount1++;
                gCount2++;
                gCount3++;

                #region 5分钟，查询对阵信息

                if (gCount1 >= 60 * 2)
                {
                    gCount1 = 0;

                    try
                    {
                        GetSportteryTeamInfo();      // 查询竟彩足彩对阵信息

                        log.Write("GetSportteryTeamInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetSportteryTeamInfo is Fail: " + e.Message);
                    }

                    try
                    {
                        GetBasketballTeamInfo();      // 查询竟彩篮彩对阵信息

                        log.Write("GetBasketballTeamInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetBasketballTeamInfo is Fail: " + e.Message);
                    }

                    try
                    {
                        GetSporttoryOddsSingleRate();         //查询竟彩足彩单关赔率

                        log.Write("GetSporttoryOddsSingleRate ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetSporttoryOddsSingleRate is Fail: " + e.Message);
                    }

                    try
                    {
                        GetSporttoryOddsPassRate();         //查询竟彩足彩赔率

                        log.Write("GetSporttoryOdds ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetSporttoryOdds is Fail: " + e.Message);
                    }

                    try
                    {
                        GetBasketballOddsPassRate();         //查询竟彩篮彩赔率

                        log.Write("GetBasketballOddsPassRate ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetBasketballOddsPassRate is Fail: " + e.Message);
                    }

                    try
                    {
                        GetBasketballOddsSingleRate();         //查询竟彩篮彩单关赔率

                        log.Write("GetBasketballOddsSingleRate ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetBasketballOddsSingleRate is Fail: " + e.Message);
                    }
                }

                #endregion

                #region 6 分钟，查询奖期

                if (gCount2 >= 60 * 6)
                {
                    gCount2 = 0;
                    try
                    {
                        GetSporttoryAwardInfo();

                        log.Write("GetSporttoryAwardInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetSporttoryAwardInfo is Fail: " + e.Message);
                    }

                    try
                    {
                        GetBasketballAwardInfo();

                        log.Write("GetBasketballAwardInfo ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetBasketballAwardInfo is Fail: " + e.Message + e.StackTrace);
                    }

                    try
                    {
                        // 竞彩方案开奖
                        WinByOpenManual();
                    }
                    catch (Exception e)
                    {
                        log.Write("WinByOpenManual is Fail: " + e.Message + e.StackTrace);
                    }
                }

                #endregion

                #region 5 分钟，查询比赛结果

                if (gCount3 >= 60 * 2)
                {
                    gCount3 = 0;

                    try
                    {
                        GetSporttoryResult();           // 查询竞彩赛果

                        log.Write("GetSporttoryResult ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetSporttoryResult is Fail: " + e.Message);
                    }

                    try
                    {
                        GetBasketballSporttoryResult();   // 查询竞彩赛果

                        log.Write("GetBasketballSporttoryResult ...... OK.");
                    }
                    catch (Exception e)
                    {
                        log.Write("GetBasketballSporttoryResult is Fail: " + e.Message);
                    }
                }

                #endregion
            }
        }

        private void Stop()
        {
            if (thread != null)
            {
                thread.Abort();
                thread = null;
            }
        }

        #region 定时器执行的事件

        private void GetSporttoryAwardInfo()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select StopSellingTime, MatchNumber, ID from T_Match where IsOpened = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetSporttoryAwardInfo)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>1</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1016</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                //new Log("1016").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                //WriteElectronTicketLog(false, "1016", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1016").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 2)
                {
                    continue;
                }

                DataTable dtFileName = ds.Tables[1];

                if (dtFileName.Rows.Count < 1)
                {
                    return;
                }

                foreach (DataRow dr in dtFileName.Rows)
                {
                    string ProcessState = dr["processState"].ToString();
                    string FileName = dr["fileName"].ToString();

                    if (ProcessState.Trim() == "0")
                    {
                        continue;
                    }

                    string DownLoadFileNameUrl = ElectronTicket_CTTCSD_DownloadGetway + "/" + ElectronTicket_CTTCSD_UserName + "/1/Award/" + FileName;

                    string Html = PublicFunction.GetHtml(DownLoadFileNameUrl, "utf-8", 120);

                    if (Html == "")
                    {
                        continue;
                    }

                    new Log("GetSporttoryAwardInfo").Write(Html);

                    // 该赛事没有中奖文件
                    if (Html.IndexOf("<body/>") >= 0)
                    {
                        // 设置该比赛已经开奖
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    elements = Html.Substring(Html.IndexOf("<head>"), Html.LastIndexOf("</body>") - Html.IndexOf("<head>")) + "</body>";

                    DataSet ds1 = new DataSet();

                    ds1.ReadXml(new StringReader(Html));

                    if (ds1 == null)
                    {
                        continue;
                    }

                    if (Shove._Security.Encrypt.MD5(elements).ToLower() != ds1.Tables[0].Rows[0]["sign"].ToString().ToLower())
                    {
                        continue;
                    }

                    DataTable dtTicket = ds1.Tables[ds1.Tables.Count - 1];

                    // 该比赛中没有中奖票
                    if (dtTicket.Rows.Count < 1)
                    {
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    // 票信息
                    string[] StrTickets = null;

                    foreach (DataRow drTicket in dtTicket.Rows)
                    {
                        StrTickets = drTicket[0].ToString().Split(',');

                        if (StrTickets.Length != 8)
                        {
                            continue;
                        }
                        // 得到票ID
                        string tickID = StrTickets[0].ToString();
                        // 得到该票中奖金额
                        string tickWinMoney = StrTickets[5].ToString().Insert(StrTickets[5].ToString().Length - 2, ".");
                        string sql = "update T_SchemesSendToCenter set HandleDescription = '" + tickWinMoney + "' where Identifiers = '" + tickID + "'";

                        if (Shove.Database.MSSQL.ExecuteNonQuery(ConnectionString, sql) < 0)
                        {
                            new Log("1016").Write("[票] 开奖错误, tickID：" + tickID);
                        }
                        new Log("1016").Write("[票] 开奖成功, tickID：" + tickID);
                    }
                    // 开奖成功后，设置isOpened = 1
                    MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);
                }

                #endregion
            }
        }

        private void GetBasketballAwardInfo()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select * from T_MatchBasket where IsOpened = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("期号销量查询错误(GetBasketballAwardInfo)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>0</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1016</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                //new Log("1016").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                //WriteElectronTicketLog(false, "1016", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1016").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                DataTable dtFileName = ds.Tables[1];

                if (dtFileName.Rows.Count < 1)
                {
                    return;
                }

                foreach (DataRow dr in dtFileName.Rows)
                {
                    string ProcessState = dr["processState"].ToString();
                    string FileName = dr["fileName"].ToString();

                    if (ProcessState.Trim() == "0")
                    {
                        continue;
                    }

                    string DownLoadFileNameUrl = ElectronTicket_CTTCSD_DownloadGetway + "/" + ElectronTicket_CTTCSD_UserName + "/0/Award/" + FileName;

                    string Html = PublicFunction.GetHtml(DownLoadFileNameUrl, "utf-8", 120);

                    if (Html == "")
                    {
                        continue;
                    }

                    new Log("GetBasketballAwardInfo").Write(Html);

                    // 该赛事没有中奖文件
                    if (Html.IndexOf("<body/>") >= 0)
                    {
                        // 设置该比赛已经开奖
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    elements = Html.Substring(Html.IndexOf("<head>"), Html.LastIndexOf("</body>") - Html.IndexOf("<head>")) + "</body>";

                    DataSet ds1 = new DataSet();

                    ds1.ReadXml(new StringReader(Html));

                    if (ds1 == null)
                    {
                        continue;
                    }

                    if (Shove._Security.Encrypt.MD5(elements).ToLower() != ds1.Tables[0].Rows[0]["sign"].ToString().ToLower())
                    {
                        continue;
                    }

                    DataTable dtTicket = ds1.Tables[ds1.Tables.Count - 1];

                    // 该比赛中没有中奖票
                    if (dtTicket.Rows.Count < 1)
                    {
                        // 设置该比赛已经开奖
                        MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);

                        continue;
                    }

                    // 票信息
                    string[] StrTickets = null;

                    foreach (DataRow drTicket in dtTicket.Rows)
                    {
                        StrTickets = drTicket[0].ToString().Split(',');

                        if (StrTickets.Length != 8)
                        {
                            continue;
                        }

                        // 得到票ID
                        string tickID = StrTickets[0].ToString();
                        // 得到该票中奖金额
                        string tickWinMoney = StrTickets[5].ToString().Insert(StrTickets[5].ToString().Length - 2, ".");

                        string sql = "update T_SchemesSendToCenter set HandleDescription = '" + tickWinMoney + "' where Identifiers = '" + tickID + "'";

                        if (Shove.Database.MSSQL.ExecuteNonQuery(ConnectionString, sql) < 0)
                        {
                            new Log("1016").Write("[票] 开奖错误, tickID：" + tickID);
                        }
                        new Log("1016").Write("[票] 开奖成功, tickID：" + tickID);
                    }

                    // 开奖成功后，设置isOpened = 1
                    MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set IsOpened = 1 where ID = " + dt.Rows[i]["ID"].ToString(), null);
                }
                #endregion
            }
        }

        private void GetSportteryTeamInfo()
        {
            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>1</type></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1015</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            new Log("1015").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1015", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1015").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 2)
            {
                return;
            }

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            string MatchNumber = "";
            string Game = "";
            string MainTeam = "";
            string GuestTeam = "";
            string Day = "";
            string SaleFlag = "";

            int orderby = 1;
            int Count = 0;

            // 开始时间
            DateTime startTime = DateTime.Now;
            DateTime stopselltime = DateTime.Now;
            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();
            StringBuilder sbSingleRate = new StringBuilder();

            for (int i = 0; i < dtTeamInfo.Rows.Count; i++)
            {
                DataRow dr = dtTeamInfo.Rows[i];

                SaleFlag = dr["saleFlag"].ToString();

                if (SaleFlag == "1")
                {
                    continue;
                }

                MatchNumber = GetWeekDescprtion(dr["weekId"].ToString()) + dr["teamId"].ToString();
                Game = dr["league"].ToString();
                stopselltime = Shove._Convert.StrToDateTime(dr["endTime"].ToString(), DateTime.Now.ToString());
                Day = dr["day"].ToString();
                startTime = Shove._Convert.StrToDateTime(dr["time"].ToString(), DateTime.Now.ToString());

                try
                {
                    MainTeam = dr["team"].ToString().Split(':')[0];
                    GuestTeam = dr["team"].ToString().Split(':')[1];
                }
                catch
                {
                    continue;
                }

                sb.Append(" exec [P_PassRateAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "','" + startTime + "'; ");
                sb.Append(" Update T_PassRate set IsHhad = 1,  IsCrs = 1, IsTtg = 1, IsHafu = 1, StopSellTime = '" + stopselltime.ToString() + "' where MatchNumber='" + MatchNumber + "'; ");

                sbSingleRate.Append(" exec [P_SingleRateAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "','" + startTime + "'; ");
                sbSingleRate.Append(" Update T_singleRate set IsHhad = 1,  IsCrs = 1, IsTtg = 1, IsHafu = 1, StopSellTime = '" + stopselltime.ToString() + "' where MatchNumber='" + MatchNumber + "'; ");

                Count++;
            }

            if (ds.Tables.Count == 4)
            {
                string Condition = "";
                string Type = "";

                foreach (DataRow dr in ds.Tables[3].Rows)
                {
                    Type = dr["type"].ToString();

                    switch (dr["lotteryId"].ToString())
                    {
                        case "FT001":
                            Condition = " IsHhad = 0 ";

                            break;
                        case "FT002":
                            Condition = " IsCrs = 0 ";

                            break;
                        case "FT003":
                            Condition = " IsTtg = 0 ";

                            break;
                        case "FT004":
                            Condition = " IsHafu = 0 ";

                            break;
                        default:
                            break;
                    }

                    DataRow[] drTeamInfo = ds.Tables[1].Select("vs_Id=" + dr["unsupport_Id"].ToString());

                    if (dtTeamInfo.Rows.Count < 1)
                    {
                        continue;
                    }

                    if (Type == "1")
                    {
                        sb.Append(" Update T_PassRate set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                    else
                    {
                        sbSingleRate.Append(" Update T_singleRate set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                }
            }

            sb.Append(" delete T_PassRate where StopSellTime < dateadd(day, -4,getdate()) or MatchDate < dateadd(day, -4,getdate()); ");
            sbSingleRate.Append(" delete T_singleRate where StopSellTime < dateadd(day, -4,getdate()) or MatchDate < dateadd(day, -4,getdate()); ");

            //new Log("1015").Write(sb.ToString());
            //new Log("1015").Write(sbSingleRate.ToString());

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            int result2 = MSSQL.ExecuteNonQuery(ConnectionString, sbSingleRate.ToString(), null);
            if (result < 0 || result2 < 0)
            {
                new Log("1015").Write("获取足球对阵数据执行失败");
            }
        }

        private void GetBasketballTeamInfo()
        {
            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>0</type></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1015</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1015").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1015", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1015").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 2)
            {
                return;
            }

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            string MatchNumber = "";
            string Game = "";
            string MainTeam = "";
            string GuestTeam = "";
            string Day = "";
            string SaleFlag = "";

            int orderby = 1;
            int Count = 0;

            DateTime stopselltime = DateTime.Now;
            // 比赛开始时间
            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();
            StringBuilder sbSingleRate = new StringBuilder();

            for (int i = 0; i < dtTeamInfo.Rows.Count; i++)
            {
                DataRow dr = dtTeamInfo.Rows[i];

                SaleFlag = dr["saleFlag"].ToString();

                if (SaleFlag == "1")
                {
                    continue;
                }

                MatchNumber = GetWeekDescprtion(dr["weekId"].ToString()) + dr["teamId"].ToString();
                Game = dr["league"].ToString();
                stopselltime = Shove._Convert.StrToDateTime(dr["endTime"].ToString(), DateTime.Now.ToString());
                Day = dr["day"].ToString();
                uptime = Shove._Convert.StrToDateTime(dr["time"].ToString(), DateTime.Now.ToString()); // 比赛开始时间

                try
                {
                    MainTeam = dr["team"].ToString().Split(':')[0];
                    GuestTeam = dr["team"].ToString().Split(':')[1];
                }
                catch
                {
                    continue;
                }

                sb.Append(" exec [P_PassRateBasketAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "','" + uptime + "'; ");
                sb.Append(" Update T_PassRateBasket set IsMnl = 1,  IsHdc = 1, IsWnm = 1, IsHilo = 1, StopSellTime = '" + stopselltime.ToString() + "' where MatchNumber='" + MatchNumber + "'; ");

                sbSingleRate.Append(" exec [P_SingleRateBasketAdd] '" + Day + "','" + MatchNumber + "','" + Game + "','" + MainTeam + "','" + GuestTeam + "'," + (orderby++).ToString() + ",'" + stopselltime.ToString() + "','" + uptime + "'; ");
                sbSingleRate.Append(" Update T_SingleRateBasket set IsMnl = 1,  IsHdc = 1, IsWnm = 1, IsHilo = 1, StopSellTime = '" + stopselltime.ToString() + "' where MatchNumber='" + MatchNumber + "'; ");

                Count++;
            }

            if (ds.Tables.Count == 4)
            {
                string Condition = "";
                string Type = "";

                foreach (DataRow dr in ds.Tables[3].Rows)
                {
                    Type = dr["type"].ToString();

                    switch (dr["lotteryId"].ToString())
                    {
                        case "BSK001":
                            Condition = " IsMnl = 0 ";

                            break;
                        case "BSK002":
                            Condition = " IsHdc = 0 ";

                            break;
                        case "BSK003":
                            Condition = " IsWnm = 0 ";

                            break;
                        case "BSK004":
                            Condition = " IsHilo = 0 ";

                            break;
                        default:
                            break;
                    }

                    DataRow[] drTeamInfo = ds.Tables[1].Select("vs_Id=" + dr["unsupport_Id"].ToString());

                    if (dtTeamInfo.Rows.Count < 1)
                    {
                        continue;
                    }

                    if (Type == "1")
                    {
                        sb.Append(" Update T_PassRateBasket set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                    else
                    {
                        sbSingleRate.Append(" Update T_SingleRateBasket set " + Condition + " where MatchNumber='" + GetWeekDescprtion(drTeamInfo[0]["weekId"].ToString()) + drTeamInfo[0]["teamId"].ToString() + "'; ");
                    }
                }
            }

            sb.Append(" delete T_PassRateBasket where StopSellTime < dateadd(day, -4,getdate()) or MatchDate < dateadd(day, -4,getdate()); ");
            sbSingleRate.Append(" delete T_SingleRateBasket where StopSellTime < dateadd(day, -4,getdate()) or MatchDate < dateadd(day, -4,getdate()); ");

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            int result2 = MSSQL.ExecuteNonQuery(ConnectionString, sbSingleRate.ToString(), null);
            if (result < 0 || result2 < 0)
            {
                new Log("1015").Write("获取篮球对阵数据执行失败");
            }
        }

        private void GetSporttoryOddsPassRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_PassRate where State = 1", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetSporttoryOdds)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>1</type>";
            Body += "<valueType>1</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";
            int MainLoseball = 0;

            string win = "";
            string flat = "";
            string lose = "";

            string S1_0 = "";
            string S2_0 = "";
            string S2_1 = "";
            string S3_0 = "";
            string S3_1 = "";
            string S3_2 = "";
            string S4_0 = "";
            string S4_1 = "";
            string S4_2 = "";
            string S5_0 = "";
            string S5_1 = "";
            string S5_2 = "";
            string SOther = "";
            string P0_0 = "";
            string P1_1 = "";
            string P2_2 = "";
            string P3_3 = "";
            string POther = "";
            string F0_1 = "";
            string F0_2 = "";
            string F1_2 = "";
            string F0_3 = "";
            string F1_3 = "";
            string F2_3 = "";
            string F0_4 = "";
            string F1_4 = "";
            string F2_4 = "";
            string F0_5 = "";
            string F1_5 = "";
            string F2_5 = "";
            string FOther = "";

            string in0 = "";
            string in1 = "";
            string in2 = "";
            string in3 = "";
            string in4 = "";
            string in5 = "";
            string in6 = "";
            string in7 = "";

            string SS = "";
            string SP = "";
            string SF = "";
            string PS = "";
            string PP = "";
            string PF = "";
            string FS = "";
            string FP = "";
            string FF = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainLoseball = Shove._Convert.StrToInt(dtVS.Rows[i]["letPoint"].ToString(), 0);
                win = dtVS.Rows[i]["v3"].ToString();
                flat = dtVS.Rows[i]["v1"].ToString();
                lose = dtVS.Rows[i]["v0"].ToString();

                S1_0 = dtScore.Rows[i]["v10"].ToString();
                S2_0 = dtScore.Rows[i]["v20"].ToString();
                S2_1 = dtScore.Rows[i]["v21"].ToString();
                S3_0 = dtScore.Rows[i]["v30"].ToString();
                S3_1 = dtScore.Rows[i]["v31"].ToString();
                S3_2 = dtScore.Rows[i]["v32"].ToString();
                S4_0 = dtScore.Rows[i]["v40"].ToString();
                S4_1 = dtScore.Rows[i]["v41"].ToString();
                S4_2 = dtScore.Rows[i]["v42"].ToString();
                S5_0 = dtScore.Rows[i]["v50"].ToString();
                S5_1 = dtScore.Rows[i]["v51"].ToString();
                S5_2 = dtScore.Rows[i]["v52"].ToString();
                SOther = dtScore.Rows[i]["v90"].ToString();
                P0_0 = dtScore.Rows[i]["v00"].ToString();
                P1_1 = dtScore.Rows[i]["v11"].ToString();
                P2_2 = dtScore.Rows[i]["v22"].ToString();
                P3_3 = dtScore.Rows[i]["v33"].ToString();
                POther = dtScore.Rows[i]["v99"].ToString();
                F0_1 = dtScore.Rows[i]["v01"].ToString();
                F0_2 = dtScore.Rows[i]["v02"].ToString();
                F1_2 = dtScore.Rows[i]["v12"].ToString();
                F0_3 = dtScore.Rows[i]["v03"].ToString();
                F1_3 = dtScore.Rows[i]["v13"].ToString();
                F2_3 = dtScore.Rows[i]["v23"].ToString();
                F0_4 = dtScore.Rows[i]["v04"].ToString();
                F1_4 = dtScore.Rows[i]["v14"].ToString();
                F2_4 = dtScore.Rows[i]["v24"].ToString();
                F0_5 = dtScore.Rows[i]["v05"].ToString();
                F1_5 = dtScore.Rows[i]["v15"].ToString();
                F2_5 = dtScore.Rows[i]["v25"].ToString();
                FOther = dtScore.Rows[i]["v09"].ToString();

                in0 = dtGoal.Rows[i]["v0"].ToString();
                in1 = dtGoal.Rows[i]["v1"].ToString();
                in2 = dtGoal.Rows[i]["v2"].ToString();
                in3 = dtGoal.Rows[i]["v3"].ToString();
                in4 = dtGoal.Rows[i]["v4"].ToString();
                in5 = dtGoal.Rows[i]["v5"].ToString();
                in6 = dtGoal.Rows[i]["v6"].ToString();
                in7 = dtGoal.Rows[i]["v7"].ToString();

                SS = dtHalf.Rows[i]["v33"].ToString();
                SP = dtHalf.Rows[i]["v31"].ToString();
                SF = dtHalf.Rows[i]["v30"].ToString();
                PS = dtHalf.Rows[i]["v13"].ToString();
                PP = dtHalf.Rows[i]["v11"].ToString();
                PF = dtHalf.Rows[i]["v10"].ToString();
                FS = dtHalf.Rows[i]["v03"].ToString();
                FP = dtHalf.Rows[i]["v01"].ToString();
                FF = dtHalf.Rows[i]["v00"].ToString();

                sb.Append(" exec [P_PassRateEdit] '" + Day + "', '" + MatchNumber + "'," + MainLoseball.ToString() + ",'" + win + "','" + flat + "','" + lose
                + "','" + S1_0 + "','" + S2_0 + "','" + S2_1 + "','" + S3_0 + "','" + S3_1 + "','" + S3_2 + "','" + S4_0 + "','" + S4_1 + "','" + S4_2
                + "','" + S5_0 + "','" + S5_1 + "','" + S5_2 + "','" + SOther + "','" + P0_0 + "','" + P1_1 + "','" + P2_2 + "','" + P3_3 + "','" + POther + "','" + F0_1
                + "','" + F0_2 + "','" + F1_2 + "','" + F0_3 + "','" + F1_3 + "','" + F2_3 + "','" + F0_4 + "','" + F1_4 + "','" + F2_4 + "','" + F0_5 + "','" + F1_5
                + "','" + F2_5 + "','" + FOther + "','" + in0 + "','" + in1 + "','" + in2 + "','" + in3 + "','" + in4 + "','" + in5 + "','" + in6 + "','" + in7
                + "','" + SS + "','" + SP + "','" + SF + "','" + PS + "','" + PP + "','" + PF + "','" + FS + "','" + FP + "','" + FF
                + "','" + uptime.ToString() + "'; ");
            }

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            if (result < 0)
            {
                new Log("1015").Write("获取足球过关赔率数据执行失败");
            }
        }

        private void GetBasketballOddsPassRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_PassRateBasket", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetBasketballOddsPassRate)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>0</type>";
            Body += "<valueType>1</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";

            string LetMainLose = "";
            string LetMainWin = "";
            string letscore = "";
            string Big = "";
            string Small = "";
            string BigSmallscore = "";
            string MainWin = "";
            string Mainlose = "";
            string DifferGuest1_5 = "";
            string DifferGuest6_10 = "";
            string DifferGuest11_15 = "";
            string DifferGuest16_20 = "";
            string DifferGuest21_25 = "";
            string DifferGuest26 = "";
            string DifferMain1_5 = "";
            string DifferMain6_10 = "";
            string DifferMain11_15 = "";
            string DifferMain16_20 = "";
            string DifferMain21_25 = "";
            string DifferMain26 = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainWin = dtVS.Rows[i]["v3"].ToString();
                Mainlose = dtVS.Rows[i]["v0"].ToString();

                //LetMainLose = dtScore.Rows[i]["v3"].ToString();
                //LetMainWin = dtScore.Rows[i]["v0"].ToString();
                LetMainLose = dtScore.Rows[i]["v0"].ToString();
                LetMainWin = dtScore.Rows[i]["v3"].ToString();

                letscore = dtScore.Rows[i]["letPoint"].ToString();

                BigSmallscore = dtGoal.Rows[i]["basePoint"].ToString();
                Big = dtGoal.Rows[i]["g"].ToString();
                Small = dtGoal.Rows[i]["l"].ToString();

                //DifferGuest1_5 = dtHalf.Rows[i]["v01"].ToString();
                //DifferGuest6_10 = dtHalf.Rows[i]["v02"].ToString();
                //DifferGuest11_15 = dtHalf.Rows[i]["v03"].ToString();
                //DifferGuest16_20 = dtHalf.Rows[i]["v04"].ToString();
                //DifferGuest21_25 = dtHalf.Rows[i]["v05"].ToString();
                //DifferGuest26 = dtHalf.Rows[i]["v06"].ToString();
                //DifferMain1_5 = dtHalf.Rows[i]["v11"].ToString();
                //DifferMain6_10 = dtHalf.Rows[i]["v12"].ToString();
                //DifferMain11_15 = dtHalf.Rows[i]["v13"].ToString();
                //DifferMain16_20 = dtHalf.Rows[i]["v14"].ToString();
                //DifferMain21_25 = dtHalf.Rows[i]["v15"].ToString();
                //DifferMain26 = dtHalf.Rows[i]["v16"].ToString();

                DifferMain1_5 = dtHalf.Rows[i]["v01"].ToString();
                DifferMain6_10 = dtHalf.Rows[i]["v02"].ToString();
                DifferMain11_15 = dtHalf.Rows[i]["v03"].ToString();
                DifferMain16_20 = dtHalf.Rows[i]["v04"].ToString();
                DifferMain21_25 = dtHalf.Rows[i]["v05"].ToString();
                DifferMain26 = dtHalf.Rows[i]["v06"].ToString();
                DifferGuest1_5 = dtHalf.Rows[i]["v11"].ToString();
                DifferGuest6_10 = dtHalf.Rows[i]["v12"].ToString();
                DifferGuest11_15 = dtHalf.Rows[i]["v13"].ToString();
                DifferGuest16_20 = dtHalf.Rows[i]["v14"].ToString();
                DifferGuest21_25 = dtHalf.Rows[i]["v15"].ToString();
                DifferGuest26 = dtHalf.Rows[i]["v16"].ToString();

                sb.Append(" exec [P_PassRateBasketEdit] '" + Day + "', '" + MatchNumber + "'," + LetMainLose + ",'" + LetMainWin + "','" + letscore + "','" + Big
                + "','" + Small + "','" + BigSmallscore + "','" + MainWin + "','" + Mainlose + "','" + DifferGuest1_5 + "','" + DifferGuest6_10 + "','" + DifferGuest11_15 + "','" + DifferGuest16_20 + "','" + DifferGuest21_25
                + "','" + DifferGuest26 + "','" + DifferMain1_5 + "','" + DifferMain6_10 + "','" + DifferMain11_15 + "','" + DifferMain16_20 + "','" + DifferMain21_25 + "','" + DifferMain26
                + "','" + uptime.ToString() + "'; ");
            }

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            if (result < 0)
            {
                new Log("1015").Write("获取篮球过关赔率数据执行失败");
            }
        }

        private void GetSporttoryOddsSingleRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_singleRate where State = 1", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetSporttoryOdds)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>1</type>";
            Body += "<valueType>0</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";
            int MainLoseball = 0;

            string win = "";
            string flat = "";
            string lose = "";

            string S1_0 = "";
            string S2_0 = "";
            string S2_1 = "";
            string S3_0 = "";
            string S3_1 = "";
            string S3_2 = "";
            string S4_0 = "";
            string S4_1 = "";
            string S4_2 = "";
            string S5_0 = "";
            string S5_1 = "";
            string S5_2 = "";
            string SOther = "";
            string P0_0 = "";
            string P1_1 = "";
            string P2_2 = "";
            string P3_3 = "";
            string POther = "";
            string F0_1 = "";
            string F0_2 = "";
            string F1_2 = "";
            string F0_3 = "";
            string F1_3 = "";
            string F2_3 = "";
            string F0_4 = "";
            string F1_4 = "";
            string F2_4 = "";
            string F0_5 = "";
            string F1_5 = "";
            string F2_5 = "";
            string FOther = "";

            string in0 = "";
            string in1 = "";
            string in2 = "";
            string in3 = "";
            string in4 = "";
            string in5 = "";
            string in6 = "";
            string in7 = "";

            string SS = "";
            string SP = "";
            string SF = "";
            string PS = "";
            string PP = "";
            string PF = "";
            string FS = "";
            string FP = "";
            string FF = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainLoseball = Shove._Convert.StrToInt(dtVS.Rows[i]["letPoint"].ToString(), 0);
                win = dtVS.Rows[i]["v3"].ToString();
                flat = dtVS.Rows[i]["v1"].ToString();
                lose = dtVS.Rows[i]["v0"].ToString();

                S1_0 = dtScore.Rows[i]["v10"].ToString();
                S2_0 = dtScore.Rows[i]["v20"].ToString();
                S2_1 = dtScore.Rows[i]["v21"].ToString();
                S3_0 = dtScore.Rows[i]["v30"].ToString();
                S3_1 = dtScore.Rows[i]["v31"].ToString();
                S3_2 = dtScore.Rows[i]["v32"].ToString();
                S4_0 = dtScore.Rows[i]["v40"].ToString();
                S4_1 = dtScore.Rows[i]["v41"].ToString();
                S4_2 = dtScore.Rows[i]["v42"].ToString();
                S5_0 = dtScore.Rows[i]["v50"].ToString();
                S5_1 = dtScore.Rows[i]["v51"].ToString();
                S5_2 = dtScore.Rows[i]["v52"].ToString();
                SOther = dtScore.Rows[i]["v90"].ToString();
                P0_0 = dtScore.Rows[i]["v00"].ToString();
                P1_1 = dtScore.Rows[i]["v11"].ToString();
                P2_2 = dtScore.Rows[i]["v22"].ToString();
                P3_3 = dtScore.Rows[i]["v33"].ToString();
                POther = dtScore.Rows[i]["v99"].ToString();
                F0_1 = dtScore.Rows[i]["v01"].ToString();
                F0_2 = dtScore.Rows[i]["v02"].ToString();
                F1_2 = dtScore.Rows[i]["v12"].ToString();
                F0_3 = dtScore.Rows[i]["v03"].ToString();
                F1_3 = dtScore.Rows[i]["v13"].ToString();
                F2_3 = dtScore.Rows[i]["v23"].ToString();
                F0_4 = dtScore.Rows[i]["v04"].ToString();
                F1_4 = dtScore.Rows[i]["v14"].ToString();
                F2_4 = dtScore.Rows[i]["v24"].ToString();
                F0_5 = dtScore.Rows[i]["v05"].ToString();
                F1_5 = dtScore.Rows[i]["v15"].ToString();
                F2_5 = dtScore.Rows[i]["v25"].ToString();
                FOther = dtScore.Rows[i]["v09"].ToString();

                in0 = dtGoal.Rows[i]["v0"].ToString();
                in1 = dtGoal.Rows[i]["v1"].ToString();
                in2 = dtGoal.Rows[i]["v2"].ToString();
                in3 = dtGoal.Rows[i]["v3"].ToString();
                in4 = dtGoal.Rows[i]["v4"].ToString();
                in5 = dtGoal.Rows[i]["v5"].ToString();
                in6 = dtGoal.Rows[i]["v6"].ToString();
                in7 = dtGoal.Rows[i]["v7"].ToString();

                SS = dtHalf.Rows[i]["v33"].ToString();
                SP = dtHalf.Rows[i]["v31"].ToString();
                SF = dtHalf.Rows[i]["v30"].ToString();
                PS = dtHalf.Rows[i]["v13"].ToString();
                PP = dtHalf.Rows[i]["v11"].ToString();
                PF = dtHalf.Rows[i]["v10"].ToString();
                FS = dtHalf.Rows[i]["v03"].ToString();
                FP = dtHalf.Rows[i]["v01"].ToString();
                FF = dtHalf.Rows[i]["v00"].ToString();

                sb.Append(" exec [P_SingleRateEdit] '" + Day + "', '" + MatchNumber + "'," + MainLoseball.ToString() + ",'" + win + "','" + flat + "','" + lose
                + "','" + S1_0 + "','" + S2_0 + "','" + S2_1 + "','" + S3_0 + "','" + S3_1 + "','" + S3_2 + "','" + S4_0 + "','" + S4_1 + "','" + S4_2
                + "','" + S5_0 + "','" + S5_1 + "','" + S5_2 + "','" + SOther + "','" + P0_0 + "','" + P1_1 + "','" + P2_2 + "','" + P3_3 + "','" + POther + "','" + F0_1
                + "','" + F0_2 + "','" + F1_2 + "','" + F0_3 + "','" + F1_3 + "','" + F2_3 + "','" + F0_4 + "','" + F1_4 + "','" + F2_4 + "','" + F0_5 + "','" + F1_5
                + "','" + F2_5 + "','" + FOther + "','" + in0 + "','" + in1 + "','" + in2 + "','" + in3 + "','" + in4 + "','" + in5 + "','" + in6 + "','" + in7
                + "','" + SS + "','" + SP + "','" + SF + "','" + PS + "','" + PP + "','" + PF + "','" + FS + "','" + FP + "','" + FF
                + "','" + uptime.ToString() + "'; ");
            }

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);

            if (result < 0)
            {
                new Log("1015").Write("获取足球单关赔率数据执行失败");
            }
        }

        private void GetBasketballOddsSingleRate()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select [DAY], MatchNumber from T_SingleRateBasket", null);

            if (dt == null)
            {
                log.Write("读取竞彩比赛信息(GetBasketballOddsSingleRate)：读取方案错误。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Body = "";
            Body += "<?xml version=\"1.0\" encoding=\"utf-8\"?><body>";
            Body += "<type>0</type>";
            Body += "<valueType>0</valueType>";
            Body += "<matchList>";

            foreach (DataRow dr in dt.Rows)
            {
                Body += "<id>" + dr["DAY"].ToString() + "_";
                Body += GetDayFromWeek(dr["MatchNumber"].ToString().Substring(0, 2)) + "_";
                Body += dr["MatchNumber"].ToString().Substring(2) + "</id>";
            }

            Body += "</matchList></body>";

            Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

            string MessageID = ElectronTicket_CTTCSD_UserName + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + "99";

            string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
            Message += "<message>";
            Message += "<head>";
            Message += "<version>1500</version>";
            Message += "<command>1018</command>";
            Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
            Message += "<messageId>" + MessageID + "</messageId>";
            Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
            Message += "</head>";
            Message += "<body>";
            Message += Body;
            Message += "</body>";
            Message += "</message>";

            //new Log("1018").Write(Message);

            string ReceiveString = "";

            try
            {
                ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, 120);
            }
            catch
            {
                return;
            }

            if (ReceiveString.Length <= 10)
            {
                return;
            }

            //WriteElectronTicketLog(true, "1018", ReceiveString);

            ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

            new Log("1018").Write(ReceiveString);

            string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

            DataSet ds = new DataSet();

            ds.ReadXml(new StringReader(elements));

            if (ds == null)
            {
                return;
            }

            if (ds.Tables.Count < 6)
            {
                return;
            }

            string Id = "";
            string Day = "";
            string MatchNumber = "";

            string LetMainLose = "";
            string LetMainWin = "";
            string letscore = "";
            string Big = "";
            string Small = "";
            string BigSmallscore = "";
            string MainWin = "";
            string Mainlose = "";
            string DifferGuest1_5 = "";
            string DifferGuest6_10 = "";
            string DifferGuest11_15 = "";
            string DifferGuest16_20 = "";
            string DifferGuest21_25 = "";
            string DifferGuest26 = "";
            string DifferMain1_5 = "";
            string DifferMain6_10 = "";
            string DifferMain11_15 = "";
            string DifferMain16_20 = "";
            string DifferMain21_25 = "";
            string DifferMain26 = "";

            DateTime uptime = DateTime.Now;

            StringBuilder sb = new StringBuilder();

            DataTable dtTeamInfo = ds.Tables[1];

            if (dtTeamInfo.Rows.Count < 1)
            {
                return;
            }

            DataTable dtVS = ds.Tables[2];
            DataTable dtScore = ds.Tables[3];
            DataTable dtGoal = ds.Tables[4];
            DataTable dtHalf = ds.Tables[5];

            for (int i = 0; i < dtVS.Rows.Count; i++)
            {
                Id = dtTeamInfo.Rows[i]["id"].ToString();

                Day = Id.Split('_')[0].ToString();
                MatchNumber = GetWeekDescprtion(Id.Split('_')[1].ToString()) + Id.Split('_')[2].ToString();

                MainWin = dtVS.Rows[i]["v3"].ToString();
                Mainlose = dtVS.Rows[i]["v0"].ToString();

                //LetMainLose = dtScore.Rows[i]["v3"].ToString();
                //LetMainWin = dtScore.Rows[i]["v0"].ToString();
                LetMainLose = dtScore.Rows[i]["v0"].ToString();
                LetMainWin = dtScore.Rows[i]["v3"].ToString();

                letscore = dtScore.Rows[i]["letPoint"].ToString();

                BigSmallscore = dtGoal.Rows[i]["basePoint"].ToString();
                Big = dtGoal.Rows[i]["g"].ToString();
                Small = dtGoal.Rows[i]["l"].ToString();

                //DifferGuest1_5 = dtHalf.Rows[i]["v01"].ToString();
                //DifferGuest6_10 = dtHalf.Rows[i]["v02"].ToString();
                //DifferGuest11_15 = dtHalf.Rows[i]["v03"].ToString();
                //DifferGuest16_20 = dtHalf.Rows[i]["v04"].ToString();
                //DifferGuest21_25 = dtHalf.Rows[i]["v05"].ToString();
                //DifferGuest26 = dtHalf.Rows[i]["v06"].ToString();
                //DifferMain1_5 = dtHalf.Rows[i]["v11"].ToString();
                //DifferMain6_10 = dtHalf.Rows[i]["v12"].ToString();
                //DifferMain11_15 = dtHalf.Rows[i]["v13"].ToString();
                //DifferMain16_20 = dtHalf.Rows[i]["v14"].ToString();
                //DifferMain21_25 = dtHalf.Rows[i]["v15"].ToString();
                //DifferMain26 = dtHalf.Rows[i]["v16"].ToString();

                DifferMain1_5 = dtHalf.Rows[i]["v01"].ToString();
                DifferMain6_10 = dtHalf.Rows[i]["v02"].ToString();
                DifferMain11_15 = dtHalf.Rows[i]["v03"].ToString();
                DifferMain16_20 = dtHalf.Rows[i]["v04"].ToString();
                DifferMain21_25 = dtHalf.Rows[i]["v05"].ToString();
                DifferMain26 = dtHalf.Rows[i]["v06"].ToString();
                DifferGuest1_5 = dtHalf.Rows[i]["v11"].ToString();
                DifferGuest6_10 = dtHalf.Rows[i]["v12"].ToString();
                DifferGuest11_15 = dtHalf.Rows[i]["v13"].ToString();
                DifferGuest16_20 = dtHalf.Rows[i]["v14"].ToString();
                DifferGuest21_25 = dtHalf.Rows[i]["v15"].ToString();
                DifferGuest26 = dtHalf.Rows[i]["v16"].ToString();

                sb.Append(" exec [P_SingleRateBasketEdit] '" + Day + "', '" + MatchNumber + "'," + LetMainLose + ",'" + LetMainWin + "','" + letscore + "','" + Big
                + "','" + Small + "','" + BigSmallscore + "','" + MainWin + "','" + Mainlose + "','" + DifferGuest1_5 + "','" + DifferGuest6_10 + "','" + DifferGuest11_15 + "','" + DifferGuest16_20 + "','" + DifferGuest21_25
                + "','" + DifferGuest26 + "','" + DifferMain1_5 + "','" + DifferMain6_10 + "','" + DifferMain11_15 + "','" + DifferMain16_20 + "','" + DifferMain21_25 + "','" + DifferMain26
                + "','" + uptime.ToString() + "'; ");
            }

            int result = MSSQL.ExecuteNonQuery(ConnectionString, sb.ToString(), null);
            if (result < 0)
            {
                new Log("1015").Write("获取篮球单关赔率数据执行失败");
            }
        }

        /// <summary>
        /// 查询竞彩赛果
        /// </summary>
        private void GetSporttoryResult()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select StopSellingTime, MatchNumber, ID from T_Match where IsOpened = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("查询竞彩赛果错误(GetSporttoryResult)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + ((99 - i) % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>1</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1017</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                //new Log("1017").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                //WriteElectronTicketLog(false, "1017", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1017").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 3)
                {
                    continue;
                }

                DataTable dtResult = ds.Tables[1];
                DataTable dtBonus = ds.Tables[2];

                foreach (DataRow dr in dtResult.Rows)
                {
                    string FirstHalfResult = dr["firstHalfResult"].ToString();
                    string Result = dr["result"].ToString();

                    string SPFResult = "";
                    string BQCResult = "";
                    string ZJQSResult = "";
                    string ZQBFResult = "";

                    int letPoint = Shove._Convert.StrToInt(dr["letPoint"].ToString(), 0);
                    //Result = (int.Parse(Result.Split(':')[0]) + letPoint ).ToString() + ":" + Result.Split(':')[1];

                    MatchResult(Result, letPoint, FirstHalfResult, ref SPFResult, ref BQCResult, ref ZJQSResult, ref ZQBFResult);

                    MSSQL.ExecuteNonQuery(ConnectionString, "Update T_Match set SPFResult = '" + SPFResult + "', BQCResult = '" + BQCResult + "', ZJQSResult = '" + ZJQSResult + "', ZQBFResult = '" + ZQBFResult + "',Result='" + Result + "', FirstHalfResult='" + FirstHalfResult + "', SPFBonus = '" + dtBonus.Rows[0]["b0"] + "', BQCBonus = '" + dtBonus.Rows[0]["b6"] + "', ZJQSBonus = '" + dtBonus.Rows[0]["b5"] + "', ZQBFBonus = '" + dtBonus.Rows[0]["b4"] + "' where ID = " + dt.Rows[i]["ID"].ToString(), null);
                }

                #endregion
            }
        }

        /// <summary>
        /// 查询批量投注中奖明细接口  [暂未使用]
        /// </summary>
        private void GetSporttoryOpenWin()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select ID,Identifiers from T_Schemes where Buyed = 1 and isOpened = 0 and isnull(Identifiers,'') <> '' and ID = 735", null);

            if (dt == null)
            {
                log.Write("获取方案Identifiers[MessageId]错误(GetSporttoryOpenWin)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + (i % 100).ToString().PadLeft(2, '0');

                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><messageId>" + dt.Rows[i]["Identifiers"] + "</messageId></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1002</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                new Log("1002").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                WriteElectronTicketLog(false, "1002", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1016").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 2)
                {
                    continue;
                }

                DataTable dtFileName = ds.Tables[1];

                if (dtFileName.Rows.Count < 1)
                {
                    return;
                }

                foreach (DataRow dr in dtFileName.Rows)
                {
                    string id = dr["id"].ToString();                        // 序列号   
                    string bonusLevel = dr["bonusLevel"].ToString();        //等级名称
                    string bonusName = dr["bonusName"].ToString();          // 奖金等级
                    string bonusCount = dr["bonusCount"].ToString();        // 中奖注数
                    // 奖金(注数*每注金额)
                    double bonusValue = Shove._Convert.StrToDouble(dr["bonusValue"].ToString(), 0);

                    long SchemeID = Shove._Convert.StrToLong(dt.Rows[i]["ID"].ToString(), 0);
                    if (SchemeID < 1)
                    {
                        continue;
                    }

                    //int ReturnValue = 0;
                    //string ReturnDescription = "";

                    //int Result = DAL.Procedures.P_WinByOpenManual(ConnectionString, 1, SchemeID, bonusValue, bonusValue, "", 1, ref ReturnValue, ref ReturnDescription);

                    //if (Result < 0)
                    //{
                    //    new Log("1002").Write("方案开奖错误,SchemeID : " + SchemeID);
                    //}
                    //new Log("1002").Write("方案开奖成功： SchemeID : " + SchemeID + " ,中奖金额: " + bonusValue);
                }
                #endregion
            }
        }

        /// <summary>
        /// 查询竞彩赛果
        /// </summary>
        private void GetBasketballSporttoryResult()
        {
            DataTable dt = MSSQL.Select(ConnectionString, "select StopSellingTime, MatchNumber, ID from T_MatchBasket where isnull(IsOpened,0) = 0 and StopSellingTime between DATEADD(DAY, -4, GETDATE()) and  GETDATE()", null);

            if (dt == null)
            {
                log.Write("查询竞彩赛果错误(GetSporttoryResult)。");

                return;
            }

            if (dt.Rows.Count < 1)
            {
                return;
            }

            string Day = "";
            string Week = "";
            int gCount = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (i % 100 == 0)
                {
                    System.Threading.Thread.Sleep(1000);
                }

                #region 查询奖期

                DateTime Now = DateTime.Now;

                DateTime MatchDate = Shove._Convert.StrToDateTime(dt.Rows[i]["StopSellingTime"].ToString(), DateTime.Now.ToString());

                Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                gCount = 0;

                while (gCount < 7)
                {
                    if (Week.CompareTo(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) == 0)
                    {
                        break;
                    }

                    MatchDate = MatchDate.AddDays(-1);

                    Week = "周" + new System.Globalization.CultureInfo("zh-CN").DateTimeFormat.GetAbbreviatedDayName(Convert.ToDateTime(MatchDate).DayOfWeek);

                    gCount++;
                }

                Day = MatchDate.Year.ToString() + MatchDate.Month.ToString().PadLeft(2, '0') + MatchDate.Day.ToString().PadLeft(2, '0');

                string MessageID = ElectronTicket_CTTCSD_UserName + Now.ToString("yyyyMMdd") + Now.ToString("HHmmss") + ((99 - i) % 100).ToString().PadLeft(2, '0');
                string Body = "<?xml version=\"1.0\" encoding=\"utf-8\"?><body><type>0</type><matchList><id>" + Day + "_" + GetDayFromWeek(dt.Rows[i]["MatchNumber"].ToString().Substring(0, 2)) + "_" + dt.Rows[i]["MatchNumber"].ToString().Substring(2) + "</id></matchList></body>";

                Body = PublicFunction.EncryptDES(Body, ElectronTicket_CTTCSD_UserPassword);

                string Message = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                Message += "<message>";
                Message += "<head>";
                Message += "<version>1500</version>";
                Message += "<command>1017</command>";
                Message += "<venderId>" + ElectronTicket_CTTCSD_UserName + "</venderId>";
                Message += "<messageId>" + MessageID + "</messageId>";
                Message += "<md>" + Shove._Security.Encrypt.MD5(Body, "utf-8") + "</md>";
                Message += "</head>";
                Message += "<body>";
                Message += Body;
                Message += "</body>";
                Message += "</message>";

                //new Log("1017").Write(Message);

                string ReceiveString = "";

                try
                {
                    ReceiveString = PublicFunction.Post(ElectronTicket_CTTCSD_Getway, Message, TimeoutSeconds);
                }
                catch
                {
                    continue;
                }

                if (ReceiveString.Length <= 10)
                {
                    continue;
                }

                //WriteElectronTicketLog(false, "1017", ReceiveString);

                #endregion

                #region 处理结果

                System.Xml.XmlDocument XmlDoc = new XmlDocument();

                try
                {
                    XmlDoc.Load(new StringReader(ReceiveString));
                }
                catch
                {
                    continue;
                }

                ReceiveString = PublicFunction.DecryptDES(ReceiveString.Substring(ReceiveString.IndexOf("<body>") + 6, ReceiveString.LastIndexOf("</body>") - ReceiveString.IndexOf("<body>") - 6), ElectronTicket_CTTCSD_UserPassword).Replace("\r", "").Replace("\n", "");

                new Log("1017").Write(ReceiveString);

                string elements = ReceiveString.Substring(ReceiveString.IndexOf(">") + 1);

                DataSet ds = new DataSet();

                ds.ReadXml(new StringReader(elements));

                if (ds == null)
                {
                    return;
                }

                if (ds.Tables.Count == 0)
                {
                    return;
                }

                if (ds.Tables.Count < 3)
                {
                    continue;
                }

                DataTable dtResult = ds.Tables[1];
                DataTable dtBonus = ds.Tables[2];

                foreach (DataRow dr in dtResult.Rows)
                {
                    string LetPoint = dr["letPoint"].ToString();
                    string Result = dr["result"].ToString();
                    string BasePoint = dr["basePoint"].ToString();

                    string DXResult = "";
                    string RFSFResult = "";
                    string SFResult = "";
                    string SFCResult = "";

                    MatchBasketballResult(Result, LetPoint, BasePoint, ref DXResult, ref RFSFResult, ref SFResult, ref SFCResult);
                    try
                    {
                        Result = Result.Split(':')[1] + ":" + Result.Split(':')[0];
                    }
                    catch { }

                    MSSQL.ExecuteNonQuery(ConnectionString, "Update T_MatchBasket set DXResult = '" + DXResult + "', RFSFResult = '" + RFSFResult + "', SFResult = '" + SFResult + "', SFCResult = '" + SFCResult + "',Result='" + Result + "',DXBonus = '" + dtBonus.Rows[0]["b3"] + "', RFSFBonus = '" + dtBonus.Rows[0]["b1"] + "', SFBonus = '" + dtBonus.Rows[0]["b0"] + "', SFCBonus = '" + dtBonus.Rows[0]["b2"] + "' where ID = " + dt.Rows[i]["ID"].ToString(), null);
                }

                #endregion
            }
        }

        /// <summary>
        /// 竞彩开奖
        /// </summary>
        private void WinByOpenManual()
        {
            // 获取未开奖竞彩方案
            DataTable dtSchemes = new DAL.Tables.T_Schemes().Open(ConnectionString, "", "isOpened = 0 and PlayTypeID >= 7201 and PlayTypeID <= 7304 and QuashStatus = 0 and Buyed = 1 and DateTime > DATEADD(DD,-5,GETDATE()) ", "");

            if (dtSchemes == null)
            {
                new Log("WinByOpenManual").Write("竞彩方案开奖数据库连接失败 WinByOpenManual()");
            }
            if (dtSchemes.Rows.Count < 1)
            {
                return;
            }

            foreach (DataRow dr in dtSchemes.Rows)
            {
                // 投注内容
                string lotterNumber = dr["LotteryNumber"].ToString();

                string[] numbers = lotterNumber.Split(';');

                if (numbers.Length < 3)
                {
                    new Log("WinByOpenManual").Write("竞彩方案投注内容错误, 方案ID：" + dr["ID"].ToString());
                    continue;
                }
                // 投注内容
                //7201;[177(1)|178(1)][179(1)|180(1)|181(1)|182(1)];[AB1,AE1];[2]
                string content = "";
                string[] matchIds = numbers[1].Replace("][", "|").Split('|');

                for (int i = 0; i < matchIds.Length; i++)
                {
                    content += "," + matchIds[i].Substring(0, matchIds[i].IndexOf('('));
                }
                // 方案涉及的所以MatchID
                content = content.StartsWith(",") ? content.Substring(1) : content;
                content = content.StartsWith("[") ? content.Substring(1) : content;
                content = content.EndsWith("]") ? content.Substring(1) : content;

                object countObj = null;
                //= Shove.Database.MSSQL.ExecuteScalar(ConnectionString, "select COUNT(*) from T_Match where ID in (" + content + ") and IsOpened
                /* 根据玩法读取不同的赛事表*/
                int playType = Shove._Convert.StrToInt(dr["PlayTypeID"].ToString(), 0);
                if (playType >= 7201 && playType <= 7204)
                {
                    countObj = Shove.Database.MSSQL.ExecuteScalar(ConnectionString, "select COUNT(*) from T_Match where ID in (" + content + ") and IsOpened = 1");
                }
                else if (playType >= 7301 && playType <= 7304)
                {
                    countObj = Shove.Database.MSSQL.ExecuteScalar(ConnectionString, "select COUNT(*) from T_MatchBasket where ID in (" + content + ") and IsOpened = 1");
                }
                if (countObj == null || countObj == DBNull.Value)
                    continue;

                int count = Shove._Convert.StrToInt(countObj.ToString(), 0);

                // 效验是否全部已开
                if (matchIds.Length == count)
                {
                    int result = 0;
                    string resultValue = "";
                    long schemeId = Shove._Convert.StrToLong(dr["ID"].ToString(), 0);
                    // 中奖金额总汇
                    double winMoney = 0;
                    // 查询 票表中属于此方案的票，累加单张票的中奖金额
                    DataTable dtTickCenter = Shove.Database.MSSQL.Select(ConnectionString, "select HandleDescription from T_SchemesSendToCenter where isnull(HandleDescription,'') <> '' and SchemeID = " + schemeId);
                    if (dtTickCenter == null || dtTickCenter.Rows.Count <= 0)
                    {
                        winMoney = 0;
                    }
                    else
                    {
                        foreach (DataRow drtick in dtTickCenter.Rows)
                        {
                            double tickWin = 0;
                            if (drtick["HandleDescription"] != null && drtick["HandleDescription"] != DBNull.Value)
                                tickWin = Shove._Convert.StrToDouble(drtick["HandleDescription"].ToString(), 0);
                            winMoney += tickWin;
                        }
                    }

                    if (DAL.Procedures.P_WinByOpenManual(ConnectionString, 1, schemeId, winMoney, winMoney, "", 1, ref result, ref resultValue) < 0)
                    {
                        new Log("WinByOpenManual").Write("竞彩方案开奖失败, 方案ID：" + schemeId.ToString());
                        continue;
                    }
                    if (result < 0)
                    {
                        new Log("WinByOpenManual").Write("竞彩方案开奖出现异常, 方案ID：" + schemeId.ToString() + "异常简介：" + resultValue);
                        continue;
                    }
                    new Log("WinByOpenManual").Write("竞彩方案开奖成功, 方案ID：" + dr["ID"] + " 中奖金额：" + winMoney);
                }
            }
        }

        #endregion

        #region 公共方法

        private string GetFromXPath(string XML, string XPath)
        {
            if (XML.Trim() == "")
                return "";

            string Result = "";
            try
            {
                XPathDocument doc = new XPathDocument(new StringReader(XML));
                XPathNavigator nav = doc.CreateNavigator();
                XPathNodeIterator nodes = nav.Select(XPath);
                while (nodes.MoveNext())
                    Result += nodes.Current.Value;
            }
            catch//(Exception ee)
            {
                return "";
                //return ee.Message;
            }

            return Result;
        }

        private string GetGameName(int LotteryID)
        {
            switch (LotteryID)
            {
                case 74:
                    return "D14";
                case 75:
                    return "D9";
                case 2:
                    return "C4";
                case 3:
                    return "D7";
                case 9:
                    return "C522";
                case 15:
                    return "C12";
                case 39:
                    return "T001";
                case 62:
                    return "C511";
                case 63:
                    return "D3";
                case 64:
                    return "D5";
                case 65:
                    return "C731";
                default:
                    return "";
            }
        }

        private string GetPlayName(int PlayTypeID)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    return "FT001";
                case 7202:
                    return "FT002";
                case 7203:
                    return "FT003";
                case 7204:
                    return "FT004";
                case 7301:
                    return "BSK001";
                case 7302:
                    return "BSK002";
                case 7303:
                    return "BSK003";
                case 7304:
                    return "BSK004";
                default:
                    return "";
            }
        }

        private string GetSporttoryLotteryNumber(int PlayTypeID, string Number)
        {
            switch (PlayTypeID)
            {
                case 7201:
                    switch (Number)
                    {
                        case "1":
                            return "3";
                        case "2":
                            return "1";
                        case "3":
                            return "0";
                        default:
                            return "0";
                    }
                case 7202:
                    switch (Number)
                    {
                        case "10":
                            return "50";
                        case "11":
                            return "51";
                        case "12":
                            return "52";
                        case "13":
                            return "90";
                        case "14":
                            return "00";
                        case "15":
                            return "11";
                        case "16":
                            return "22";
                        case "17":
                            return "33";
                        case "18":
                            return "99";
                        case "19":
                            return "01";
                        case "20":
                            return "02";
                        case "21":
                            return "12";
                        case "22":
                            return "03";
                        case "23":
                            return "13";
                        case "24":
                            return "23";
                        case "25":
                            return "04";
                        case "26":
                            return "14";
                        case "27":
                            return "24";
                        case "28":
                            return "05";
                        case "29":
                            return "15";
                        case "30":
                            return "25";
                        case "31":
                            return "09";
                        case "1":
                            return "10";
                        case "2":
                            return "20";
                        case "3":
                            return "21";
                        case "4":
                            return "30";
                        case "5":
                            return "31";
                        case "6":
                            return "32";
                        case "7":
                            return "40";
                        case "8":
                            return "41";
                        case "9":
                            return "42";
                        default:
                            return "";
                    }
                case 7203:
                    switch (Number)
                    {
                        case "1":
                            return "0";
                        case "2":
                            return "1";
                        case "3":
                            return "2";
                        case "4":
                            return "3";
                        case "5":
                            return "4";
                        case "6":
                            return "5";
                        case "7":
                            return "6";
                        case "8":
                            return "7";
                        default:
                            return "";
                    }
                case 7204:
                    switch (Number)
                    {
                        case "1":
                            return "33";
                        case "2":
                            return "31";
                        case "3":
                            return "30";
                        case "4":
                            return "13";
                        case "5":
                            return "11";
                        case "6":
                            return "10";
                        case "7":
                            return "03";
                        case "8":
                            return "01";
                        case "9":
                            return "00";
                        default:
                            return "";
                    }
                case 7301:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7302:
                    switch (Number)
                    {
                        case "2":
                            return "3";
                        case "1":
                            return "0";
                        default:
                            return "0";
                    }
                case 7303:
                    switch (Number)
                    {
                        case "12":
                            return "16";
                        case "11":
                            return "15";
                        case "10":
                            return "14";
                        case "9":
                            return "13";
                        case "8":
                            return "12";
                        case "7":
                            return "11";
                        case "6":
                            return "06";
                        case "5":
                            return "05";
                        case "4":
                            return "04";
                        case "3":
                            return "03";
                        case "2":
                            return "02";
                        case "1":
                            return "01";
                        default:
                            return "01";
                    }
                case 7304:
                    return Number;
                default:
                    return "";
            }
        }

        private int GetLotteryID(string gameName)
        {
            switch (gameName)
            {
                case "D14":
                    return 74;
                case "D9":
                    return 75;
                case "C4":
                    return 2;
                case "D7":
                    return 3;
                case "C522":
                    return 9;
                case "C12":
                    return 15;
                case "T001":
                    return 39;
                case "C511":
                    return 62;
                case "D3":
                    return 63;
                case "D5":
                    return 64;
                case "C731":
                    return 65;
                default:
                    return -1;
            }
        }

        //写日志文件
        public void WriteElectronTicketLog(bool isSend, string TransType, string TransMessage)
        {
            log.Write("isSend: " + isSend.ToString() + "\tTransType: " + TransType + "\t" + TransMessage);
        }

        private string GetWeekDescprtion(string Day)
        {
            switch (Day)
            {
                case "1":
                    return "周一";
                case "2":
                    return "周二";
                case "3":
                    return "周三";
                case "4":
                    return "周四";
                case "5":
                    return "周五";
                case "6":
                    return "周六";
                case "7":
                    return "周日";
                default:
                    return "";

            }

        }

        private string GetDayFromWeek(string Day)
        {
            switch (Day)
            {
                case "周一":
                    return "1";
                case "周二":
                    return "2";
                case "周三":
                    return "3";
                case "周四":
                    return "4";
                case "周五":
                    return "5";
                case "周六":
                    return "6";
                case "周日":
                    return "7";
                default:
                    return "";

            }

        }

        private void MatchResult(string Result, int letPoint, string FirstHalfResult, ref string SPFResult, ref string BQCResult, ref string ZJQSResult, ref string ZQBFResult)
        {
            int MainResult = 0;
            int GuestResult = 0;
            int MainHalfResult = 0;
            int GuestHalfResult = 0;

            MainResult = Shove._Convert.StrToInt(Result.Split(':')[0], 0);
            GuestResult = Shove._Convert.StrToInt(Result.Split(':')[1], 0);
            MainHalfResult = Shove._Convert.StrToInt(FirstHalfResult.Split(':')[0], 0);
            GuestHalfResult = Shove._Convert.StrToInt(FirstHalfResult.Split(':')[1], 0);

            if (MainResult > GuestResult)
            {
                if (MainHalfResult > GuestHalfResult)
                {
                    BQCResult = "胜胜";
                }
                else if (MainHalfResult == GuestHalfResult)
                {
                    BQCResult = "平胜";
                }
                else
                {
                    BQCResult = "负胜";
                }
            }
            else if (MainResult == GuestResult)
            {
                if (MainHalfResult > GuestHalfResult)
                {
                    BQCResult = "胜平";
                }
                else if (MainHalfResult == GuestHalfResult)
                {
                    BQCResult = "平平";
                }
                else
                {
                    BQCResult = "负平";
                }
            }
            else
            {
                if (MainHalfResult > GuestHalfResult)
                {
                    BQCResult = "胜负";
                }
                else if (MainHalfResult == GuestHalfResult)
                {
                    BQCResult = "平负";
                }
                else
                {
                    BQCResult = "负负";
                }
            }

            if (MainResult + letPoint > GuestResult)
            {
                SPFResult = "胜";
            }
            else if (MainResult + letPoint == GuestResult)
            {
                SPFResult = "平";
            }
            else
            {
                SPFResult = "负";
            }

            ZJQSResult = (MainResult + GuestResult) > 6 ? "7+" : (MainResult + GuestResult).ToString();
            ZQBFResult = MainResult.ToString() + ":" + GuestResult.ToString();
        }

        private void MatchBasketballResult(string Result, string LetPoint, string BasePoint, ref string DXResult, ref string RFSFResult, ref string SFResult, ref string SFCResult)
        {
            double MainResult = 0;
            double GuestResult = 0;
            double LetPointResult = 0;
            double BasePointResult = Shove._Convert.StrToDouble(BasePoint, 0);

            MainResult = Shove._Convert.StrToDouble(Result.Split(':')[0], 0);
            GuestResult = Shove._Convert.StrToDouble(Result.Split(':')[1], 0);
            LetPointResult = MainResult + Shove._Convert.StrToDouble(LetPoint, 0);

            if (MainResult > GuestResult)
            {
                SFResult = "主胜";

                if (MainResult - GuestResult > 25)
                {
                    SFCResult = "主胜26+";
                }
                else if (MainResult - GuestResult < 5)
                {
                    SFCResult = "主胜1-5";
                }
                else if (MainResult - GuestResult < 11)
                {
                    SFCResult = "主胜6-10";
                }
                else if (MainResult - GuestResult < 16)
                {
                    SFCResult = "主胜11-15";
                }
                else if (MainResult - GuestResult < 21)
                {
                    SFCResult = "主胜16-20";
                }
                else if (MainResult - GuestResult < 26)
                {
                    SFCResult = "主胜21-25";
                }
            }
            else
            {
                SFResult = "主负";

                if (GuestResult - MainResult > 25)
                {
                    SFCResult = "客胜26+";
                }
                else if (GuestResult - MainResult < 5)
                {
                    SFCResult = "客胜1-5";
                }
                else if (GuestResult - MainResult < 11)
                {
                    SFCResult = "客胜6-10";
                }
                else if (GuestResult - MainResult < 16)
                {
                    SFCResult = "客胜11-15";
                }
                else if (GuestResult - MainResult < 21)
                {
                    SFCResult = "客胜16-20";
                }
                else if (GuestResult - MainResult < 26)
                {
                    SFCResult = "客胜21-25";
                }
            }

            if (LetPointResult > GuestResult)
            {
                RFSFResult = "主胜";
            }
            else
            {
                RFSFResult = "主负";
            }

            if (BasePointResult > (MainResult + GuestResult))
            {
                DXResult = "小";
            }
            else
            {
                DXResult = "大";
            }
        }
        #endregion

        #region 分析中奖描述、奖等

        private class CompareToLength : IComparer
        {
            int IComparer.Compare(Object x, Object y)
            {
                long _x = Shove._Convert.StrToLong(x.ToString(), -1);
                long _y = Shove._Convert.StrToLong(y.ToString(), -1);

                return _x.CompareTo(_y);
            }
        }
        #endregion
    }
}