using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

namespace SLS.Cttcsd.Task
{
    public class PublicFunction
    {
        public static string GetCallCert()
        {
            string Result = "";

            Result = "ShoveSoft";
            Result += " ";
            Result += "CO.,Ltd ";

            string Result2 = Shove._String.Reverse(Result);

            Result = "--";
            Result += " by Shove ";

            Result = Shove._String.Reverse(Result2) + Result;

            Result2 = Shove._String.Reverse(Result);

            Result = "20050709";
            Result += Shove._String.Reverse("���� ");
            Result += Shove._String.Reverse("����");

            Result = Shove._String.Reverse(Result);

            Result = Shove._String.Reverse(Result2) + Shove._String.Reverse(Result);

            return Result;
        }

        // ��ȡ Url ���ص� Html ��
        public static string Post(string Url, string RequestString, int TimeoutSeconds)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);

            if (TimeoutSeconds > 0)
            {
                request.Timeout = 1000 * TimeoutSeconds;
            }
            request.Method = "POST";
            request.AllowAutoRedirect = true;

            byte[] data = System.Text.Encoding.GetEncoding("GBK").GetBytes(RequestString);

            request.ContentType = "application/x-www-form-urlencoded";
            request.Accept = "";
            Stream outstream = request.GetRequestStream();

            outstream.Write(data, 0, data.Length);
            outstream.Close();

            HttpWebResponse hwrp = (HttpWebResponse)request.GetResponse();
            string ContentType = hwrp.Headers.Get("Content-Type");

            StreamReader sr = null;

            sr = new StreamReader(hwrp.GetResponseStream(), System.Text.Encoding.GetEncoding("GBK"));

            return sr.ReadToEnd();
        }

        // ��ȡ Url ���ص� Html ��
        public static string GetHtml(string Url, string encodeing, int TimeoutSeconds)
        {
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            StreamReader reader = null;
            try
            {
                request = (HttpWebRequest)WebRequest.Create(Url);
                request.UserAgent = "www.svnhost.cn";
                if (TimeoutSeconds > 0)
                {
                    request.Timeout = 1000 * TimeoutSeconds;
                }
                request.AllowAutoRedirect = false;

                response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.GetEncoding(encodeing));
                    string html = reader.ReadToEnd();
                    return html;
                }
                else
                {
                    return "";
                }
            }
            catch (SystemException)
            {
                return "";
            }
        }

        ///   <summary> 
        ///   3des�����ַ��� 
        ///   </summary> 
        ///   <param   name= "a_strString "> Ҫ���ܵ��ַ��� </param> 
        ///   <param   name= "a_strKey "> ��Կ </param> 
        ///   <returns> ���ܺ󲢾�base64������ַ��� </returns> 
        ///   <remarks> ��̬����������Ĭ��ascii���� </remarks> 
        public static string EncryptDES(string a_strString, string a_strKey)
        {
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            des.Mode = CipherMode.ECB;
            des.Padding = PaddingMode.PKCS7;
            des.IV = StringToKey(a_strKey);
            des.Key = StringToKey(a_strKey);
            des.BlockSize = 64;
            byte[] bytes = Encoding.UTF8.GetBytes(a_strString);
            byte[] resultBytes = des.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length);

            return Convert.ToBase64String(resultBytes, Base64FormattingOptions.None);
        }

        public static byte[] StringToKey(String key_str)
        {
            byte[] k = new byte[8];
            for (int i = 0; i < key_str.Length; i += 2)
            {
                k[i / 2] = (byte)Convert.ToInt32(key_str.Substring(i, 2), 16);
            }
            return k;
        }

        private static byte[] strToToHexByte(string hexString)
        {
            byte[] returnBytes = new byte[hexString.Length / 2];
            for (int i = 0; i < returnBytes.Length; i++)
                returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            return returnBytes;
        }



        ///   <summary> 
        ///   3des�����ַ��� 
        ///   </summary> 
        ///   <param   name= "a_strString "> Ҫ���ܵ��ַ��� </param> 
        ///   <param   name= "a_strKey "> ��Կ </param> 
        ///   <returns> ���ܺ���ַ��� </returns> 
        ///   <exception   cref= " "> ��Կ���� </exception> 
        ///   <remarks> ��̬����������Ĭ��ascii���� </remarks> 
        public static string DecryptDES(string a_strString, string a_strKey)
        {
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            des.Mode = CipherMode.ECB;
            des.Padding = PaddingMode.PKCS7;
            des.IV = StringToKey(a_strKey);
            des.Key = StringToKey(a_strKey);
            des.BlockSize = 64;

            byte[] bytes = Convert.FromBase64String(a_strString);

            byte[] resultBytes = des.CreateDecryptor().TransformFinalBlock(bytes, 0, bytes.Length);

            return System.Text.Encoding.UTF8.GetString(resultBytes);
        }
    }
}
