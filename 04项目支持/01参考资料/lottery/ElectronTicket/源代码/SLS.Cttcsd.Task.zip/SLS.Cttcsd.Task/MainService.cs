﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace SLS.Cttcsd.Task
{
    public partial class MainService : ServiceBase
    {
        private string ConnectionString = "";
        private string SporLotteryConnectionString = "";

        private ElectronTicket_CTTCSD ElectronTicket_CTTCSD_Task = null;
        private ElectronTicket_Sporttery ElectronTicket_Sporttery_Task = null;

        public MainService()
        {
            InitializeComponent();
            Shove._IO.IniFile ini = new Shove._IO.IniFile(System.AppDomain.CurrentDomain.BaseDirectory + "Config.ini");
            ConnectionString = ini.Read("Options", "ConnectionString");
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                System.Data.SqlClient.SqlConnection conn = Shove.Database.MSSQL.CreateDataConnection<System.Data.SqlClient.SqlConnection>(ConnectionString);

                while (conn.State != ConnectionState.Open)
                {
                    conn.Open();

                    new Log("System").Write("ConnectionString数据库连接失败");

                    System.Threading.Thread.Sleep(1000);
                }

                conn.Close();
            }
            catch (Exception e)
            {
                new Log("System").Write(e.Message);
            }

            SystemOptions so = new SystemOptions(ConnectionString);

            // 彩通天成竞彩电子票自动任务
            try
            {
                if (so["ElectronTicket_CTTCSD_Status_ON"].ToBoolean(false) && (new DAL.Tables.T_Lotteries().GetCount(ConnectionString, "PrintOutType = 108") > 0))
                {
                    ElectronTicket_CTTCSD_Task = new ElectronTicket_CTTCSD(ConnectionString);

                    ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_Getway = so["ElectronTicket_CTTCSD_Getway"].ToString("");
                    ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_UserName = so["ElectronTicket_CTTCSD_UserName"].ToString("");
                    ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_UserPassword = so["ElectronTicket_CTTCSD_UserPassword"].ToString("");
                    ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_DownloadGetway = so["ElectronTicket_CTTCSD_DownloadGetway"].ToString("");
                    ElectronTicket_CTTCSD_Task.ElectronTicket_PrintOut_IDCardNumber = so["ElectronTicket_CTTCSD_PrintOut_IDCardNumber"].ToString("");
                    ElectronTicket_CTTCSD_Task.ElectronTicket_PrintOut_Mobile = so["ElectronTicket_CTTCSD_PrintOut_Mobile"].ToString("");

                    if ((ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_Getway != "") && (ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_UserName != "") && (ElectronTicket_CTTCSD_Task.ElectronTicket_CTTCSD_UserPassword != ""))
                    {
                        ElectronTicket_CTTCSD_Task.Run();
                    }
                }
            }
            catch (Exception e)
            {
                new Log("System").Write("ElectronTicket_CTTCSD 启动失败：" + e.Message);
            }
           
            try
            {
                if (so["ElectronTicket_CTTCSD_Status_ON"].ToBoolean(false) && (new DAL.Tables.T_Lotteries().GetCount(ConnectionString, "PrintOutType = 108 and id in (72, 73)") > 0))
                {
                    ElectronTicket_Sporttery_Task = new ElectronTicket_Sporttery(ConnectionString);

                    ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_Getway = so["ElectronTicket_CTTCSD_Getway"].ToString("");
                    ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_UserName = so["ElectronTicket_CTTCSD_UserName"].ToString("");
                    ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_UserPassword = so["ElectronTicket_CTTCSD_UserPassword"].ToString("");
                    ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_DownloadGetway = so["ElectronTicket_CTTCSD_DownloadGetway"].ToString("");
                    ElectronTicket_Sporttery_Task.ElectronTicket_PrintOut_IDCardNumber = so["ElectronTicket_CTTCSD_PrintOut_IDCardNumber"].ToString("");
                    ElectronTicket_Sporttery_Task.ElectronTicket_PrintOut_Mobile = so["ElectronTicket_CTTCSD_PrintOut_Mobile"].ToString("");

                    if ((ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_Getway != "") && (ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_UserName != "") && (ElectronTicket_Sporttery_Task.ElectronTicket_CTTCSD_UserPassword != ""))
                    {
                        ElectronTicket_Sporttery_Task.Run();
                    }
                }

            }
            catch (Exception e)
            {
                new Log("System").Write("ElectronTicket_Sporttery_Task 启动失败：" + e.Message);
            }
        }

        protected override void OnStop()
        {
            if (ElectronTicket_CTTCSD_Task != null)
            {
                ElectronTicket_CTTCSD_Task.Exit();
            }

            if (ElectronTicket_Sporttery_Task != null)
            {
                ElectronTicket_Sporttery_Task.Exit();
            }

            while ((ElectronTicket_CTTCSD_Task != null) && (ElectronTicket_CTTCSD_Task.State != 0)) { System.Threading.Thread.Sleep(500); };
            while ((ElectronTicket_Sporttery_Task != null) && (ElectronTicket_Sporttery_Task.State != 0)) { System.Threading.Thread.Sleep(500); };
        }
    }
}
